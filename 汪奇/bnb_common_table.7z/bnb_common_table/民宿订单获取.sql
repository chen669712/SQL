SELECT oh.orderId,
	oh.uid
FROM ods_htl_bnborderdb.order_header_v2 oh,
     ods_htl_bnborderdb.order_item oi,
     ods_htl_bnborderdb.order_item_space ois
WHERE oh.orderId = oi.orderId 
	AND oi.orderItemId = ois.orderItemId 
	AND oh.payStatusId IN (12, 20, 22, 23)
	AND to_date(oh.createdTime) >='2017-11-11'
	AND to_date(oh.createdTime) < '2017-11-12'
	AND oh.salesChannel = 1   --- 1 直销，2 分销
    AND oh.d = '2017-11-12'
	AND oi.d = '2017-11-12'
	AND ois.d = '2017-11-12' 
limit 10;

set calcDay='2017-10-01';
set beginDay='2017-12-15';
use bnb_hive_db;
drop table tmp_wq_bnb_orderdetail;
create table tmp_wq_bnb_orderdetail as
SELECT oh.d
	,oh.uid
	,oh.orderid
	,oh.salesChannel
--	,oh.visitsource
--	,oi.orderitemid
	,oi.productid
--	,oi.statusid
	,oi.saleamount
	,ois.checkin
	,ois.checkout
	,datediff(to_date(ois.checkout), to_date(ois.checkin)) as days
	,ois.cityid
	,ois.childquantity
FROM
(SELECT to_date(createdtime) as d   -- 下单时间
	,uid                              -- 下单用户UID 分销模式为固定值:$seller-agent
	,orderId                          -- 携程订单ID
	,salesChannel                     -- 订单的销售渠道:1.携程直销,2分销；
	,visitsource                      -- 订单内部来源:0.未设置
	,terminaltype                     -- 用户下单使用的终端类型：0.未知 ,10.手机APP下单,11.APP H5, 20.PC端
	,orderstatusid                    -- 订单状态: 10处理中,20成功,21失败,30已取消,31部分取消
	,paystatusid                      -- 订单支付状态:10-待支付 ,11-支付中,12-支付成功,13-支付失败,20-待退款,21-退款中,22-部分退款,23-已退款,24-退款失败
FROM ods_htl_bnborderdb.order_header_v2
WHERE d = ${hiveconf:calcDay}
    AND uid not in('$seller-agent')
    AND visitsource not in (13,14,18) 
	AND to_date(createdTime) >=${hiveconf:beginDay}
	AND to_date(createdTime) < ${hiveconf:calcDay}) oh
INNER JOIN
(SELECT orderitemid
	,orderid
	,productid
	,statusid
	,saleamount
FROM ods_htl_bnborderdb.order_item 
WHERE d = ${hiveconf:calcDay}
	AND (statusid like '12%' 
	     OR statusid like '20%' 
	     OR statusid like '22%' 
	     OR statusid like '23%'))oi ON oh.orderid=oi.orderid
INNER JOIN
(SELECT d 
	,orderitemid
	,cityid
	,checkin
	,checkout
	,childquantity
	,infantquantity
FROM ods_htl_bnborderdb.order_item_space
WHERE d = ${hiveconf:calcDay}) ois ON oi.orderitemid = ois.orderitemid;


use bnb_hive_db;
drop table tmp_wq_inn_orderdetail;
create table tmp_wq_inn_orderdetail as
SELECT to_date(a.orderdate) as day
	,uid
	,orderid
	,hotel   -- 酒店Id
	,ordpersons    -- 预订入住人数	
	,ordamount -- 订单金额
	,ordcost   -- 订单底价
         ,count(distinct a.orderid) as directorder
      from dw_htlmaindb.FactHotelOrder_All_Inn a
      where to_date(a.orderdate)>=:date-8
        and to_date(a.orderdate)<=:date-1 
        and a.d=:date 
        and a.ordertype_ubt='直接订单'
      group by to_date(a.orderdate)