SELECT * FROM (
SELECT
  c.cityName as `城市名称`,
  a.visitNumber  as `UV`,
  b.orderNumber as `支付订单数`,
  concat_ws('',cast(round((b.orderNumber*100)/a.visitNumber,2) as string),'%')  as `转化率`
FROM
(SELECT get_json_object(value, '$.cityid') AS cityid
  , count(DISTINCT newvalue.data['env_clientcode']) AS visitNumber
FROM dw_mobdb.factmbtracelog_hybrid
WHERE d = :date-1
  AND KEY in ("100641","bnb_inn_list_app_basic")
  GROUP BY get_json_object( VALUE, '$.cityid')) a
JOIN
(select e.cityId
  ,sum(e.orderNumber) AS orderNumber
from (
  SELECT ois.cityId,
    count(oh.orderId) AS orderNumber
  FROM ods_htl_bnborderdb.order_header_v2 oh,
    ods_htl_bnborderdb.order_item oi,
    ods_htl_bnborderdb.order_item_space ois
  WHERE oh.orderId = oi.orderId AND oi.orderItemId = ois.orderItemId AND oh.payStatusId IN (12, 20, 22, 23)
    AND ois.cityId IS NOT NULL
    AND oh.createdTime >= :date-1  AND oh.createdTime <:date
    AND oh.salesChannel = 1
    AND oh.visitsource NOT IN (14, 18)
    AND oh.d = :date  AND oi.d = :date  AND ois.d = :date
  GROUP BY ois.cityId

  UNION ALL

  SELECT om.cityId,
    count(om.orderid) AS orderNumber
  FROM dw_htlmaindb.facthotelorder_all_inn om
  LEFT JOIN Dim_HtlDB.dimhtlhotel dhh ON dhh.hotel = om.hotel
  WHERE om.ordertype_ubt = '直接订单' AND om.orderstatus != 'C'
    AND om.orderdate >=:date-1 and om.orderdate<:date AND om.d =:date
  GROUP BY om.cityId )e
group by cityId) b ON a.cityId = b.cityId
JOIN ods_htl_groupwormholedb.bnb_city c ON a.cityId = c.cityId AND c.d = :date

UNION ALL

SELECT
  '汇总' as `城市名称`,
  a.visitNumber  as `UV`,
  b.orderNumber as `支付订单数`,
  concat_ws('',cast(round((b.orderNumber*100)/a.visitNumber,2) as string),'%')  as `转化率`
FROM (
  SELECT 'all' as `all`,
    count(DISTINCT newvalue.data['env_clientcode']) AS visitNumber
  FROM dw_mobdb.factmbtracelog_hybrid
  WHERE d = :date-1 AND KEY in ("100641","bnb_inn_list_app_basic")) a

  LEFT JOIN
  (select 'all' as `all`,
    sum(e.orderNumber) AS orderNumber
  from (
  SELECT count(oh.orderId) AS orderNumber
  FROM ods_htl_bnborderdb.order_header_v2 oh,
    ods_htl_bnborderdb.order_item oi,
    ods_htl_bnborderdb.order_item_space ois
  WHERE oh.orderId = oi.orderId AND oi.orderItemId = ois.orderItemId
    AND oh.payStatusId IN (12, 20, 22, 23) AND ois.cityId IS NOT NULL
    AND oh.createdTime >= :date-1  AND oh.createdTime <:date  AND oh.salesChannel = 1
    AND oh.visitsource NOT IN (14, 18)
    AND oh.d = :date  AND oi.d = :date  AND ois.d = :date

  UNION ALL

  SELECT count(om.orderid) AS orderNumber
  FROM dw_htlmaindb.facthotelorder_all_inn om
  LEFT JOIN Dim_HtlDB.dimhtlhotel dhh ON dhh.hotel = om.hotel
  WHERE om.ordertype_ubt = '直接订单' AND om.orderstatus != 'C'
    AND om.orderdate >=:date-1 and om.orderdate<:date AND om.d =:date) e
  ) b ON a.all = b.all
) all
order by `支付订单数` desc , `转化率` desc limit 10000