----Step 1:
use dw_htlmaindb;
insert overwrite table inn_order_fromubt_byday partition (d='${operate_date}')
select distinct get_json_object(exdata,'$.orderid') as orderid
  ,a.clientcode
  ,a.vid  ,a.sid  ,a.starttime
  ,get_json_object(exdata,'$.sourcefrom') sourcefrom
  ,b.orderdate
from dw_mobdb.factmbtracelog_sdk a
left join (select * from DW_HtlMainDB.FactHotelOrder where d>='${before90_date}') b
  on get_json_object(a.exdata,'$.orderid')=b.orderid
where a.d ='${operate_date}'
--and pagecode in('hotel_oversea_order','hotel_inland_order')
and actioncode='app_mj_save'
and get_json_object(exdata,'$.sourcefrom') in ('h5_kezhan','gl_kezhan','zby_kezhan')
and get_json_object(exdata,'$.orderid') is not null and get_json_object(exdata,'$.orderid')>0;


----Step 2:
use dw_htlmaindb;
insert overwrite table inn_orderType_fromubt_byday partition (d)
select main.orderid
      ,coalesce(a.orderType,b.orderType,null) as orderType
      ,main.d
from (
     select distinct orderid,d
       from dw_htlmaindb.inn_order_fromubt_byday
      where d ='${operate_date}'
) main
left outer join  ( -- 直接订单
     select distinct a.d,a.orderid, '直接订单' as orderType
       from dw_htlmaindb.inn_order_fromubt_byday a
       join dw_mobdb.factmbactionlog_sdk b
         on a.d=b.d and a.clientcode=b.clientcode
      where b.pagecode='home' and b.actioncode='c_hotel_inn'
        and b.starttime<=a.orderdate
        and a.d ='${operate_date}'
) a on main.orderid=a.orderid and main.d=a.d
left outer join (
       -- 间接订单
       select distinct d ,orderid
           ,case when m.prepagecode in('schedule_empty_trip','schedule_topbar_weekend') then '旅行日程'
                      when m.prepagecode in('dest_pic_detail','318090','252010','318045','318085','318089') then '攻略'
                      when m.prepagecode in('419001','418001') then '特卖汇'
                      when m.prepagecode in('249115','251115','251201','411002','211130','251211','600005437') then '周边游'
                      when m.prepagecode='hotel_inland_inquire' then '国内酒店首页'
                      when m.prepagecode='hotel_inland_hotkeyword' then '国内关键词页'
                      when m.prepagecode='hotel_inland_detail' then '国内酒店详情页'
                       when m.prepagecode='global_search_home' then '全站搜索'
                       when m.prepagecode='408017' then '汽车票'
                       when m.prepagecode='train_inquire' then '火车票'
                      when m.prepagecode='hotel_inland_list' then '国内酒店列表页'
               else prepagecode end orderType
      from (
                 select distinct a.d
                       ,a.orderid
                       ,a.clientcode,a.vid,a.sid
                       ,b.prepagecode
                       ,b.starttime
                       ,row_number() over (partition by a.d,a.orderid,a.clientcode,a.vid,a.sid order by unix_timestamp(b.starttime) desc ) num
                          --  2016-01-11       取订单前浏览的最后一个页面作为跳转页面
                 from dw_htlmaindb.inn_order_fromubt_byday a
                 join dw_mobdb.factmbpageview b  on a.d=b.d and a.clientcode=b.clientcode and a.vid=b.vid and a.sid=b.sid
                 where b.prepagecode in('train_inquire','408017','dest_pic_detail','318090','252010','318045','hotel_inland_inquire'
                        ,'hotel_inland_hotkeyword','hotel_inland_detail','global_search_home','schedule_empty_trip','schedule_topbar_weekend'
                               ,'318085','318089','419001','418001','249115','251115','251201','411002','211130','251211','600005437','hotel_inland_list')
                    and b.pagecode in('600004932','600005144','hotel_inn_detail','hotel_inn_oversea_detail')
                    and a.d ='${operate_date}'
                    and b.starttime<a.orderdate -- 2017-01-10       增加浏览时间在预订时间前
       )  m
       where num=1
) b  on main.orderid=b.orderid and main.d=b.d

----Step 3:
use dw_htlmaindb;
insert overwrite table FactHtlOrderChangeSource_Inn partition (d='${CurrentDate}')
select orderid ,orderdate     ,room     ,roomchgid    ,hotel      ,hotelchgid     ,uid  ,status     ,orderstatus   ,orderdatekey       ,customereval ,
              earlyarrivaltime     ,arrival    ,arrivalkey      ,departure      ,departurekey ,etd  ,etdkey   ,ordpersons       ,clientname    ,modifyreason       ,holdroomtype      ,
              ordquantity    ,ciiquantity     ,ordamount   ,ciiamount      ,ordcost  ,ciireceivable  ,ciipayable      ,ciiacrealget       ,billheadid      ,hasbillhead   ,
              serverfrom     ,referencetype       ,reference      ,referenceby   ,validity   ,vc   ,vcby      ,isonline       ,ispackageorder    ,packageorderid    ,golduserlevel ,
              ordertype      ,currency ,paymenttype ,balancetype  ,guarantee     ,allneedguarantee ,cancelreason ,famount       ,fcostamount  ,grouporderclass   ,
              vipgrade ,clientcomefrom    ,delaytimes    ,balanceperiod      ,corppaytype  ,ordroomstatus     ,ordroomnum       ,averecommendlevel    ,aveprice ,ordadvanceday    ,
              ordsource      ,orddays ,commission1st     ,ciiroomnum  ,isnoshow      ,ciichkquantity       ,ciinosquantity       ,isacmodify    ,uidname ,custid     ,
              isholdroom    ,updatedt       ,auditkey ,freesale  ,recommendlevel  ,ciiamountvalid      ,isadv      ,iscorp       ,ciiadvquantity       ,ctripcardno   ,
              upersons ,fupersons     ,futype    ,eid  ,ip1  ,ip2  ,ip3  ,ip4  ,frompackageorder      ,custtype ,sysconfirmtype       ,confirmdate  ,
              modifieddate ,processdate  ,confirmdeadline   ,hotelcheckin  ,isdiffprice      ,chgtimes       ,isebooking       ,receivetype   ,readtime       ,
              receiver  ,cutofftime     ,urgencylevel ,isfromnoroom      ,lastcanceltime       ,processoper  ,confirmoper       ,confirmtype  ,ebookingprocess  ,
              getfaxtime      ,ciiuniquantity ,readtimeebooking       ,receiverebooking ,readtimefax   ,receiverfax       ,isprocessed   ,contactname ,remarktype   ,
              contacttel       ,mobilephone ,noshowreason     ,holddeadline ,noshowauditoper ,noshowaudittime ,insertdt       ,supereid ,upselling       ,
              usefg      ,isfhpkg  ,houradjuest  ,ishotelconfirm      ,isswitch  ,roomgiftid     ,acreceivebranch   ,serverfromid       ,isstraightconnect  ,
              switchstatus   ,acgatheringtype   ,guaranteeway      ,acuserpaydate      ,aggquantity  ,tmoney  ,gtickettype       ,actualroom   ,clanguage     ,acmroper      ,
              custlastpaydate     ,acservicefee  ,isinsurance    ,ordtmoney    ,riskdata  ,isemailconfirm      ,phonesystemid       ,remarks ,ismaskedorder     ,
              allianceid ,sid  ,emailconfirmstatus      ,mobileconfirmstatus    ,commentgiftsendstatus      ,iscashback       ,maskedhotelid     ,actualhotelid ,
              maskedroomtypeid      ,sourceid ,ouid       ,submitfrom   ,istestaccount ,channelid      ,cityid       ,isflashsaleorder    ,isvirtualholdroom ,ishotsaleorder      ,
              cii_receivable_ctrip ,orderType_UBT
from (
   select *,
          row_number() over(partition by orderid order by sourcetype) num
   from (
       select a.orderid ,orderdate   ,room     ,roomchgid    ,hotel      ,hotelchgid     ,uid  ,status     ,orderstatus       ,orderdatekey ,customereval ,
              earlyarrivaltime     ,arrival    ,arrivalkey      ,departure      ,departurekey ,etd  ,etdkey   ,ordpersons       ,clientname    ,modifyreason       ,holdroomtype      ,
              ordquantity    ,ciiquantity     ,ordamount   ,ciiamount      ,ordcost  ,ciireceivable  ,ciipayable       ,ciiacrealget    ,billheadid      ,hasbillhead   ,
              serverfrom     ,referencetype       ,reference      ,referenceby   ,validity   ,vc   ,vcby      ,isonline       ,ispackageorder    ,packageorderid    ,golduserlevel ,
              a.ordertype    ,currency ,paymenttype ,balancetype  ,guarantee     ,allneedguarantee ,cancelreason       ,famount ,fcostamount  ,grouporderclass   ,
              vipgrade ,clientcomefrom    ,delaytimes    ,balanceperiod      ,corppaytype  ,ordroomstatus       ,ordroomnum ,averecommendlevel    ,aveprice ,ordadvanceday    ,
              ordsource      ,orddays ,commission1st     ,ciiroomnum  ,isnoshow      ,ciichkquantity       ,ciinosquantity       ,isacmodify    ,uidname ,custid     ,
              isholdroom    ,updatedt       ,auditkey ,freesale  ,recommendlevel  ,ciiamountvalid      ,isadv       ,iscorp    ,ciiadvquantity       ,ctripcardno   ,
              upersons ,fupersons     ,futype    ,eid  ,ip1  ,ip2  ,ip3  ,ip4  ,frompackageorder      ,custtype       ,sysconfirmtype     ,confirmdate  ,
              modifieddate ,processdate  ,confirmdeadline   ,hotelcheckin  ,isdiffprice      ,chgtimes       ,isebooking    ,receivetype   ,readtime       ,
              receiver  ,cutofftime     ,urgencylevel ,isfromnoroom      ,lastcanceltime       ,processoper       ,confirmoper  ,confirmtype  ,ebookingprocess  ,
              getfaxtime      ,ciiuniquantity ,readtimeebooking       ,receiverebooking ,readtimefax   ,receiverfax       ,isprocessed   ,contactname ,remarktype   ,
              contacttel       ,mobilephone ,noshowreason     ,holddeadline ,noshowauditoper ,noshowaudittime       ,insertdt  ,supereid ,upselling       ,
              usefg      ,isfhpkg  ,houradjuest  ,ishotelconfirm      ,isswitch  ,roomgiftid     ,acreceivebranch       ,serverfromid ,isstraightconnect  ,
              switchstatus   ,acgatheringtype   ,guaranteeway      ,acuserpaydate      ,aggquantity  ,tmoney       ,gtickettype    ,actualroom   ,clanguage     ,acmroper      ,
              custlastpaydate     ,acservicefee  ,isinsurance    ,ordtmoney    ,riskdata  ,isemailconfirm       ,phonesystemid    ,remarks ,ismaskedorder     ,
              allianceid ,sid  ,emailconfirmstatus      ,mobileconfirmstatus    ,commentgiftsendstatus       ,iscashback    ,maskedhotelid     ,actualhotelid ,
              maskedroomtypeid      ,sourceid ,ouid       ,submitfrom   ,istestaccount ,channelid      ,cityid       ,isflashsaleorder    ,isvirtualholdroom ,ishotsaleorder      ,
              cii_receivable_ctrip ,b.ordertype as orderType_UBT,
              1 as sourcetype  -- 优先取宫格的数据
       from (select * from DW_HtlMainDB.FactHotelOrder where d>='${before90_date}') a
       join (
              select m.orderid,m.ordertype,m.d
              from dw_htlmaindb.inn_orderType_fromubt_byday m
              inner join      (
                 select orderid
                    ,max(d) as d
                 from  dw_htlmaindb.inn_orderType_fromubt_byday
                 where d>='${before90_date}'
                 group by orderid
              ) n on m.orderid=n.orderid and m.d=n.d
              where m.d>='${before90_date}'
       ) b on a.orderid=b.orderid

       union all

       select orderid ,orderdate     ,room     ,roomchgid    ,a.hotel   ,hotelchgid     ,uid  ,status     ,orderstatus       ,orderdatekey ,customereval ,
              earlyarrivaltime     ,arrival    ,arrivalkey      ,departure      ,departurekey ,etd  ,etdkey   ,ordpersons       ,clientname    ,modifyreason       ,holdroomtype      ,
              ordquantity    ,ciiquantity     ,ordamount   ,ciiamount      ,ordcost  ,ciireceivable  ,ciipayable       ,ciiacrealget    ,billheadid      ,hasbillhead   ,
              serverfrom     ,referencetype       ,reference      ,referenceby   ,validity   ,vc   ,vcby      ,isonline       ,ispackageorder    ,packageorderid    ,golduserlevel ,
              a.ordertype    ,currency ,paymenttype ,balancetype  ,guarantee     ,allneedguarantee ,cancelreason       ,famount ,fcostamount  ,grouporderclass   ,
              vipgrade ,clientcomefrom    ,delaytimes    ,balanceperiod      ,corppaytype  ,ordroomstatus       ,ordroomnum ,averecommendlevel    ,aveprice ,ordadvanceday    ,
              ordsource      ,orddays ,commission1st     ,ciiroomnum  ,isnoshow      ,ciichkquantity       ,ciinosquantity       ,isacmodify    ,uidname ,custid     ,
              isholdroom    ,updatedt       ,auditkey ,freesale  ,recommendlevel  ,ciiamountvalid      ,isadv       ,iscorp    ,ciiadvquantity       ,ctripcardno   ,
              upersons ,fupersons     ,futype    ,eid  ,ip1  ,ip2  ,ip3  ,ip4  ,frompackageorder      ,custtype       ,sysconfirmtype     ,confirmdate  ,
              modifieddate ,processdate  ,confirmdeadline   ,hotelcheckin  ,isdiffprice      ,chgtimes       ,isebooking    ,receivetype   ,readtime       ,
              receiver  ,cutofftime     ,urgencylevel ,isfromnoroom      ,lastcanceltime       ,processoper       ,confirmoper  ,confirmtype  ,ebookingprocess  ,
              getfaxtime      ,ciiuniquantity ,readtimeebooking       ,receiverebooking ,readtimefax   ,receiverfax       ,isprocessed   ,contactname ,remarktype   ,
              contacttel       ,mobilephone ,noshowreason     ,holddeadline ,noshowauditoper ,noshowaudittime       ,insertdt  ,supereid ,upselling       ,
              usefg      ,isfhpkg  ,houradjuest  ,ishotelconfirm      ,isswitch  ,roomgiftid     ,acreceivebranch       ,serverfromid ,isstraightconnect  ,
              switchstatus   ,acgatheringtype   ,guaranteeway      ,acuserpaydate      ,aggquantity  ,tmoney       ,gtickettype    ,actualroom   ,clanguage     ,acmroper      ,
              custlastpaydate     ,acservicefee  ,isinsurance    ,ordtmoney    ,riskdata  ,isemailconfirm       ,phonesystemid    ,remarks ,ismaskedorder     ,
              allianceid ,sid  ,emailconfirmstatus      ,mobileconfirmstatus    ,commentgiftsendstatus       ,iscashback    ,maskedhotelid     ,actualhotelid ,
              maskedroomtypeid      ,sourceid ,ouid       ,submitfrom   ,istestaccount ,channelid      ,cityid       ,isflashsaleorder    ,isvirtualholdroom ,ishotsaleorder      ,
              cii_receivable_ctrip ,'hotel_order' as orderType_UBT ,
              2 as sourcetype
       from (select * from DW_HtlMainDB.FactHotelOrder where d>='${before90_date}')  a
       join (
            select hotel from dim_hoteldb.vdimhotel
            where hotelname like '%斯维登%' or hotelname like '%途家%' or hotelname like '%欢墅%' )dh  on a.hotel=dh.hotel
   ) c
) d where num=1;


--- Step 4:
INSERT OVERWRITE TABLE DW_HtlMainDB.FactHotelOrder_All_Inn partition(d='${CurrentDate}')
select M.*
from
(
    SELECT ${SelectCOLS}
    FROM DW_HTLMainDB.FactHtlOrderChangeSource_Inn a
    WHERE a.d='${CurrentDate}'

    union all

    SELECT ${SelectCOLS}
    FROM (select * from DW_HtlMainDB.FactHotelOrder_All_Inn where d='${operate_date}') a
    LEFT JOIN (select * from DW_HTLMainDB.FactHtlOrderChangeSource_Inn where d='${CurrentDate}') b
    ON a.orderid=b.orderid
    WHERE  b.OrderID is null )M


SelectCOLS="
     A.orderid
    ,A.orderdate
    ,A.room
    ,A.roomchgid
    ,A.hotel
    ,A.hotelchgid
    ,A.uid
    ,A.status
    ,A.orderstatus
    ,A.orderdatekey
    ,A.customereval
    ,A.earlyarrivaltime
    ,A.arrival
    ,A.arrivalkey
    ,A.departure
    ,A.departurekey
    ,A.etd
    ,A.etdkey
    ,A.ordpersons
    ,A.clientname
    ,A.modifyreason
    ,A.holdroomtype
    ,A.ordquantity
    ,A.ciiquantity
    ,A.ordamount
    ,A.ciiamount
    ,A.ordcost
    ,A.ciireceivable
    ,A.ciipayable
    ,A.ciiacrealget
    ,A.billheadid
    ,A.hasbillhead
    ,A.serverfrom
    ,A.referencetype
    ,A.reference
    ,A.referenceby
    ,A.validity
    ,A.vc
    ,A.vcby
    ,A.isonline
    ,A.ispackageorder
    ,A.packageorderid
    ,A.golduserlevel
    ,A.ordertype
    ,A.currency
    ,A.paymenttype
    ,A.balancetype
    ,A.guarantee
    ,A.allneedguarantee
    ,A.cancelreason
    ,A.famount
    ,A.fcostamount
    ,A.grouporderclass
    ,A.vipgrade
    ,A.clientcomefrom
    ,A.delaytimes
    ,A.balanceperiod
    ,A.corppaytype
    ,A.ordroomstatus
    ,A.ordroomnum
    ,A.averecommendlevel
    ,A.aveprice
    ,A.ordadvanceday
    ,A.ordsource
    ,A.orddays
    ,A.commission1st
    ,A.ciiroomnum
    ,A.isnoshow
    ,A.ciichkquantity
    ,A.ciinosquantity
    ,A.isacmodify
    ,A.uidname
    ,A.custid
    ,A.isholdroom
    ,A.updatedt
    ,A.auditkey
    ,A.freesale
    ,A.recommendlevel
    ,A.ciiamountvalid
    ,A.isadv
    ,A.iscorp
    ,A.ciiadvquantity
    ,A.ctripcardno
    ,A.upersons
    ,A.fupersons
    ,A.futype
    ,A.eid
    ,A.ip1
    ,A.ip2
    ,A.ip3
    ,A.ip4
    ,A.frompackageorder
    ,A.custtype
    ,A.sysconfirmtype
    ,A.confirmdate
    ,A.modifieddate
    ,A.processdate
    ,A.confirmdeadline
    ,A.hotelcheckin
    ,A.isdiffprice
    ,A.chgtimes
    ,A.isebooking
    ,A.receivetype
    ,A.readtime
    ,A.receiver
    ,A.cutofftime
    ,A.urgencylevel
    ,A.isfromnoroom
    ,A.lastcanceltime
    ,A.processoper
    ,A.confirmoper
    ,A.confirmtype
    ,A.ebookingprocess
    ,A.getfaxtime
    ,A.ciiuniquantity
    ,A.readtimeebooking
    ,A.receiverebooking
    ,A.readtimefax
    ,A.receiverfax
    ,A.isprocessed
    ,A.contactname
    ,A.remarktype
    ,A.contacttel
    ,A.mobilephone
    ,A.noshowreason
    ,A.holddeadline
    ,A.noshowauditoper
    ,A.noshowaudittime
    ,A.insertdt
    ,A.supereid
    ,A.upselling
    ,A.usefg
    ,A.isfhpkg
    ,A.houradjuest
    ,A.ishotelconfirm
    ,A.isswitch
    ,A.roomgiftid
    ,A.acreceivebranch
    ,A.serverfromid
    ,A.isstraightconnect
    ,A.switchstatus
    ,A.acgatheringtype
    ,A.guaranteeway
    ,A.acuserpaydate
    ,A.aggquantity
    ,A.tmoney
    ,A.gtickettype
    ,A.actualroom
    ,A.clanguage
    ,A.acmroper
    ,A.custlastpaydate
    ,A.acservicefee
    ,A.isinsurance
    ,A.ordtmoney
    ,A.riskdata
    ,A.isemailconfirm
    ,A.phonesystemid
    ,A.remarks
    ,A.ismaskedorder
    ,A.allianceid
    ,A.sid
    ,A.emailconfirmstatus
    ,A.mobileconfirmstatus
    ,A.commentgiftsendstatus
    ,A.iscashback
    ,A.maskedhotelid
    ,A.actualhotelid
    ,A.maskedroomtypeid
    ,A.sourceid
    ,A.ouid
    ,A.submitfrom
    ,A.istestaccount
    ,A.channelid
    ,A.cityid
    ,A.isflashsaleorder
    ,A.isvirtualholdroom
       ,A.ishotsaleorder
    ,A.Cii_Receivable_Ctrip
    ,A.OrderType_UBT
"