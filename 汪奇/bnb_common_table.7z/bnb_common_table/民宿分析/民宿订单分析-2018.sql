--进入宫格的用户数



-- 按照周来统计用户数
use bnb_hive_db;
select d
	, cast(datediff(to_date(d), to_date('2018-01-01')) / 7 + 1 as int) as week
	, count(distinct clientcode) as num
from bnb_pageview
where d>= '2018-01-01'
group by d
	, cast(datediff(to_date(d), to_date('2018-01-01')) / 7 + 1 as int)


-- 按照周来统计订单

select to_date(ordertime) as d
	, cast(datediff(to_date(ordertime), to_date('2018-01-01')) / 7 + 1 as int) as week
	, count(distinct orderid) as num
from bnb_orderinfo
where d='2018-02-26'
	and to_date(ordertime)>='2018-01-01'
group by to_date(ordertime)
	, cast(datediff(to_date(ordertime), to_date('2018-01-01')) / 7 + 1 as int) 