use bnb_hive_db;

select aa.d
  ,sum (IF(oiuser.uid is null, 0, 1)) as num
  ,count (distinct aa.cid) as nums
from
(select distinct oiuser.d
  ,oiuser.uid
  ,oiuser.cid
from
(select d
  , uid
  , clientcode as cid
from bnb_pageview
where d >='2018-01-01'
  and pagecode in('600003570')
  and prepagecode in ('600003564')) oiuser
left outer join
(select to_date(ordertime) as d
  , uid
  , cid
from bnb_hive_db.bnb_orderinfo
where d = '2018-04-23'
  and to_date(ordertime)>='2018-01-01' and to_date(ordertime)<='2018-04-23'
  and source in('100')
  and (visitsource is null or visitsource not in('13','14','18'))
  and (sellerid is null or sellerid = '0'))bnboi on oiuser.d = bnboi.d and oiuser.cid = bnboi.cid
where bnboi.cid is null) aa
left outer join
(select distinct uid
from bnb_hive_db.bnb_orderinfo
where d = '2018-04-23') oiuser on lower(aa.uid) = lower(oiuser.uid)
group by aa.d


use bnb_hive_db;
select oi.d
  ,sum (IF(ops.uid is null, 0, 1)) as num
  ,count (distinct oi.cid) as nums
from
(select to_date(ordertime) as d
  , uid
  , cid
from bnb_hive_db.bnb_orderinfo
where d = '2018-04-23'
  and to_date(ordertime)>='2018-03-01' and to_date(ordertime)<='2018-04-23'
  and source in('100')
  and (visitsource is null or visitsource not in('13','14','18'))
  and (sellerid is null or sellerid = '0')) oi
left outer join
(select d, uid
from tmp_wq_filter_parsing
where people not in ('-1')) ops on oi.d=ops.d and lower(oi.uid) = lower(ops.uid)
group by oi.d