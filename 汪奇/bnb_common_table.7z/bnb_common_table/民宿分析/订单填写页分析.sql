


use bnb_hive_db;
select d
  , key
  , count(distinct cid) as num
from bnb_tracelog
where d>='2018-04-01'
  and pageid = '600003570'
  and key in ('o_bnb_inn_order_filling_app'
    , 'c_bnb_inn_order_filling_app'
    , 'c_bnb_inn_order_filling_operate_app')
group by d, key;


select d
  , count (distinct clientcode) as num
from dw_mobdb.factmbpageview
where d= '2018-04-26'
  and clientcode is not null
  and clientcode not in ('','00000000000000000000')

--- source: 100-查看详情，101-入离时间，102-优惠券，103-明细, 104-发票
use bnb_hive_db;
select d
  , get_json_object(value, '$.source') as source
  , count (distinct cid) as num
from bnb_tracelog
where d>='2018-04-01'
  and pageid = '600003570'
  and key = 'c_bnb_inn_order_filling_operate_app'
group by d
  , get_json_object(value, '$.source');


use bnb_hive_db;
select *
from bnb_tracelog
where d>='2018-04-01'
  and pageid = '600003570'
  and key in ('o_bnb_inn_order_filling_app'
    , 'c_bnb_inn_order_filling_app'
    , 'c_bnb_inn_order_filling_operate_app')
limit 100