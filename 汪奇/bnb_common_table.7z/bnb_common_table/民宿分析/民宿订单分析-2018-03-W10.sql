
---获取有押金的产品
select * from ods_htl_groupwormholedb.bnb_space_additional_fees
where d='2018-03-05' and securitydeposit>0


select d
  ,productid
from bnb_product_trace
where d >= '2018-02-01'
  and source = '102'
  and type = '101'


---进入宫格人群分析
use bnb_hive_db;
drop table if exists tmp_wq_bnb_users;
create table tmp_wq_bnb_users as
select users.uid
  ,get_json_object(ui.userattributes, '$.birth') as birthday
  ,case when get_json_object(ui.userattributes, '$.birth') is null then '未知'
      when get_json_object(ui.userattributes, '$.birth') = 'unknown' then '未知'
      when get_json_object(ui.userattributes, '$.birth') = '未知' then '未知'
      when get_json_object(ui.userattributes, '$.birth') < '1970-00-00' then '60s'
      when get_json_object(ui.userattributes, '$.birth') < '1980-00-00' then '70s'
      when get_json_object(ui.userattributes, '$.birth') < '1990-00-00' then '80s'
      when get_json_object(ui.userattributes, '$.birth') < '2000-00-00' then '90s'
      when get_json_object(ui.userattributes, '$.birth') >= '2000-00-00' then '00s'
      else '未知' end as birth
  ,get_json_object(ui.userattributes, '$.currentresidentplace') as home
  ,get_json_object(ui.userattributes, '$.gender') as gender
from
( select distinct uid
  from bnb_pageview
  where d >= '2018-01-01'
    and d < '2018-03-01') users
left outer join
(select uid
  ,userattributes
from olap_mobdb.userattributes_tag) ui on lower(users.uid)=lower(ui.uid);


use bnb_hive_db;
select birthday
	, birth
	, home
	, gender
	, count(distinct uid) nums
from tmp_wq_bnb_users
group by birthday
	, birth
	, home
	, gender


---民宿下单人群分析
use bnb_hive_db;
drop table if exists tmp_wq_bnb_oi_users;
create table tmp_wq_bnb_oi_users as
select users.uid
  ,get_json_object(ui.userattributes, '$.birth') as birthday
  ,case when get_json_object(ui.userattributes, '$.birth') is null then '未知'
      when get_json_object(ui.userattributes, '$.birth') = 'unknown' then '未知'
      when get_json_object(ui.userattributes, '$.birth') = '未知' then '未知'
      when get_json_object(ui.userattributes, '$.birth') < '1970-00-00' then '60s'
      when get_json_object(ui.userattributes, '$.birth') < '1980-00-00' then '70s'
      when get_json_object(ui.userattributes, '$.birth') < '1990-00-00' then '80s'
      when get_json_object(ui.userattributes, '$.birth') < '2000-00-00' then '90s'
      when get_json_object(ui.userattributes, '$.birth') >= '2000-00-00' then '00s'
      else '未知' end as birth
  ,get_json_object(ui.userattributes, '$.currentresidentplace') as home
  ,get_json_object(ui.userattributes, '$.gender') as gender
from
( select distinct uid
  from bnb_orderinfo
  where d = '2018-03-02'
    and to_date(ordertime) >= '2018-01-01'
    and to_date(ordertime) < '2018-03-01') users
left outer join
(select uid
  ,userattributes
from olap_mobdb.userattributes_tag) ui on lower(users.uid)=lower(ui.uid);



--- 民宿首页分析
use bnb_hive_db;
select d
	,count(distinct clientcode) as num
from bnb_pageview
where pagecode = '600003560'
  and d>='2018-02-01'
  and d<'2018-03-21'
group by d


-- 二屏曝光
use bnb_hive_db;
select d
  , count(distinct cid) as num
from bnb_tracelog
where d>='2018-02-01'
  and d<'2018-03-21'
  and pageid = '600003560'
  and key in ('o_bnb_inn_2nd_home_app')
group by d


--- 二屏热门目的地
use bnb_hive_db;
select d
  , count(distinct cid) as num
from bnb_tracelog
where d>='2018-02-01'
  and d<'2018-03-21'
  and pageid = '600003560'
  and key in ('c_bnb_inn_home_hot_app')
group by d



select d
  , get_json_object(value, '$.source') as source
  , count(distinct uid)
from bnb_tracelog
where d>='2018-02-01'
  and d<'2018-03-01'
  and key = 'c_bnb_inn_banner_app'
group by d
  ,source


-- 搜索项操作
select d
  , get_json_object(value, '$.source') as source
  , count(distinct uid)
from bnb_tracelog
where d>='2018-02-01'
  and d<'2018-03-01'
  and key = 'c_bnb_inn_home_filter_app'
group by d
  ,source


-- 浏览历史
use bnb_hive_db;
select d
  , count(distinct uid)
from bnb_tracelog
where d>='2018-02-01'
  and d<'2018-03-01'
  and key in ('c_bnb_inn_home_prd_history_app')
--  and key in ('o_bnb_inn_home_prd_history_app')
group by d


--- 二屏产品
use bnb_hive_db;
select d
  , count(distinct uid)
from bnb_tracelog
where d>='2018-02-01'
  and d<'2018-03-01'
  and get_json_object(value, '$.source') = '100'  -- 特卖
  and get_json_object(value, '$.source') = '101'  -- 推荐
  and key = 'c_bnb_inn_product_app'
group by d



--- 免押金分析

-- step1 取出订单填写页的产品的分类，有无押金
use bnb_hive_db;
select d
  , info.deposit
  , count(distinct info.productid)
from (
select distinct prds.d
  , prds.productid
  , prds.uid
  , fees.securitydeposit
  , case when fees.securitydeposit is null then 'w'
		when fees.securitydeposit > 0 then 'y'
    else 'n' end as deposit
from(
  select d
    , get_json_object(value, '$.productid') as productid
    , uid
  from bnb_tracelog
  where d >= '2018-01-01'
    and d< '2018-03-01'
    and key in('o_bnb_inn_order_filling_app')) prds
left outer join(
  select *
  from ods_htl_groupwormholedb.bnb_space_additional_fees
  where d='2018-03-05') fees on prds.productid = fees.spaceid ) info
group by d
  ,info.deposit;

-- step2 看看Step1中转化成的订单数
use bnb_hive_db;
select info.d
  , info.deposit
  , count(distinct oi.orderid)
from
(select to_date(ordertime) as d
  , uid
  , orderid
  , productid
from bnb_orderinfo
where d = '2018-03-05'
  and source = '100' --只取民宿
  and to_date(ordertime) >= '2018-01-01'
  and to_date(ordertime) < '2018-03-01') oi
right outer join
(select distinct prds.d
    , prds.productid
    , prds.uid
    , fees.securitydeposit
    , case when fees.securitydeposit is null then 'w'
        when fees.securitydeposit > 0 then 'y'
      else 'n' end as deposit
  from(
    select d
      , get_json_object(value, '$.productid') as productid
      , uid
    from bnb_tracelog
    where d >= '2018-01-01'
      and d< '2018-03-01'
      and key in('o_bnb_inn_order_filling_app')) prds
  left outer join
  (select *
  from ods_htl_groupwormholedb.bnb_space_additional_fees
  where d='2018-03-05') fees on prds.productid = fees.spaceid
) info on oi.productid = info.productid and oi.d = info.d
group by info.d
  , info.deposit
limit 100



---获取每个用户的城市
use bnb_hive_db;
SELECT distinct uid
  , cityid
  , cityname
  , dense_rank() over (partition by uid order by cityid) as nums
from bnb_pageview
where d = '2018-03-01'
	and uid is not null
	and uid not in ('')
limit 100


---- step1 订单的目的地城市及订单数
select city.cityname
  , count(DISTINCT orderid) as nums
  from
  (select to_date(ordertime) as d  --通过民宿宫格生成的订单
      , uid
      , orderid
      , cityid
    from bnb_orderinfo
    where d = '2018-03-06'
      and to_date(ordertime) >='2018-01-01'
      and to_date(ordertime) <'2018-03-01'
      and source = '100') oi
    left outer join
    (select cityid
      ,cityname
    from ods_htl_groupwormholedb.bnb_city
  where d = '2018-03-06') city on oi.cityid = city.cityid
group by city.cityname

---- 获取订单的目的地城市和PV的城市匹配的数量
use bnb_hive_db;
drop table if exists tmp_wq_oi_info;
create table tmp_wq_oi_info as
select oi.d
  , oi.uid
  , oi.cityname
  , pv.cityname
  , case when pv.cityname is null or pv.cityname in('中国') then 'c'
      when oi.cityname = pv.cityname then 'y'
    else 'n' end as cityflag
  , oi.orderid
from
  (select distinct oi.d
    , oi.uid
    , oi.orderid
    , oi.cityid
    , city.cityname
  from
  (select to_date(ordertime) as d  --通过民宿宫格生成的订单
      , uid
      , orderid
      , cityid
    from bnb_orderinfo
    where d = '2018-03-06'
      and to_date(ordertime) >='2018-01-01'
      and to_date(ordertime) <'2018-01-02'
  	  and uid not in ('$seller-agent')
      and source = '100') oi
    left outer join
    (select cityid
      ,cityname
    from ods_htl_groupwormholedb.bnb_city
  where d = '2018-03-06') city on oi.cityid = city.cityid ) oi

  left outer join

  (SELECT distinct d
    , uid
    , cityid
    , cityname
    , dense_rank() over (partition by uid order by cityid) as nums
  from bnb_pageview
  where d >= '2018-01-01'
    and d< '2018-01-02'
    and uid is not null
    and uid not in ('')) pv on pv.d = oi.d and lower(pv.uid)=lower(oi.uid) and pv.cityname = oi.cityname;

---查看每个订单城市的匹配度
use bnb_hive_db;
select ocityname
  , count(distinct orderid) as num
from tmp_wq_oi_info
group by ocityname
  , cityflag




----首页豪宅点击
use bnb_hive_db;
select d
  , count(distinct uid)
from bnb_tracelog
where d>='2018-02-01'
  and d<'2018-03-01'
  and key = 'c_bnb_inn_banner_app'
  and get_json_object(value, '$.source') = '101'
group by d


use bnb_hive_db;
select d
  , count(distinct uid) as nums
from
(select d
  , uid
  , get_json_object(value, '$.filter.labelid')  as label
from bnb_tracelog
where d>='2018-02-01'
  and d<'2018-03-01'
  and key = 'c_bnb_inn_list_filter_app') info
where info.label like '%豪宅%'
group by d



