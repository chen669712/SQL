-----------------------------------------------------------------
--- 分析订单用户的新老客分布
-----------------------------------------------------------------
use bnb_hive_db;
set calcDay=from_unixtime(unix_timestamp(),'yyyy-MM-dd');
drop table  if exists tmp_wq_bnb_members;
create table tmp_wq_bnb_members as
select bnb.d
	, bnb.uid
	, unix_timestamp(bnb.d, 'yyyy-MM-dd') as utime
	, mem.gender
	, mem.birth
	, mem.signupdate
	, tag.home
from 
(select distinct ordertime as d
	, uid
from bnb_orderinfo
where d ='2018-01-11'
	and ordertime >='2017-12-01') bnb
left outer join 
(select uid
	, to_date(signupdate) as signupdate  ----用户注册时间
	, gender
	, case when birthday is null then '未知'
	  when (birthday = 'unknown' or birthday = '未知') then '未知'
      when birthday < '1970-00-00' then '60s'
      when birthday < '1980-00-00' then '70s'
      when birthday < '1990-00-00' then '80s'
      when birthday < '2000-00-00' then '90s'
      when birthday >= '2000-00-00' then '00s'
      else '未知' end as birth
 from dw_bbzdb.members 
where d=${hiveconf:calcDay}) mem on lower(bnb.uid) = lower(mem.uid) and bnb.d=mem.signupdate
left outer join 
(select uid
	,get_json_object(userattributes, '$.currentresidentplace') as home
from olap_mobdb.userattributes_tag) tag on lower(tag.uid)=lower(bnb.uid);


drop table  if exists tmp_wq_bnb_users;
create table tmp_wq_bnb_users as
select mem.*
	,case when (oi.uid is not null and mem.utime > oi.min_time) then 'y' 
	 else 'n' end as orderstatus 
from tmp_wq_bnb_members mem
left outer join
(select uid
	, min(unix_timestamp(ordertime, 'yyyy-MM-dd')) as min_time
from bnb_orderinfo
where d = '2018-01-11'
group by uid) oi on lower(mem.uid) = lower(oi.uid);


-------------------------------------------------------------------
--获取城市产品的经纬度
-------------------------------------------------------------------
ods_htl_groupwormholedb.bnb_space


use bnb_hive_db;
set beginDay='2017-12-01';
set endDay='2017-12-30';
drop table if exists tmp_wq_bnb_user_city_trace;
create table tmp_wq_bnb_user_city_trace as
SELECT d
  , uid
  , get_json_object(value, '$.cityid') AS cityid
FROM bnb_tracelog
WHERE d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
  and uid is not null


---根据uid分析用户的性别，年龄和常住地
set calcDay=from_unixtime(unix_timestamp(),'yyyy-MM-dd');
set cityId='32'; 
select bnb.uid
	,mem.gender
	,mem.birth
	,tag.home
from 
(select distinct uid
from tmp_wq_bnb_user_city_trace
where cityid=${hiveconf:cityId}) bnb
left outer join 
(select uid
	, gender
	, case when birthday is null then '未知'
	  when (birthday = 'unknown' or birthday = '未知') then '未知'
      when birthday < '1970-00-00' then '60s'
      when birthday < '1980-00-00' then '70s'
      when birthday < '1990-00-00' then '80s'
      when birthday < '2000-00-00' then '90s'
      when birthday >= '2000-00-00' then '00s'
      else '未知' end as birth
 from dw_bbzdb.members 
where d=${hiveconf:calcDay}) mem on lower(bnb.uid) = lower(mem.uid) 
left outer join 
(select uid
	,get_json_object(userattributes, '$.currentresidentplace') as home
from olap_mobdb.userattributes_tag) tag on lower(bnb.uid)=lower(tag.uid)


--------------------------------------------------------------------
-- 获取某个城市的经纬度
--------------------------------------------------------------------
set calcDay=from_unixtime(unix_timestamp(),'yyyy-MM-dd');
set cityId='32'; 
select bs.longitude
	,bs.latitude
from 
(select spaceid 
from ods_htl_groupwormholedb.bnb_space_address
where d = ${hiveconf:calcDay}
	and cityid=${hiveconf:cityId}
order by rand()
limit 1200) bsa
inner join 
(select spaceid
 	, latitude
 	, longitude
from ods_htl_groupwormholedb.bnb_space
where d = ${hiveconf:calcDay}) bs on bsa.spaceid = bs.spaceid


--------------------------------------------------------------------
--- 通过cid反补uid
--------------------------------------------------------------------
select
	pv.d
	, us.uid
from
(select distinct d
		, clientcode
	from bnb_hive_db.bnb_pageview
	where d='2018-01-02' and uid is null) pv
left outer join
(select input as cid
	, output as uid
	, max(relation)
from dw_mobdb.user_database_encryption
where category='cid-uid'
 group by input, output
) us on lower(pv.clientcode) = lower(us.cid)
where us.uid is not null

select productid, max(num)
from(select productid, row_number() over(partition by productid order by ordertime desc) num
from bnb_hive_db.bnb_orderinfo)


set cityId='32'; 
select tc.d
	, tc. uid
from 
(select distinct d, uid from bnb_hive_db.bnb_tracelog
where d>='2017-12-01' 
	and d<='2017-12-30'
	and get_json_object(value, '$.cityid') = ${hiveconf:cityId}) tc
inner join
(select distinct d, uid from bnb_hive_db.bnb_pageview 
where d>='2017-12-01' 
	and d<='2017-12-30') pv on tc.d=pv.d and lower(tc.uid) = lower(pv.uid)
left outer join
(select distinct ordertime as d, uid from bnb_hive_db.bnb_orderinfo
where d='2018-01-11'
	and ordertime >='2017-12-01' 
	and ordertime <='2017-12-30') oi on tc.d=oi.d and lower(tc.uid)=lower(oi.uid)
where oi.uid is null
