select d, pageid, count(distinct vid) as num
from dw_ubtdb.pageview
where d >'2018-04-01'
	and pageid in('102901' -- 客栈民宿
	  ,'10320606077' -- 海外民宿
	  ,'102801')  -- 途家公寓
group by d, pageid


------------------------------------
-- 民宿客栈的转换
set calcDay= '2018-04-01';
select home.d
  , count (distinct home.vid) as `首页UV`
  , count (distinct list.vid) as `列表UV`
  , count (distinct detail.vid) as `详情页UV`
  , count (distinct fill.vid) as `填写页UV`
from
(select distinct d
  , vid
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '102901') home
left outer join
(select distinct d
  , vid
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '102902'
  and prevpageid = '102901') list on home.d = list.d and home.vid = list.vid
left outer join
(select distinct d
  , vid
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '102906'
  and prevpageid in ('102902')) detail on home.d = detail.d and home.vid = detail.vid
left outer join
(select distinct d
  , vid
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '102908'
  and prevpageid = '102906') fill on home.d = fill.d and home.vid = fill.vid
group by home.d


------------------------------------
-- 海外民宿的转换
set calcDay= '2018-04-01';
select home.d
  , count (distinct home.vid) as `首页UV`
  , count (distinct list.vid) as `列表UV`
  , count (distinct detail.vid) as `详情页UV`
  , count (distinct fill.vid) as `填写页UV`
from
(select distinct d
  , vid
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '10320606077') home
left outer join
(select distinct d
  , vid
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '600004093'
  and prevpageid = '10320606077') list on home.d = list.d and home.vid = list.vid
left outer join
(select distinct d
  , vid
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '10320606078'
  and prevpageid in ('600004093')) detail on home.d = detail.d and home.vid = detail.vid
left outer join
(select distinct d
  , vid
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '102105'
  and prevpageid = '10320606078') fill on home.d = fill.d and home.vid = fill.vid
group by home.d

select home.d
  , home.uv as `首页UV`
  , list.uv as `列表UV`
  , detail.uv as `详情页UV`
  , fill.uv as `填写页UV`
  , concat(cast(100*((list.uv)/home.uv) as decimal(5,2)),'%') as `S2L`
  , concat(cast(100*((detail.uv)/list.uv) as decimal(5,2)),'%') as `L2D`
  , concat(cast(100*((fill.uv)/detail.uv) as decimal(5,2)),'%') as `D2B`
from
(select d
  , count(distinct vid) as uv
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '10320606077'
group by d) home
join
(select d
  , count(distinct vid) as uv
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '600004093'
  and prevpageid = '10320606077'
group by d) list on home.d = list.d
join
(select d
  , count(distinct vid) as uv
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '10320606078'
  and prevpageid = '600004093'
group by d) detail on home.d = detail.d
join
(select d
  , count(distinct vid) as uv
from dw_ubtdb.pageview
where d >= ${hiveconf:calcDay}
  and pageid = '102105'
  and prevpageid = '10320606078'
group by d) fill on home.d = fill.d