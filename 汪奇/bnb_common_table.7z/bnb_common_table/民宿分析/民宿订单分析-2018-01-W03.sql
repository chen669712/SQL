
-------------------------------------------------------------------
-- 用户时间分布
-------------------------------------------------------------------
-- 只能用Hive跑
use bnb_hive_db;
drop table tmp_wq_tracelog_time;
create table tmp_wq_tracelog_time as
select d
	,uid
	,ts
	,from_unixtime(cast((cast(ts as bigint)/1000)as bigint), 'yyyy-MM-dd HH:mm:ss') as t
	,hour(from_unixtime(cast((cast(ts as bigint)/1000)as bigint), 'yyyy-MM-dd HH:mm:ss')) as h
	,key
	,value
	,pageid
from bnb_tracelog
where d>='2018-01-01'
	and d<'2018-03-01'

use bnb_hive_db;
select d, h, count(distinct uid) as users
from (
  select d
    ,uid
    ,ts
    ,from_unixtime(cast((cast(ts as bigint)/1000)as bigint), 'yyyy-MM-dd HH:mm:ss') as t
    ,hour(from_unixtime(cast((cast(ts as bigint)/1000)as bigint), 'yyyy-MM-dd HH:mm:ss')) as h
    ,key
    ,value
  	,pageid
  from bnb_tracelog
  where d>='2018-01-01'
    and d<'2018-03-01'
) group by d, h





-------------------------------------------------------------------
-- 用户下单订单时间分布
-------------------------------------------------------------------
use bnb_hive_db;
drop table tmp_wq_order_time;
create table tmp_wq_order_time as
select orderid
	, to_date(ordertime) as d
	, hour(ordertime) as h
	, datediff( to_date(checkin), to_date(ordertime)) as gap
	, uid
	, days
	, cityid
	, productid
    , source
from bnb_orderinfo
where d='2018-03-04'
	and ordertime >='2018-01-01'
	and ordertime <'2018-03-01'
  and orderstatus in('100', '10', 'P','S');  -- 成交单&正在处理的订单


-----订单起订时间分布
use bnb_hive_db;
select d
	, case when gap > '15' then '16'
		else gap end as gap
	, count(distinct orderid) as ois
from tmp_wq_order_time group by d, gap;


-----订单起订时间和城市分布
use bnb_hive_db;
select d
	, case when gap > '15' then '16'
      when (gap > '5' and gap < '16') then '3'
      else gap end as time
	, case when days > 5 then 6
      else days end as day
	, cityid
	, count(distinct orderid) as ois
from tmp_wq_order_time
group by d
  , gap
  , days
  , cityid;



---获取城市名
select cityid, cityname from ods_htl_groupwormholedb.bnb_city 
where cityid in('28','25','1','43','2','4','32','17','37','12','10','5','30','477','14','36','34','206','3','31')
and d='2018-01-17'

-----------------------------------------------------------------------------------
-- 下单人群分析
-----------------------------------------------------------------------------------
use bnb_hive_db;
select oi.uid
  ,get_json_object(ui.userattributes, '$.birth') as birthday
  ,case when get_json_object(ui.userattributes, '$.birth') is null then '未知'
      when get_json_object(ui.userattributes, '$.birth') = 'unknown' then '未知'
      when get_json_object(ui.userattributes, '$.birth') = '未知' then '未知'
      when get_json_object(ui.userattributes, '$.birth') < '1970-00-00' then '60s'
      when get_json_object(ui.userattributes, '$.birth') < '1980-00-00' then '70s'
      when get_json_object(ui.userattributes, '$.birth') < '1990-00-00' then '80s'
      when get_json_object(ui.userattributes, '$.birth') < '2000-00-00' then '90s'
      when get_json_object(ui.userattributes, '$.birth') >= '2000-00-00' then '00s'
      else '未知' end as birth
  ,get_json_object(ui.userattributes, '$.currentresidentplace') as home
  ,get_json_object(ui.userattributes, '$.gender') as gender
from (
  select distinct uid 
  from bnb_orderinfo
  where d = '2018-01-17'
  and ordertime >='2017-12-01' 
	and ordertime <'2017-12-16') oi
  left outer join 
  (select uid
    ,userattributes
  from olap_mobdb.userattributes_tag) ui on lower(oi.uid)=lower(ui.uid);
