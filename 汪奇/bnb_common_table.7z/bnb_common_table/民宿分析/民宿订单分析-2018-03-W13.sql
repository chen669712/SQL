
set beginDay='2018-03-23';
set endDay='2018-03-30';

use bnb_hive_db;
select d
	,count(distinct clientcode) as num
from bnb_pageview
where pagecode = '600003560'
  and d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
group by d;



use bnb_hive_db;
select d
  , count(distinct cid) as num
from bnb_tracelog
where d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
  and pageid = '600003560'
  and key in ('o_bnb_inn_2nd_home_app')
group by d;

use bnb_hive_db;
select d
  , key
  , count(distinct cid) as num
from bnb_tracelog
where d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
  and pageid = '600003560'
  and key in ('c_bnb_inn_home_recom_app', 'c_bnb_inn_home_hot_app')
group by d, key;





use bnb_hive_db;
select to_date(ordertime) as d
  , count(distinct orderid)
from bnb_orderinfo
where d='2018-03-26'
  and visitsource='203'  ---猜你喜欢直接订单
group by to_date(ordertime)


use bnb_hive_db;
select
from bnb_pageview
where pagecode in ('10320676558')



set beginDay='2018-03-23';
set endDay='2018-03-27';

use bnb_hive_db;
select d
	,count(distinct clientcode) as num
from bnb_pageview
where pagecode = '600003563'
  and prepagecode = '10320676558'
  and d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
group by d;


------------------------------------------
use bnb_hive_db;
select productid
  , count(distinct orderid) as num
from bnb_orderinfo
where d ='2018-03-25'
  and orderstatus = '100'
  and source in ('100', '100-1')
group by productid

select oi.productid
  , oi.oinum
  , co.conum
from
(select distinct productid
  , count(distinct orderid) oinum
from bnb_orderinfo
where d ='2018-03-25'
  and orderstatus = '100'
  and source in ('100', '100-1')
group by productid) oi
left join
(select productid
  , count(distinct commentid) as conum
from ods_htl_groupwormholedb.bnb_comment
where isaudit='0'
  and d='2018-03-25'
group by productid) as co on oi.productid = co.productid



