---- step1 订单的目的地城市及订单数
use bnb_hive_db;
drop table if exists tmp_wq_bnb_order_city;
create table tmp_wq_bnb_order_city as
select oi.d
  , oi.uid
  , city.cityname
  , oi.orderid
  , oi.ots
  , oi.times
from (select to_date(ordertime) as d  --通过民宿宫格生成的订单
    , uid
    , orderid
    , cityid
    , unix_timestamp(ordertime) as ots
    , ordertime as times
  from bnb_orderinfo
  where d = '2018-03-14'
    and to_date(ordertime) >='2018-01-01'
    and to_date(ordertime) <'2018-03-14'
    and uid not in ('$seller-agent')
    and source = '100') oi
inner join
(select cityid
    , cityname
  from ods_htl_groupwormholedb.bnb_city
  where d = '2018-03-14') city on oi.cityid = city.cityid;

----每天，每个城市的订单数
use bnb_hive_db;
select d
  , count(distinct uid) as num
from tmp_wq_bnb_order_city
group by d;

---- step2 通过Trace获取每个用户所在城市及时间段
use bnb_hive_db;
drop table if exists tmp_wq_bnb_trace_city;
create table tmp_wq_bnb_trace_city as
select d
    , uid
    , cityname
    , min(from_unixtime(ts/1000, 'yyyy-MM-dd HH:mm:ss')) as minpts
    , max(from_unixtime(ts/1000, 'yyyy-MM-dd HH:mm:ss')) as maxpts
from bnb_tracelog
where d >= '2018-03-08'
  and d< '2018-03-14'
  and cityname not in('中国')
  and uid is not null
  and uid not in ('')
group by d
    , uid
    , cityname;


---Step3 取出当天下单用户的匹配关系
use bnb_hive_db;
drop table if exists tmp_wq_bnb_oi_pv_city;
create table tmp_wq_bnb_oi_pv_city as
select oi.d
  , oi.uid
  , oi.cityname
  , oi. orderid
  , oi.ots
  , oi.times
  , pv.maxpts
  , pv.minpts
  , case when oi.times <= pv.maxpts and oi.times >= pv.minpts and oi.cityname=pv.cityname then 'y'
    else 'n' end as flag
from tmp_wq_bnb_order_city oi
left outer join tmp_wq_bnb_trace_city pv on oi.d=pv.d and oi.uid=pv.uid
where pv.cityname is not null;

---Step4 计算占比
use bnb_hive_db;
select d
  , count(distinct uid) as num
from tmp_wq_bnb_oi_pv_city
where flag = 'y'
group by d;

------------------------------------------------------------------------------
-- 评论页分析
------------------------------------------------------------------------------
--- 点评页的曝光数据
select d
	,count(distinct clientcode) as nums
from dw_mobdb.factmbpageview
where pagecode = '10320662859'
  and d>='2018-03-07'
  and d<'2018-03-13'
group by d

select d
  , count(distinct newvalue.data['env_clientcode']) as nums
from dw_mobdb.factmbtracelog_hybrid
where d>='2018-03-07'
  and d<'2018-03-13'
  and pageid = '10320662859'
  and key ='o_bnb_inn_comment_app'
group by d;

use bnb_hive_db;
drop table if exists tmp_wq_bnb_comment_trace;
create table  tmp_wq_bnb_comment_trace as
select d
  , uid
  , newvalue.data['env_clientcode'] as cid
  , get_json_object(value, '$.tag') as tag
  , regexp_extract(get_json_object(value, '$.tag'), '[\\u4e00-\\u9fa5]+|\\d+', 0) as tags
from dw_mobdb.factmbtracelog_hybrid
where d>='2018-03-07'
  and d<'2018-03-13'
  and pageid = '10320662859'
  and key ='o_bnb_inn_comment_filter_app';

use bnb_hive_db;
select d
	, tags
	, count(distinct cid) as nums
from tmp_wq_bnb_comment_trace
group by d, tags

use bnb_hive_db;
select count(distinct cid) as nums
from tmp_wq_bnb_comment_trace
where d > '2018-03-07'
  and tags not in ('', '全部')


use bnb_hive_db;
select tags, count(distinct cid) as nums
from tmp_wq_bnb_comment_trace
where d > '2018-03-07'
  and tags not in ('', '全部')
group by tags
