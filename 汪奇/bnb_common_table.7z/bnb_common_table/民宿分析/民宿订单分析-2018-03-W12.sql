---Online的客栈数据分析
select d
  pageid
  , count(distinct vid) as num
from dw_ubtdb.factpageview
where pageid in('102901'  --客栈首页
  , '102001'  --酒店首页
  , '10320606077'  --海外民宿首页
  , '100101991'  --大首页
  )
	and d >= '2018-01-01'
group by d, pageid;



---从产品详情页进入地图页的占比
use bnb_hive_db;
select d
	,pagecode
    ,count(distinct clientcode) as num
from bnb_pageview
where d>='2018-01-01'
  and pagecode in( '10320671062', '600003564')
group by d, pagecode



