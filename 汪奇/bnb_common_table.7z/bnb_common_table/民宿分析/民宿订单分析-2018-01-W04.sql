--- 新注册用户再回访率(1~30)
--- 流量分析
--- 首页分析


---------------------------------------------------------------------------------------
-- 用户再回访
---------------------------------------------------------------------------------------
-- 取出日活用户
use bnb_hive_db;
set calcDay= '2018-01-22';
drop table tmp_wq_signup_users;
create table tmp_wq_signup_users as
select bnb.d 
	, bnb.uid
	, case when mem.signupdate is not null then 'y'
		else 'n' end as new_user
	, unix_timestamp(bnb.d, 'yyyy-MM-dd') as utime
from 
(select distinct d, uid
from bnb_pageview
where d >= '2017-12-15'
 and d<'2018-01-16') bnb
left outer join
(select uid
	,to_date(signupdate) as signupdate  ----用户注册时间
from dw_bbzdb.members 
where d=${hiveconf:calcDay}) mem on lower(bnb.uid) = lower(mem.uid) and bnb.d=mem.signupdate

use bnb_hive_db;
set calcDay= '2018-01-22';
drop table  if exists tmp_wq_bnb_users;
create table tmp_wq_bnb_users as
select mem.*
	,case when (oi.uid is not null and mem.utime > oi.min_time) then 'y' 
	 else 'n' end as has_order 
	,oi.min_time
from tmp_wq_signup_users mem
left outer join
(select uid
	, min(unix_timestamp(ordertime, 'yyyy-MM-dd')) as min_time
from bnb_orderinfo
where d = ${hiveconf:calcDay}
	and to_date(ordertime) <'2018-01-16'
group by uid) oi on lower(mem.uid) = lower(oi.uid);





--取基数
use bnb_hive_db;
select d, new_user, has_order, count(distinct uid) 
from bnb_hive_db.tmp_wq_bnb_users
group by d, new_user, has_order


-- GAP 1
set timeGap= 1;
use bnb_hive_db;
select bnb.d
	, bnb.new_user
	, bnb.has_order
	, count(distinct bnb.uid)
from
(select distinct d
	, new_user
	, has_order
	, uid 
from bnb_hive_db.tmp_wq_bnb_users) bnb
inner join(
select distinct d
	, uid
	, unix_timestamp(d, 'yyyy-MM-dd') as utime 
from bnb_pageview
where d > '2017-12-15'
 and d<'2018-01-24') pv on pv.d = date_add(bnb.d, ${hiveconf:timeGap}) and bnb.uid = pv.uid
group by bnb.d
	, bnb.new_user
	, bnb.has_order







---------------------------------------------------------------------------------------
-- 首页分析
---------------------------------------------------------------------------------------

--- 进入首页的用户集
use bnb_hive_db;
select d, count(distinct uid)
from bnb_pageview
where pagecode='600003560'   -- 页面首页
	and d>'2018-01-18'
group by d

--- 二屏的曝光用户
use bnb_hive_db;
select d
	, count(distinct uid) as users
from bnb_tracelog
where key = 'o_bnb_inn_2nd_home_app'
	and d >='2018-01-18'
group by d


--- 热门城市点击
use bnb_hive_db;
select d
	, count(distinct uid) as users
from bnb_tracelog
where key = 'c_bnb_inn_home_hot_app'
	and d >='2018-01-18'
group by d


--- 不同类型产品曝光点击
use bnb_hive_db;
select d
	, source
	, type
	, count(distinct uid) as users
from bnb_product_trace
where d >= '2018-01-18'
group by d, source, type


--- 途家豪宅的点击
use bnb_hive_db;
select d
	, count(distinct uid) as users
from bnb_tracelog
where key = 'c_bnb_inn_banner_app'
	and get_json_object(value, '$.source') = '101'
	and d >='2018-01-18'
group by d


--- 搜索的点击
use bnb_hive_db;
select d
	, count(distinct uid) as users
from bnb_tracelog
where key in ('100641','100642', 'bnb_inn_list_app_basic', 'bnb_inn_list_h5_basic')
	and pageid='600003560'
	and d >='2018-01-18'
group by d


--- 搜索模块的点击
use bnb_hive_db;
drop table tmp_wq_bnb_user_city_trace;
create table tmp_wq_bnb_user_city_trace as
select d
	, get_json_object(value, '$.source')  as source
	, get_json_object(value, '$.value') as value
	, uid
	, pageid
from bnb_tracelog
where key = 'c_bnb_inn_home_filter_app'
	and d >='2018-01-18'

use bnb_hive_db;
select d
	, source
	, count(distinct uid)
from bnb_hive_db.tmp_wq_bnb_user_city_trace
group by d, source


--- 搜索目的地的变化
-- '上海','三亚','北京','厦门','成都','广州','重庆','杭州'
-- '西安','深圳','丽江','南京','大理市','昆明','哈尔滨'
-- '武汉','苏州','北海','长沙','海口','珠海','香港'
-- '天津','青岛','桐乡','郑州','福州','桂林','宁波','沈阳'
use bnb_hive_db;
drop table tmp_wq_bnb_user_city_search;
create table tmp_wq_bnb_user_city_search as
select d
	, uid
	, case when get_json_object(value, '$.cityid') in ('189','1','206','28','36','258','32','33','5'
			,'42','17','34','37','12','375','7','43','2','30','451','14','3','580','477'
			,'10','25','58','559','4','31') then get_json_object(value, '$.cityid')
		else '其它' end as city
from bnb_tracelog
where key in ('100641','100642', 'bnb_inn_list_app_basic', 'bnb_inn_list_h5_basic')
	and pageid='600003560'
	and d >='2018-01-01'


select *
from bnb_tracelog
where key = 'o_bnb_inn_detail_similar_app'
	and get_json_object(value, '$.source') is null
	and d ='2018-01-25'	



use bnb_hive_db;
select to_date(ordertime) as d
	, source
	, visitsource
	, sellerid
	, agent
	, count(orderId) ois
from bnb_orderinfo
where d= '2018-01-25'
	and to_date(ordertime) > '2018-01-10'
group by to_date(ordertime)
	, source
	, visitsource
	, sellerid
	, agent


use bnb_hive_db;
select A.orderId 
from 
(select orderId 
from ods_htl_bnborderdb.order_header_v2
where d= '2018-01-26'
 	and to_date(createdTime)='2018-01-25'
 	and paystatusid IN ( 12, 20, 22, 23 )
	and visitSource = 20) A
left outer join
(select orderId
from bnb_orderinfo
where source='100'
	and visitsource = '20'
	and d= '2018-01-25'
	and to_date(ordertime) = '2018-01-25') B on A.orderId = B.orderId
where B.orderId is null
	