
---列表页的分析
use bnb_hive_db;
select d
	, count(distinct uid) nums
from bnb_tracelog
where key = 'o_bnb_inn_2nd_list_app'
	and d >= '2018-03-01'
	and d<'2018-03-13'
group by d


use bnb_hive_db;
drop table tmp_wq_filter_parsing;
create table tmp_wq_filter_parsing as
select log.d 
	, log.uid
	, log.vid
	, log.value
	, log.pageid
	, info.*
	, filter.* 
	, position.*
from bnb_tracelog log
lateral view json_tuple(get_json_object(log.value, '$'), 'cityid'
		, 'result'
		, 'checkin'
		, 'checkout'
		, 'keyword'
		, 'priceMin'
		, 'priceMax'
		, 'hotelLevel'
		, 'sort') info as cityid
		, result
		, checkin
		, checkout
		, keyword
		, priceMin
		, priceMax
		, hotelLevel
		, sorts
lateral view json_tuple(get_json_object(log.value, '$.filter'), 'people'
		, 'type'
		, 'labelid'
		, 'facilityid') filter as people
		, type
		, label
		, facility
lateral view json_tuple(get_json_object(log.value, '$.position'), 'business'
		, 'viewpoint'
		, 'metro'
		, 'university'
		, 'hospital'
		, 'district'
		, 'station'
		, 'distance'
		, 'other') position as business
		, viewpoint
		, metro
		, university
		, hospital
		, district
		, station
		, distance
		, other
where log.key = 'c_bnb_inn_list_filter_app'
	and log.d >= '2018-03-01'
	and log.d<'2018-03-13'






-- filter的点击
use bnb_hive_db;
select d
	,count(distinct uid) user
from tmp_wq_filter_parsing
where hotelLevel is not null
		or people not in ('-1')
		or type not in ('-1')
		or length(label) > 2
		or length(facility) > 2
group by d


-- position的点击
use bnb_hive_db;
select d
	,count(distinct uid) user
from tmp_wq_filter_parsing
where business not in ('-1')
		or viewpoint not in ('')
		or metro not in ('')
		or university not in ('')
		or hospital not in ('')
		or district not in ('-1')
		or station not in ('')
		or distance not in ('0')
		or other not in ('')
group by d


--price的点击
use bnb_hive_db;
select d
	,count(distinct uid) user
from tmp_wq_filter_parsing
where priceMax not in ('0')
group by d

--排序的点击
use bnb_hive_db;
select d
	, count(distinct uid) as num
from tmp_wq_filter_parsing
where sorts is not null
group by d


select d
	,count(distinct uid) 
from dw_mobdb.factmbpageview
where pagecode = '600003563'
group by d


select d
	,count(distinct uid) user
from tmp_wq_filter_parsing
where keyword not in ('')
group by d 


select d
	, count(distinct uid) user
from bnb_tracelog
where key = 'c_bnb_inn_list_map_app'
	and d>='2018-02-01'
group by d



--- 详情页的分析
use bnb_hive_db;
select d
	, get_json_object(value, '$.type') as type
	, count(distinct uid)
from bnb_tracelog
where key ='c_bnb_inn_detail_collect_app'
	and pageid = '600003564'
	and d >= '2018-02-01'
group by d
	, get_json_object(value, '$.type')


select d
	, get_json_object(value, '$.source') as source
	, count(distinct uid)
from bnb_tracelog
where key ='c_bnb_inn_detail_operate_app'
	and pageid = '600003564'
	and d >= '2018-02-01'
group by d
	, get_json_object(value, '$.source')


select d
	, count(distinct uid)
from bnb_tracelog
where key in ('bnb_inn_booking_app_basic', '100645')
	and d >= '2018-02-01'
group by d

select d
	,count(distinct uid) 
from dw_mobdb.factmbpageview
where pagecode = '600003564'
	and d >= '2018-02-01'
group by d


--- 订单填写页
select d
	, get_json_object(value, '$.source') as source
	, count(distinct uid)
from bnb_tracelog
where key ='c_bnb_inn_order_filling_operate_app'
	and pageid = '600003570'
	and d >= '2018-02-01'
group by d
	, get_json_object(value, '$.source')


select d
	,count(distinct uid) 
from dw_mobdb.factmbpageview
where pagecode = '600003570'
	and d >= '2018-02-01'
group by d	

select d
	, count(distinct uid)
from bnb_tracelog
where key in ('bnb_inn_order_app_basic', '100647')
	and d >= '2018-02-01'
group by d


--- 订单详情页
use bnb_hive_db;
select d
	, get_json_object(value, '$.source') as source
	, count(distinct uid)
from bnb_tracelog
where key ='c_bnb_inn_order_detail_operate_app'
	and pageid = '600003641'
	and d >= '2018-02-01'
group by d
	, get_json_object(value, '$.source')


select d
	,count(distinct uid) 
from dw_mobdb.factmbpageview
where pagecode = '600003641'
	and d >= '2018-02-01'
group by d


use bnb_hive_db;
select
  oi.*
from(
SELECT to_date(ordertime) as d
  , uid
  , unix_timestamp(ordertime) as ts
  , row_number() over (partition by uid order by ordertime) as times
from bnb_orderinfo
where d = '2018-02-28'
  and uid not in ('$seller-agent')
  and orderstatus in('100', '10', 'P','S')) oi
where oi.times >= 2



use bnb_hive_db;
select count(distinct oi.uid)
from(
SELECT to_date(ordertime) as d
  , uid
  , unix_timestamp(ordertime) as ts
  , dense_rank() over (partition by uid order by to_date(ordertime)) as times
from bnb_orderinfo
where d = '2018-02-28'
  and uid not in ('$seller-agent')
  and to_date(ordertime) < '2018-03-01'
  and orderstatus in('100', 'S')) oi  -- 100/S 订单完成， 10/P 处理中的订单
-- where oi.times >= 2
group by d, uid



use bnb_hive_db;
drop table if exists tmp_wq_oi_info;
create table tmp_wq_oi_info as
SELECT to_date(ordertime) as d
  , uid
  , unix_timestamp(ordertime) as ts
  , dense_rank() over (partition by uid order by to_date(ordertime)) as times
from bnb_orderinfo
where d = '2018-02-28'
  and to_date(ordertime) < '2018-03-01'
  and uid not in ('$seller-agent')
  and orderstatus in('100', '10', 'P','S')


---- 7月~9月人群再次复购时间分布
use bnb_hive_db;
select datediff(oi.d, info.d) as gap
  , count(distinct oi.uid)
from
(select *
  from tmp_wq_oi_info
  where times = 2) oi
inner join
(select *
 from tmp_wq_oi_info
 where times = 1
	and d < '2017-10-01') info on oi.uid = info.uid
group by gap



use bnb_hive_db;
select oi.times,
  , count(distinct oi.uid)
from
(select uid
    , max(times) as times
  from tmp_wq_oi_info
  where times >= 2
  group by uid) oi
inner join
(select *
 from tmp_wq_oi_info
 where times = 1
	and d < '2017-10-01') info on oi.uid = info.uid
group by oi.times

