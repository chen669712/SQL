------------------------------------------------
-- 设置取数时间范围
------------------------------------------------
set beginDay='2017-12-01';
set endDay='2017-12-24';

------------------------------------------------
-- 选择通过首页进入民宿首页的UV
------------------------------------------------
use bnb_hive_db;
drop table if exists tmp_wq_pv_raw_all;
create table tmp_wq_pv_raw_all as 
select d
     , vid
     , sid
     , pvid 
     , cityid
     , cityname
     , lower(pagecode) as pagecode
     , lower(prepagecode) as prepagecode
     , substring(starttime,1,19) as starttime
     , clientcode
     , lower(uid) as uid
     , lower(category) as category
from dw_mobdb.factmbpageview
where d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
  and uid is not null
  and clientcode is not null
  and clientcode not in ('','00000000000000000000');

drop table tmp_wq_pv_bnb_raw;
create table tmp_wq_pv_bnb_raw as 
select pv.*
from tmp_wq_pv_raw_all pv
left outer join
(select distinct d, uid
  from tmp_wq_pv_raw_all
  where  pagecode='600003560'
    and prepagecode = 'home') bnb on bnb.d=pv.d and bnb.uid = pv.uid 
where bnb.uid is not null;



--------------------------------------------------------
--- 获取民宿过去半年的订单
---------------------------------------------------------
--use bnb_hive_db;
set calcDay=from_unixtime(unix_timestamp(),'yyyy-MM-dd');
drop table  if exists tmp_wq_bnb_orders;
create table tmp_wq_bnb_orders as
SELECT oh.d
  , unix_timestamp(oh.d) as utime
  , oh.uid
  , oh.orderid
  , oi.vendorid
FROM
(SELECT to_date(createdtime) as d   -- 下单时间
  ,uid                              -- 下单用户UID 分销模式为固定值:$seller-agent
  ,orderId                          -- 携程订单ID
FROM ods_htl_bnborderdb.order_header_v2
WHERE d = ${hiveconf:calcDay}
    AND uid not in('$seller-agent')
    AND visitsource not in (13,14,18) 
  AND to_date(createdTime) >='2017-06-01'
  AND to_date(createdTime) < '2017-12-24') oh
INNER JOIN
(SELECT orderitemid
  ,orderid
  ,vendorid
FROM ods_htl_bnborderdb.order_item 
WHERE d = ${hiveconf:calcDay}
  AND (statusid like '12%' 
       OR statusid like '20%' 
       OR statusid like '22%' 
       OR statusid like '23%'))oi ON oh.orderid=oi.orderid
INNER JOIN
(SELECT d 
  ,orderitemid
FROM ods_htl_bnborderdb.order_item_space
WHERE d = ${hiveconf:calcDay}) ois ON oi.orderitemid = ois.orderitemid
group by oh.d
  , oh.uid
  , oh.orderid
  , oi.vendorid;

------------------------------------------------
-- 分析民宿人群的相关属性
------------------------------------------------
---1. 绑定人口属性
set calcDay=from_unixtime(unix_timestamp(),'yyyy-MM-dd');
drop table  if exists tmp_wq_bnb_all_members;
create table tmp_wq_bnb_all_members as
select bnb.d
	, bnb.uid
	, unix_timestamp(bnb.d, 'yyyy-MM-dd') as utime
	, mem.gender
	, mem.birth
	, mem.signupdate
	, tag.home
from 
(select distinct d
	,uid
from tmp_wq_pv_bnb_raw) bnb
left outer join 
(select uid
	, to_date(signupdate) as signupdate  ----用户注册时间
	, gender
	, case when birthday is null then '未知'
	  when (birthday = 'unknown' or birthday = '未知') then '未知'
      when birthday < '1970-00-00' then '60s'
      when birthday < '1980-00-00' then '70s'
      when birthday < '1990-00-00' then '80s'
      when birthday < '2000-00-00' then '90s'
      when birthday >= '2000-00-00' then '00s'
      else '未知' end as birth
 from dw_bbzdb.members 
where d=${hiveconf:calcDay}) mem on bnb.uid = mem.uid and bnb.d=mem.signupdate
left outer join 
(select uid
	,get_json_object(userattributes, '$.currentresidentplace') as home
from olap_mobdb.userattributes_tag) tag on lower(tag.uid)=bnb.uid


---2. 绑定订单信息
use bnb_hive_db;
drop table  if exists tmp_wq_bnb_all_users;
create table tmp_wq_bnb_all_users as
select mem.*
	,case when (oi.uid is not null and mem.utime > oi.min_time) then 'y' 
	 else 'n' end as orderstatus 
from tmp_wq_bnb_all_members mem
left outer join
(select uid
	, min(utime) as min_time
	, max(utime) as max_time
from tmp_wq_bnb_orders
group by uid) oi on lower(mem.uid) = lower(oi.uid);



------------------------------------------------
-- 分析北京相关信息
------------------------------------------------
drop table if exists tmp_wq_bnb_trace_raw_bj;
create table tmp_wq_bnb_trace_raw_bj as
SELECT d
  , uid
--  , get_json_object(value, '$.cityid') AS cityid
  , get_json_object(value, '$.productid') AS productid
  , key
FROM dw_mobdb.factmbtracelog_hybrid
WHERE d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
  and uid is not null
  and get_json_object(value, '$.cityid') = '1'
  and key in('100641','100642'  -- 点击搜索
      ,'100643','100644'  -- 点击某个产品
      ,'100645','100646'  -- 立刻预定
      ,'100647','100648')  -- 订单提交
group by d
  , key
  , uid
  , get_json_object(value, '$.productid');


use bnb_hive_db;
drop table if exists tmp_wq_bnb_trace_app_raw_bj;
create table tmp_wq_bnb_trace_app_raw_bj as
select ubt.* 
from tmp_wq_bnb_trace_raw_bj ubt
left outer join(
  select distinct d, uid
  from tmp_wq_bnbpv_raw) pv on ubt.d = pv.d AND lower(ubt.uid) = lower(pv.uid)
where pv.uid is not null;


-- use bnb_hive_db;
drop table if exists tmp_wq_bnb_htlorder_bj;
create table tmp_wq_bnb_htlorder_bj as 
select to_date(orderdate) as d
    ,uid 
    ,acity -- 目的地城市
    ,amount
    ,realamount
    ,realquantity
    ,mobilephone
    ,productid
    ,orderid
    ,(amount/realquantity) as price
    ,max(unix_timestamp(substring(orderdate,1,19))) as unix_order
from olap_Mobdb.olapmbwirelessorder
where channel is not null 
  and to_date(orderdate)>=${hiveconf:beginDay}
  and to_date(orderdate)<=${hiveconf:endDay}
  and producttype='H'
  and acity='1'    -- 1 北京
  and subproducttype = 'N'
--  and subproducttype IN ('I','N');   --- I 国际酒店，N国内酒店
group by to_date(orderdate)
    ,uid 
    ,acity -- 目的地城市
    ,amount
    ,realamount
    ,realquantity
    ,mobilephone
    ,productid
    ,orderid
    ,(amount/realquantity);

-- use bnb_hive_db;
set calcDay=from_unixtime(unix_timestamp(),'yyyy-MM-dd');
drop table if exists tmp_wq_bnb_innorder_bj;
create table tmp_wq_bnb_innorder_bj as
SELECT oh.d
  ,oh.uid
  ,oh.orderid
  ,oh.salesChannel
--  ,oh.visitsource
--  ,oi.orderitemid
  ,oi.productid
--  ,oi.statusid
  ,oi.saleamount
  ,oi.vendorid
  ,ois.checkin
  ,ois.checkout
  ,datediff(to_date(ois.checkout), to_date(ois.checkin)) as days
  ,ois.cityid
  ,ois.childquantity
FROM
(SELECT to_date(createdtime) as d   -- 下单时间
  ,uid                              -- 下单用户UID 分销模式为固定值:$seller-agent
  ,orderId                          -- 携程订单ID
  ,salesChannel                     -- 订单的销售渠道:1.携程直销,2分销；
  ,visitsource                      -- 订单内部来源:0.未设置
--  ,terminaltype                     -- 用户下单使用的终端类型：0.未知 ,10.手机APP下单,11.APP H5, 20.PC端
--  ,orderstatusid                    -- 订单状态: 10处理中,20成功,21失败,30已取消,31部分取消
--  ,paystatusid                      -- 订单支付状态:10-待支付 ,11-支付中,12-支付成功,13-支付失败,20-待退款,21-退款中,22-部分退款,23-已退款,24-退款失败
FROM ods_htl_bnborderdb.order_header_v2
WHERE d = ${hiveconf:calcDay}
    AND uid not in('$seller-agent')
    AND visitsource not in (13,14,18) 
  AND to_date(createdTime) >=${hiveconf:beginDay}
  AND to_date(createdTime) <= ${hiveconf:endDay}) oh
INNER JOIN
(SELECT orderitemid
  ,orderid
  ,productid
  ,statusid
  ,saleamount
  ,vendorid
FROM ods_htl_bnborderdb.order_item 
WHERE d = ${hiveconf:calcDay}
  AND (statusid like '12%' 
       OR statusid like '20%' 
       OR statusid like '22%' 
       OR statusid like '23%'))oi ON oh.orderid=oi.orderid
INNER JOIN
(SELECT d 
  ,orderitemid
  ,cityid
  ,checkin
  ,checkout
  ,childquantity
  ,infantquantity
FROM ods_htl_bnborderdb.order_item_space
WHERE d = ${hiveconf:calcDay}
   AND cityid = '1' ) ois ON oi.orderitemid = ois.orderitemid;


use bnb_hive_db;
drop table if exists tmp_wq_bnb_trace_products_bj;
create table tmp_wq_bnb_trace_products_bj as
select ubt.d
  ,ubt.uid
  ,ubt.key
  ,ubt.productid as browser_productid
  ,oi.productid as order_productid
  ,oi.orderid
  ,oi.vendorid
from tmp_wq_bnb_trace_app_raw_bj ubt
left outer join 
( select htl.d
    , htl.uid
    , htl.productid
    , htl.orderid
    , bnb.vendorid
  from tmp_wq_bnb_htlorder_bj htl  -- 过滤掉下过民宿订单用户
  left outer join tmp_wq_bnb_innorder_bj bnb on htl.d = bnb.d and lower(htl.uid) = lower(bnb.uid)
  where bnb.uid is null ) oi on oi.d=ubt.d and lower(oi.uid)=lower(ubt.uid)
where oi.uid is not null


use bnb_hive_db;
select oi.uid
  ,get_json_object(ui.userattributes, '$.birth') as birthday
  ,case when get_json_object(ui.userattributes, '$.birth') is null then '未知'
      when get_json_object(ui.userattributes, '$.birth') = 'unknown' then '未知'
      when get_json_object(ui.userattributes, '$.birth') = '未知' then '未知'
      when get_json_object(ui.userattributes, '$.birth') < '1970-00-00' then '60s'
      when get_json_object(ui.userattributes, '$.birth') < '1980-00-00' then '70s'
      when get_json_object(ui.userattributes, '$.birth') < '1990-00-00' then '80s'
      when get_json_object(ui.userattributes, '$.birth') < '2000-00-00' then '90s'
      when get_json_object(ui.userattributes, '$.birth') >= '2000-00-00' then '00s'
      else '未知' end as birth
  ,get_json_object(ui.userattributes, '$.currentresidentplace') as home
  ,get_json_object(ui.userattributes, '$.gender') as gender
from (
  select distinct uid 
  from tmp_wq_bnb_trace_products_bj
--  where key in ('100645','100646')) oi   ---点击详情页“立刻预定”
--  where key in ('100645','100646')
  ) oi   ---点击列表页某个民宿产品
  left outer join 
  (select uid
    ,userattributes
  from olap_mobdb.userattributes_tag) ui on lower(oi.uid)=lower(ui.uid);


-------------------------------------------------------------------------------
--- 获取酒店产品的经纬度
-------------------------------------------------------------------------------
select oi.order_productid as productid
	,htl.resourcename
	,htl.lon
	,htl.lat
from 
(select distinct order_productid
from bnb_hive_db.tmp_wq_bnb_trace_products_bj) oi
left outer join 
(select hotel
	,masterhotelid 
from dim_htldb.dimhtlhotel)dhtl on oi.order_productid=dhtl.hotel
left outer join 
(select resource
 ,resourcename
 ,lat
 ,lon 
 from ods_htl_ProductDB.Resource_Map
 where d='2017-12-26') htl on dhtl.masterhotelid= htl.resource;



SELECT d
  , uid
--  , get_json_object(value, '$.cityid') AS cityid
  , get_json_object(value, '$.productid') AS productid
  , key
FROM dw_mobdb.factmbtracelog_hybrid
WHERE d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
  and uid is not null
--   and get_json_object(value, '$.cityid') = '1'
  and key in('100643','100644'
      ,'bnb_inn_detail_app_basic','bnb_inn_detail_h5_basic ')
group by d
  , key
  , uid
  , get_json_object(value, '$.productid');