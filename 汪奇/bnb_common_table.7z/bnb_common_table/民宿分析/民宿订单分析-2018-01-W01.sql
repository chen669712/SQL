------------------------------------------------
-- 设置取数时间范围
------------------------------------------------
set beginDay='2017-12-01';
set endDay='2017-12-30';

------------------------------------------------
-- 选择通过首页进入民宿首页的UV
------------------------------------------------
use bnb_hive_db;
drop table if exists tmp_wq_pv_raw_all;
create table tmp_wq_pv_raw_all as 
select d
     , vid
     , sid
     , pvid 
     , cityid
     , cityname
     , lower(pagecode) as pagecode
     , lower(prepagecode) as prepagecode
     , substring(starttime,1,19) as starttime
     , clientcode
     , lower(uid) as uid
     , lower(category) as category
from dw_mobdb.factmbpageview
where d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
  and uid is not null
  and clientcode is not null
  and clientcode not in ('','00000000000000000000');

drop table tmp_wq_pv_bnb_raw;
create table tmp_wq_pv_bnb_raw as 
select pv.*
from
(select distinct d, uid
  from tmp_wq_pv_raw_all
  where  pagecode='600003560'
    and prepagecode = 'home') bnb
left outer join
tmp_wq_pv_raw_all pv on bnb.d=pv.d and bnb.uid = pv.uid 
where pv.uid is not null;


-- 分析一个session内两个页面的承接关系
drop table tmp_wq_bnb_data_detail;
create table tmp_wq_bnb_data_detail as 
select d
     , sid
     , pvid
     , pagecode
     , lead(pagecode,1) over (partition by d,sid,clientcode order by pvid) as next_page
     , starttime
     , lead(starttime,1) over(partition by d,sid,clientcode order by pvid) as next_time
     , category
     , lead(category,1) over (partition by d,sid,clientcode order by pvid) as next_category
     , uid
     , clientcode
from tmp_wq_pv_bnb_raw;



------------------------------------------------
-- 在民宿中有操作行为的UV
------------------------------------------------
drop table if exists tmp_wq_bnb_trace_raw_all;
create table tmp_wq_bnb_trace_raw_all as
SELECT d
  , uid
  , get_json_object(value, '$.cityid') AS cityid
  , get_json_object(value, '$.productid') AS productid
  , key
FROM dw_mobdb.factmbtracelog_hybrid
WHERE d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
  and uid is not null
  and key in('100641','100642'  -- 点击搜索
      ,'100643','100644'  -- 点击某个产品
      ,'100645','100646'  -- 立刻预定
      ,'100647','100648')  -- 订单提交
group by d
  , key
  , uid
  , get_json_object(value, '$.cityid')
  , get_json_object(value, '$.productid');


-- 和通过首页进行的用户进行筛选
use bnb_hive_db;
drop table if exists tmp_wq_bnb_trace_app_raw;
create table tmp_wq_bnb_trace_app_raw as
select ubt.* 
from 
( select distinct d, uid
  from tmp_wq_pv_bnb_raw) pv
left outer join
tmp_wq_bnb_trace_raw_all ubt on ubt.d = pv.d AND lower(ubt.uid) = lower(pv.uid)
where ubt.uid is not null;




---------------------------------------------备份忽略--------------------------------------------------------------------------
---------------------------------------------备份忽略--------------------------------------------------------------------------
---------------------------------------------备份忽略--------------------------------------------------------------------------
select * from bnb_hive_db.tmp_wq_pv_bnb_raw
where pagecode in(
  '600003560' -- 首页
  ,'600003544' -- 搜索页
  ,'600003571'  --订单列表页
  ,'10320655917' --我的页面
  ,'10320655913' --消息列表页面
  ,'10320669958'  --民宿途家豪宅
  ,'10320666866'  --城市选择页
  ,'10320666862'  --浏览历史页
  ,'10320655915'  --消息单聊页面
  
  ,'600003563'  --产品列页表
  ,'10320672009'  --酒店宫格调民宿列表页Hybird

  ,'hotel_inland_detail' --国内酒店详情页
  ,'600003564'  --产品详情页
  ,'600003566'  --房东详情页
  ,'600003567'  --房源详情页  ??
  ,'600003573'  --选择入离店日 ??
  ,'10320657575'  --位置区域完整地址页面

  ,'hotel_inland_order' --国内酒店订单填写页
  ,'600003570'    --订单填写页 (预定流程)
  ,'10320655678'  --价格选择页 (预定流程)
  ,'10320655680'  --入住人选择页 (预定流程)
  ,'10320666870'  --入住人增加页 (预定流程)
  ,'10320666868'  --入住人编辑页 (预定流程)
  ,'10320672475'  --订单填写页开发票增加配送地址 (预定流程)
  ,'10320672463'  --订单填写页开发票页面 (预定流程)

  ,'widget_pay_main' --支付页面
  ,'600003641'  --订单详情页
  ,'600003643'  --支付失败页
  ,'600003572'  --订单完成页

  ,'10320655907'  --地图页面
  ,'10320671062'  --地图详情页
  );