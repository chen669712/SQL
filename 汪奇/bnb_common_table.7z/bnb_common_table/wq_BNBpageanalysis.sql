drop table tmp_wq_bnbpvraw;
create table tmp_wq_bnbpvraw as 
select d
     , vid
     , sid
     , pvid 
     , lower(pagecode) as pagecode
     , lower(prepagecode) as prepagecode
     , substring(starttime,1,19) as starttime
     , clientcode
     , lower(uid) as uid
     , lower(category) as category
from dw_mobdb.factmbpageview
where d>='2017-11-17'
  and d<='2017-11-30'
  and clientcode is not null
  and clientcode not in ('','00000000000000000000');


------ 意图部分 --15天内是否有酒店意图
drop table tmp_wq_bnbintention;
create table tmp_wq_bnbintention as 
select d 
     , uid
     , intentioninfo
     , case when get_json_object(get_json_object(intentioninfo,'$.buvisitlist'),'$.DHTL') is not null then 'y'
            when get_json_object(get_json_object(intentioninfo,'$.buvisitlist'),'$.IHTL') is not null then 'y'
          else 'n' end as hashtlintention
     , date_add(d,1) as d_adj
  from olap_mobdb.userintentioninfo
 where d>='2017-11-16'
   and d<='2017-11-29';


----- 订单部分 --过去一年内是否有酒店订单
drop table tmp_wq_bnborder;
create table tmp_wq_bnborder as 
select lower(trim(uid)) as uid
  from olap_mobdb.olapmbordertotal
 where to_date(orderdate)>='2016-11-17'
   and to_date(orderdate)< '2017-11-17'
   and channel is not null
   and producttype='H'
   and subproducttype IN ('I','N')
group by lower(trim(uid));



 ----------------------------------------------------------------------
 ----- 底层表

drop table tmp_wq_bnbdataagg;
create table tmp_wq_bnbdataagg as 
 select a.*
      , b.intentioninfo
      , coalesce(b.hashtlintention,'n') as hashtlintention
      , case when c.uid is not null then 'y' else 'n' end as hasorderlastyr
   from (
          select *
            from tmp_wq_bnbpvraw
           where uid is not null
             and uid not in ('null','','wwwwww','test111111')) a 
left outer join tmp_wq_bnbintention b on a.d=b.d_adj and a.uid=b.uid
left outer join tmp_wq_bnborder c on a.uid=c.uid;


--------------------------------------------------------------------------------

drop table tmp_wq_bnbdatadetail;
create table tmp_wq_bnbdatadetail as 
select d
     , sid
     , pvid
     , pagecode
     , lead(pagecode,1) over (partition by d,sid,clientcode order by pvid) as next_1_page
     , lead(pagecode,2) over (partition by d,sid,clientcode order by pvid) as next_2_page
     , lead(pagecode,3) over (partition by d,sid,clientcode order by pvid) as next_3_page
     , lead(pagecode,4) over (partition by d,sid,clientcode order by pvid) as next_4_page
     , lead(pagecode,5) over (partition by d,sid,clientcode order by pvid) as next_5_page
     , starttime
     , lead(starttime,1) over(partition by d,sid,clientcode order by pvid) as next_time
     , category
     , lead(category,1) over (partition by d,sid,clientcode order by pvid) as next_category
     , uid
     , clientcode
     , case when hashtlintention='y' and hasorderlastyr='y' then '有意图有订单'
            when hashtlintention='y' and hasorderlastyr='n' then '有意图无订单'
            when hashtlintention='n' and hasorderlastyr='y' then '无意图有订单'
            when hashtlintention='n' and hasorderlastyr='n' then '无意图无订单'
        end as usertype
  from tmp_wq_bnbdataagg;



---- APP首页分布
  select d 
       , usertype
       , count(distinct uid) as uv
  from tmp_wq_bnbdatadetail
  where pagecode='home'
 group by d 
        , usertype


---- 民宿首页分布
  select d 
       , usertype
       , count(distinct uid) as uv
  from tmp_wq_bnbdatadetail
  where pagecode='home'
    and next_1_page='600003560'
 group by d 
        , usertype


----- 列表页分布
---- 民宿首页分布
  select d 
       , usertype
       , count(distinct uid) as uv
  from tmp_wq_bnbdatadetail
  where pagecode='home'
    and next_1_page='600003560'
    and next_2_page='600003563'
 group by d 
        , usertype




---- 详情页分布
  select d 
       , usertype
       , count(distinct uid) as 
  from tmp_wq_bnbdatadetail
  where pagecode='home'
    and next_1_page='600003560'
    and (next_2_page='600003564' or next_3_page='600003564')
 group by d 
        , usertype


---- 列表页到详情页分布
  select d 
       , usertype
       , count(distinct uid) as 
  from tmp_wq_bnbdatadetail
  where pagecode='home'
    and next_1_page='600003560'
    and next_2_page='600003563' 
    and next_3_page='600003564'
 group by d 
        , usertype




 ---- 订单完成页分布
 drop table tmp_wq_bnbhomeorderseqdatail;
 create table tmp_wq_bnbhomeorderseqdatail as 
 select a.d
      , a.sid 
      , a.pvid
      , a.usertype
      , a.uid
      , a.pagecode
      , a.next_1_page
      , a.next_2_page
      , a.next_3_page
      , b.pvid as order_pvid
      , case when a.pvid<b.pvid then 'y' else 'n' end as hasfillinpage
      , case when a.pvid<c.pvid then 'y' else 'n' end as hasorderpage
 from (
  select d
       , sid 
       , pvid
       , usertype
       , uid
       , pagecode
       , next_1_page
       , next_2_page
       , next_3_page
  from tmp_wq_bnbdatadetail
  where pagecode='home'
    and next_1_page='600003560'
    and (next_2_page='600003564' or next_3_page='600003564') ) a 
 left outer join (
 	        select d
                 , sid 
                 , min(pvid) as pvid
                 , uid
              from tmp_wq_bnbdatadetail
             where pagecode='600003570'
            group by d
                   , sid 
                   , uid) b on a.d=b.d and a.sid=b.sid and a.uid=b.uid
  left outer join (
 	        select d
                 , sid 
                 , min(pvid) as pvid
                 , uid
              from tmp_wq_bnbdatadetail
             where pagecode='600003570'
               and next_1_page='600003572'
            group by d
                   , sid 
                   , uid) c on a.d=c.d and a.sid=c.sid and a.uid=c.uid;


select d 
      ,usertype
      ,count(distinct case when hasfillinpage='y' then uid end) as uv1
      ,count(distinct case when hasorderpage='y'  then uid end) as uv2
  from tmp_wq_bnbhomeorderseqdatail
group by d 
       , usertype


-------------------------------------------------------------------------------------

---- 民宿首页分布
  select d 
       , usertype
       , count(distinct uid) as uv
  from tmp_wq_bnbdatadetail
  where pagecode='600003560'
 group by d 
        , usertype


---- 民宿列表页分布
  select d 
       , usertype
       , count(distinct uid) as uv
  from tmp_wq_bnbdatadetail
  where pagecode='600003560'
    and next_1_page='600003563'
 group by d 
        , usertype



---- 详情页分布
  select d 
       , usertype
       , count(distinct uid) as 
  from tmp_wq_bnbdatadetail
  where pagecode='600003560'
    and (next_1_page='600003564' or next_2_page='600003564')
 group by d 
        , usertype


---- 列表页到详情页分布
  select d 
       , usertype
       , count(distinct uid) as 
  from tmp_wq_bnbdatadetail
  where pagecode='600003560'
    and next_1_page='600003563' 
    and next_2_page='600003564'
 group by d 
        , usertype


 ---- 订单完成页分布
 drop table tmp_wq_bnborderseqdatail;
 create table tmp_wq_bnborderseqdatail as 
 select a.d
      , a.sid 
      , a.pvid
      , a.usertype
      , a.uid
      , a.pagecode
      , a.next_1_page
      , a.next_2_page
      , a.next_3_page
      , b.pvid as order_pvid
      , case when a.pvid<b.pvid then 'y' else 'n' end as hasfillinpage
      , case when a.pvid<c.pvid then 'y' else 'n' end as hasorderpage
 from (
  select d
       , sid 
       , pvid
       , usertype
       , uid
       , pagecode
       , next_1_page
       , next_2_page
       , next_3_page
  from tmp_wq_bnbdatadetail
  where pagecode='600003560'
    and (next_1_page='600003564' or next_2_page='600003564') ) a 
 left outer join (
 	        select d
                 , sid 
                 , min(pvid) as pvid
                 , uid
              from tmp_wq_bnbdatadetail
             where pagecode='600003570'
            group by d
                   , sid 
                   , uid) b on a.d=b.d and a.sid=b.sid and a.uid=b.uid
  left outer join (
 	        select d
                 , sid 
                 , min(pvid) as pvid
                 , uid
              from tmp_wq_bnbdatadetail
             where pagecode='600003570'
               and next_1_page='600003572'
            group by d
                   , sid 
                   , uid) c on a.d=c.d and a.sid=c.sid and a.uid=c.uid;



select d 
      ,usertype
      ,count(distinct case when hasfillinpage='y' then uid end) as uv1
      ,count(distinct case when hasorderpage='y'  then uid end) as uv2
  from tmp_wq_bnborderseqdatail
group by d 
       , usertype



--------------------------------------------------------------------------------
----- 只进入过详情页但当天没有进入订单完成页  之后有酒店订单
create table tmp_wq_bnbhtlorder as 
select lower(trim(uid)) as uid 
     , to_date(orderdate) as orderdate
     , max(unix_timestamp(substring(orderdate,1,19))) as unix_order
from olap_Mobdb.olapmbwirelessorder
where channel is not null 
  and to_date(orderdate)>='2017-11-17'
  and to_date(orderdate)<='2017-11-30'
  and producttype='H'
  and subproducttype IN ('I','N')
group by lower(trim(uid))
       , to_date(orderdate);



------- 详情页
create table tmp_wq_bnbonlydetailpage_1 as 
select a.d
     , a.usertype
     , a.uid
     , a.unix_time
     , max(case when b.uid is not null then 'y' else 'n' end) as has_detailpage
from (
     select d
          , usertype
          , uid
          , unix_timestamp(starttime) as unix_time
       from tmp_wq_bnbdatadetail
       where pagecode='600003564' ) a 
left outer join (
              select d
                    , uid
                 from tmp_wq_bnbdatadetail
                 where pagecode='600003570'
              group by d
                     , uid ) b on a.d=b.d and a.uid=b.uid
group by a.d
       , a.usertype
       , a.uid
       , a.unix_time;



drop table tmp_wq_bnbonlydetailpage;
create table tmp_wq_bnbonlydetailpage as 
select a.d
     , a.usertype
     , a.uid
     , max(has_detailpage) as has_detailpage
     , max(case when a.unix_time <= c.unix_order then 'y' else 'n' end) as has_htlorder
from tmp_wq_bnbonlydetailpage_1 a
left outer join tmp_wq_bnbhtlorder c on a.d=c.orderdate and a.uid=c.uid
group by a.d
       , a.usertype
       , a.uid;


---- 进入过产品详情页但是  没有进入过订单填写页  但当日没有订单
select d 
     , usertype
     , count(distinct uid) as tot_uv
     , count(distinct case when has_detailpage='n' and has_htlorder='y' then uid end) as uv 
from tmp_wq_bnbonlydetailpage
group by d 
       , usertype;




 ------- 详情页
drop table tmp_wq_bnbonlyorderfillinpage_1;
create table tmp_wq_bnbonlyorderfillinpage_1 as 
select a.d
     , a.usertype
     , a.uid
     , a.unix_time
     , max(case when b.uid is not null then 'y' else 'n' end) as has_detailpage
from (
     select d
          , usertype
          , uid
          , unix_timestamp(starttime) as unix_time
       from tmp_wq_bnbdatadetail
       where pagecode='600003570' ) a 
left outer join (
              select d
                    , uid
                 from tmp_wq_bnbdatadetail
                 where pagecode='600003572'
              group by d
                     , uid ) b on a.d=b.d and a.uid=b.uid
group by a.d
       , a.usertype
       , a.uid
       , a.unix_time;


drop table tmp_wq_bnbonlyorderfillinpage;
create table tmp_wq_bnbonlyorderfillinpage as 
select a.d
     , a.usertype
     , a.uid
     , max(a.has_detailpage) as has_detailpage
     , max(case when a.unix_time <= c.unix_order then 'y' else 'n' end) as has_htlorder
  from tmp_wq_bnbonlyorderfillinpage_1 a 
left outer join tmp_wq_bnbhtlorder c on a.d=c.orderdate and a.uid=c.uid
group by a.d
       , a.usertype
       , a.uid;


select d 
     , usertype
     , count(distinct uid) as tot_uv
     , count(distinct case when has_detailpage='n' and has_htlorder='y' then uid end) as uv 
from tmp_wq_bnbonlyorderfillinpage
group by d 
       , usertype;