use dw_htlbizdb;
--drop table if exists tmp_chen_lib_bnb_orderab_new;
--create table tmp_chen_lib_bnb_orderab_new as
insert overwrite table bnb_orderab_new partition (d='${selectDate}')
select a.orderdate,
       a.orderid,
       a.uid,
       a.clientid,
       a.totalsaleamount,       --售卖价格（包含发票的价格，当和saleamount不一致时，就是因为有了发票）
       a.totalcostamount,       --成本金额
       a.totaldiscountamount,   --总优惠金额
       b.vendorid,
       b.productid,
       datediff(to_date(c.checkout), to_date(c.checkin)) * (b.quantity) as ordquantity, --间夜量
	   b.quantity as roomnum, --房间数
       b.saleamount,--卖价总金额
       b.costamount as costamount,--成本价
       to_date(c.checkin) as checkin,         --入住时间
       to_date(c.checkout) as checkout,        --退房时间
       c.cityid,
       case when b.statusId in (1212,1012,1210,1222, 1214,2212, 2232, 2233,9933 ,1220,2332,9000) then '成功单'
       else '交易失败' end as orderstatus --'订单状态'
  from (select createdtime as orderdate, --预定日期
               orderid,
               uid,
               clientid,
               totalsaleamount,       --售卖价格(不包含发票价格，房型的卖价)
               totalcostamount,       --成本金额
               totaldiscountamount,   --总优惠金额
               terminaltype           --用户下单使用的终端类型：0.未知 ,10手机APP下单,11.APP H5,20.PC端
          from ods_htl_bnborderdb.order_header_v2 --新民宿订单表（所有订单）
         where d = '${Today}'
           and to_date(createdtime) > '2017-04-30'     --等价于orderdate
           and to_date(createdtime) <= '${selectDate}' --等价于orderdate
           --and sellerid = 0 --民宿频道
           and (sellerid is null or sellerid = 0) --汪奇口径
           and visitsource not in ('13', '14')    --汪奇口径
           ) a
         join
          (select orderid,
                  productid,   --产品ID
                  productname, --产品名称
                  orderitemid,
                  quantity,
                  saleamount,  --卖价总金额
                  costamount,  --成本价总金额
                  onlinepaymentrate, --在线支付百分比, 1.00代表在线支付100%金额
                  vendorid,           --供应商ID,根据产品类型区分
                  statusid
             from ods_htl_bnborderdb.order_item--限制订单状态
            where d = '${Today}'
              --and productType = 1
			   and (statusid like '12%'   -- 支付成功
      or statusid like '20%'   -- 待退款
      or statusid like '22%'   -- 	部分退款
      or statusid like '23%')  -- 已退款
	  and saleamount>=20
           )b
            on a.orderid = b.orderid
          join (select orderitemid,    --订单项ID
                       ownerid,        --房东ID
                       checkin,        --入住日期
                       checkout,       --离店日期
                       adultquantity,  --成人入住人数
                       childquantity,  --儿童入住人数
                       infantquantity, --婴儿入住人数
                       cancellationpolicy, --取消策略
                       confirmtype,        --确认类型 :0.未设置     1.自动确认     2.人工确认     earliestarrival, --最早到达时间
                       latestarrival,      --最晚到达时间
                       cityid              --房源所在城市ID
                 from ods_htl_bnborderdb.order_item_space  --取入离时间
                where d = '${Today}'
               ) c
            on b.orderitemid = c.orderitemid;




--1:从分流表取分流用户
use dw_htlbizdb;
drop table if exists tmp_chen_lib_bnb_abtest_factabtesting_1;
create table tmp_chen_lib_bnb_abtest_factabtesting_1 as
select d
  , clientcode
  --, uid
  ,case when abversion = 'B' then 'B'
        when abversion in ('C', 'D') then 'control'
        else null end as abversion
from dw_abtestdb.factabtestingserver
where expcode = '180313_bnbHybrid_gnxpx'
  and d>='2018-03-23'
  and d<='${selectDate}' -- '2018-03-25'
  and abversion in ('B','C','D')
group by d
  , clientcode
  , (case when abversion = 'B' then 'B'
        when abversion in ('C', 'D') then 'control'
        else null end)
  ;

--2：剔除一个用户被分到多个版本的cid，剔除AB异常用户，剔除不是从民宿产品列表页进入的cid
use dw_htlbizdb;
drop table if exists tmp_chen_lib_bnb_abtest_userpv_1;
create table tmp_chen_lib_bnb_abtest_userpv_1 as
select d,abversion,clientcode,count(distinct pvid) as pv,count(distinct sid,pvid) as pvid_1
from(select a.d, a.clientcode, a.abversion, m.sid, m.pvid
       from tmp_chen_lib_bnb_abtest_factabtesting_1 a
       left join (select d, clientcode, count(distinct abversion) as abcnt
                    from tmp_chen_lib_bnb_abtest_factabtesting_1
                   group by d, clientcode
                  having count(distinct abversion) > 1 --用户被分流到多个版本，去除
                  ) b
         on a.clientcode = b.clientcode
        and a.d = b.d
       left join (select clientcode
                    from olap_abtestdb.abAbnormalUser --AB异常用户
                   where d >='2018-03-23'
                     and d <= '${selectDate}'
                     and clienttype = 'app'
                     and distance > std
                     and distance > 1
                   group by clientcode) c
         on a.clientcode = c.clientcode
       join (select distinct d, clientcode, lower(uid) as uid, sid, pvid
               from DW_MobDB.factmbpageview
              where d >= '2018-03-23'
                and d <= '${selectDate}'
                and pagecode in ('600003563') -- 600003563 民宿产品列表页
                and prepagecode IN ('600003560')) m
         on a.d = m.d
        and a.clientcode = m.clientcode --（取从主页进入的用户）
      where b.clientcode is null
        and c.clientcode is null
    )a
 group by d,abversion,clientcode;





--3.1: 汇总每一天的用户，每个用户的总订单信息等。
use dw_htlbizdb;
drop table if exists tmp_chen_lib_bnb_abtest_userorder_1;
create table tmp_chen_lib_bnb_abtest_userorder_1 as
select a.d,
       'bnb_ltr' as experiment,
       a.abversion as abversion_temp,
       a.clientcode,
       case when a.pv is null then 0 else a.pv end as pv_sum,  --pv
       case when a.pvid_1 is null then 0 else a.pvid_1 end as pv_sum_1,  --pv
       case when b.order_num is null then 0 else b.order_num end as order_num,--订单数CR
       case when b.nocancel_order_num is null then 0 else b.nocancel_order_num end as nocancel_order_num, --非取消订单数
       case when b.quantity_sum is null then 0 else b.quantity_sum end as quantity_sum,  --间夜数
       case when b.amount_sum is null then 0 else b.amount_sum end as amount_sum,  --GMB（人均订单金额）
       case when b.gp_sum is null then 0 else b.gp_sum end as gp_sum,  --人均GP
       case when b.nocancel_gp_sum is null then 0 else b.nocancel_gp_sum end as nocancel_gp_sum,  --人均非取消单GP
       case when b.gp_c_sum is null then 0 else b.gp_c_sum end as gp_c_sum, --人均订单利润（去除优惠券）
       case when b.nocancel_gp_c_sum is null then 0 else b.nocancel_gp_c_sum end as nocancel_gp_c_sum  --人均非取消订单利润（去除优惠券）
 from tmp_chen_lib_bnb_abtest_userpv_1 a
left join (select d,
                  clientid,
                  count(distinct orderid) as order_num,--订单数CR
                  count(distinct case when orderstatus = '成功单' then orderid end) as nocancel_order_num,--非取消订单数
                  sum(ordquantity) as quantity_sum,
                  sum(saleamount) as amount_sum,--金额   GMB(人均订单金额)
                  sum(saleamount - costamount) as gp_sum,--成本价总金额
                  sum(case when orderstatus = '成功单' then (saleamount - costamount) else 0 end) as nocancel_gp_sum,
                  sum(saleamount - costamount - totaldiscountamount) as gp_c_sum, --GP-C
                  sum(case when orderstatus = '成功单' then (saleamount - costamount - totaldiscountamount)
                      else 0 end) as nocancel_gp_c_sum
             from bnb_orderab_new
            where d = '${selectDate}'
              and to_date(orderdate) >= '2018-03-23'
              and to_date(orderdate) <= '${selectDate}'
            group by d,clientid
          ) b
  on a.clientcode = b.clientid
 and a.d = b.d
 ;



--3.2:得到最终每日的计算结果（总体效果）  pvid
use dw_htlbizdb;
insert overwrite table bnb_abtest_result partition (d='${selectDate}')
--drop table if exists tmp_chen_lib_bnb_abtest_userorder_2;
--create table tmp_chen_lib_bnb_abtest_userorder_2 as
select
      abversion_temp
      ,experiment
      ,count(distinct clientcode) as uv
      ,avg(pv_sum            ) as pv_sum_avg
      ,avg(order_num         ) as order_num_avg
      ,avg(nocancel_order_num) as nocancel_order_num_avg
      ,avg(quantity_sum      ) as quantity_sum_avg
      ,avg(amount_sum        ) as amount_sum_avg
      ,avg(gp_sum            ) as gp_sum_avg
      ,avg(nocancel_gp_sum   ) as nocancel_gp_sum_avg
      ,avg(gp_c_sum          ) as gp_c_sum_avg
      ,avg(nocancel_gp_c_sum ) as	nocancel_gp_c_sum_avg
      ,stddev_samp(pv_sum             )/sqrt(count(distinct clientcode)) as   pv_sum_std
      ,stddev_samp(order_num          )/sqrt(count(distinct clientcode)) as   order_num_std
      ,stddev_samp(nocancel_order_num )/sqrt(count(distinct clientcode)) as   nocancel_order_num_std
      ,stddev_samp(quantity_sum       )/sqrt(count(distinct clientcode)) as   quantity_sum_std
      ,stddev_samp(amount_sum         )/sqrt(count(distinct clientcode)) as   amount_sum_std
      ,stddev_samp(gp_sum             )/sqrt(count(distinct clientcode)) as   gp_sum_std
      ,stddev_samp(nocancel_gp_sum    )/sqrt(count(distinct clientcode)) as   nocancel_gp_sum_std
      ,stddev_samp(gp_c_sum           )/sqrt(count(distinct clientcode)) as   gp_c_sum_std
      ,stddev_samp(nocancel_gp_c_sum  )/sqrt(count(distinct clientcode)) as   nocancel_gp_c_sum_std
 from dw_htlbizdb.tmp_chen_lib_bnb_abtest_userorder_1
group by abversion_temp,experiment
;


--
--3.3:pvid_1
use dw_htlbizdb;
insert overwrite table bnb_abtest_result_pv partition (d='${selectDate}')
--drop table if exists tmp_chen_lib_bnb_abtest_userorder_2;
--create table tmp_chen_lib_bnb_abtest_userorder_2 as
select
      abversion_temp
      ,experiment
      ,count(distinct clientcode) as uv
      ,avg(pv_sum_1          ) as pv_sum_avg
      ,avg(order_num         ) as order_num_avg
      ,avg(nocancel_order_num) as nocancel_order_num_avg
      ,avg(quantity_sum      ) as quantity_sum_avg
      ,avg(amount_sum        ) as amount_sum_avg
      ,avg(gp_sum            ) as gp_sum_avg
      ,avg(nocancel_gp_sum   ) as nocancel_gp_sum_avg
      ,avg(gp_c_sum          ) as gp_c_sum_avg
      ,avg(nocancel_gp_c_sum ) as	nocancel_gp_c_sum_avg
      ,stddev_samp(pv_sum             )/sqrt(count(distinct clientcode)) as   pv_sum_std
      ,stddev_samp(order_num          )/sqrt(count(distinct clientcode)) as   order_num_std
      ,stddev_samp(nocancel_order_num )/sqrt(count(distinct clientcode)) as   nocancel_order_num_std
      ,stddev_samp(quantity_sum       )/sqrt(count(distinct clientcode)) as   quantity_sum_std
      ,stddev_samp(amount_sum         )/sqrt(count(distinct clientcode)) as   amount_sum_std
      ,stddev_samp(gp_sum             )/sqrt(count(distinct clientcode)) as   gp_sum_std
      ,stddev_samp(nocancel_gp_sum    )/sqrt(count(distinct clientcode)) as   nocancel_gp_sum_std
      ,stddev_samp(gp_c_sum           )/sqrt(count(distinct clientcode)) as   gp_c_sum_std
      ,stddev_samp(nocancel_gp_c_sum  )/sqrt(count(distinct clientcode)) as   nocancel_gp_c_sum_std
 from dw_htlbizdb.tmp_chen_lib_bnb_abtest_userorder_1
group by abversion_temp,experiment;