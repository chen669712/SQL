--------------------------------------------------
-- 订单分布的取数逻辑
-- 基于分流用户，计算不同的点击分布用户
--------------------------------------------------

----取进入List的UV-----
use bnb_hive_db;
drop table if exists tmp_wq_bnb_rba_list;
create table tmp_wq_bnb_rba_list as
select home.starttime
  , home.unixtime
  , home.clientcode
from
(select distinct starttime
  , clientcode
  , unix_timestamp(substring(starttime,1,19)) as unixtime
from bnb_pageview
where d = '${zdt.addDay(-1).format("yyyy-MM-dd")}')home
left outer join
(select distinct clientcode
from bnb_pageview
where d = '${zdt.addDay(-1).format("yyyy-MM-dd")}'
  and pagecode ='600003563'
  and prepagecode ='600003560')list on home.clientcode = list.clientcode
where list.clientcode is not null;

----取AB实验的分流用户----
drop table if exists tmp_wq_bnb_rba_ab;
create table tmp_wq_bnb_rba_ab as
select fts.clientcode
  , fts.abversion
from
(select distinct clientcode
  , abversion
from dw_abtestdb.factabtestingserver
where expcode = '180507_bnbHybrid_rba'
  and d ='${zdt.addDay(-1).format("yyyy-MM-dd")}')fts
left outer join
(select clientcode
  from olap_abtestdb.abAbnormalUser
  where d>='2018-06-01'
    and clienttype = 'app'
    and distance>std
    and distance>1
 group by clientcode ) abu on fts.clientcode = abu.clientcode
where abu.clientcode is null;

-----取进入List用户分流情况-----
drop table if exists tmp_wq_bnb_rba_ab_cid;
create table tmp_wq_bnb_rba_ab_cid as
select distinct brl.starttime
  , brl.unixtime
  , brl.clientcode
  , bra.abversion
from
tmp_wq_bnb_rba_list brl
left outer join
tmp_wq_bnb_rba_ab bra on brl.clientcode = bra.clientcode
where bra.clientcode is not null;



-----取进入List曝光的产品属性-----
use bnb_hive_db;
insert overwrite table bnb_rba_product_distribution
partition(d = '${zdt.addDay(-1).format("yyyy-MM-dd")}')
select bpt.productid
	, case when bst.tagid is null then '0'
	    when bst.tagid=59 then '1'
	    else '2' end as rbaFlag
	, bpt.type
	, bpt.clientcode
	, rac.abversion
	, bpt.cityid
	, bpt.prdunixtime
from
(select productid
 	, cid as clientcode
 	, type
 	, cityid
 	, ts as prdunixtime
 from bnb_hive_db.bnb_product_trace
 where d = '${zdt.addDay(-1).format("yyyy-MM-dd")}'
 	and source = '102') bpt
left outer join
(select distinct spaceid
  , tagid
from ods_htl_groupwormholedb.bnb_space_tag
where d = '${zdt.addDay(-1).format("yyyy-MM-dd")}'
  and tagid=59) bst on bpt.productid = bst.spaceid
left outer join
tmp_wq_bnb_rba_ab rac on bpt.clientcode = rac.clientcode;



------取分流用户的订单---------
insert overwrite table bnb_rba_oi_distribution
partition(d = '${zdt.addDay(-1).format("yyyy-MM-dd")}')
select rac.clientcode
  , rac.abversion
  , rac.starttime
  , rac.unixtime
  , oi.orderid
  , oi.orderamount
  , oi.ordertime
from
tmp_wq_bnb_rba_ab_cid rac
left outer join
(select productid
  , orderid
  , orderamount
  , unix_timestamp(substring(ordertime,1,19))  as ordertime
  , cid as clientcode
  , orderstatus
from bnb_orderinfo
where d = '${zdt.addDay(-1).format("yyyy-MM-dd")}'
  and to_date(ordertime) = '${zdt.addDay(-1).format("yyyy-MM-dd")}'
  and source = '100'
  and sellerid = '0'
  and visitsource in (0, 20, 70, 120, 130, 201, 203, 205)) oi on oi.clientcode=rac.clientcode;



use bnb_hive_db;
drop table bnb_rba_product_distribution;
CREATE TABLE bnb_rba_product_distribution(
	productid string COMMENT '进入列表的产品Id'
	, rbaFlag string COMMENT '是不是RBA房源'
	, type string COMMENT '产品的曝光和点击'
  , clientcode string COMMENT '用户的cid'
  , abversion string COMMENT 'RBA分流版本'
  , cityid string COMMENT '产品所属的城市Id'
	, prdunixtime string COMMENT '进入列表时间'
)COMMENT '无线民宿RBA实验中间表'
PARTITIONED BY (`d` string COMMENT 'date')



use bnb_hive_db;
CREATE TABLE bnb_rba_oi_distribution(
  clientcode string COMMENT '用户的cid'
  , abversion string COMMENT 'RBA分流版本'
	, starttime string COMMENT '进入列表时间'
	, unixtime string COMMENT '进入列表UNIX时间'
	, orderid string COMMENT '订单Id'
	, orderamount string COMMENT '订单金额'
	, ordertime string COMMENT '下单UNIX时间'
)COMMENT '无线民宿RBA实验中间表'
PARTITIONED BY (`d` string COMMENT 'date')


use bnb_hive_db;
select aa.d as `日期`
  , aa.abversion as `实验号`
  , concat(cast(100*((aa.rbaOPrd)/(aa.rbaOPrd+aa.nrbaOPrd)) as decimal(5,2)),'%') as `列表页RBA曝光产品占比`
  , concat(cast(100*((aa.rbaOUV)/(aa.rbaOUV+aa.nrbaOUV)) as decimal(5,2)),'%') as `列表页RBA曝光用户占比`
  , aa.rbaOPrd as `列表页RBA曝光产品数`
  , aa.nrbaOPrd as `列表页非RBA曝光产品数`
  , aa.rbaCPrd  as `列表页RBA点击产品数`
  , aa.nrbaCPrd  as `列表页非RBA点击产品数`
  , aa.rbaOUV  as `列表页RBA曝光用户数`
  , aa.nrbaOUV as `列表页非RBA曝光用户数`
  , aa.rbaCUV as `列表页RBA点击用户数`
  , aa.nrbaCUV as `列表页非RBA点击用户数`
from
(select d
  , case when a.abversion = 'B' then 'RBA加权'
            when a.abversion = 'C' then '非RBA加权C'
            when a.abversion = 'D' then '非RBA加权D'
            end as abversion
  , sum(if(a.rbaFlag=1 and a.type=100, a.num, 0)) as rbaOPrd
  , sum(if(a.rbaFlag=1 and a.type=101, a.num, 0)) as rbaCPrd
  , sum(if(a.rbaFlag=0 and a.type=100, a.num, 0)) as nrbaOPrd
  , sum(if(a.rbaFlag=0 and a.type=101, a.num, 0)) as nrbaCPrd
  , sum(if(a.rbaFlag=1 and a.type=100, a.uv, 0)) as rbaOUV
  , sum(if(a.rbaFlag=1 and a.type=101, a.uv, 0)) as rbaCUV
  , sum(if(a.rbaFlag=0 and a.type=100, a.uv, 0)) as nrbaOUV
  , sum(if(a.rbaFlag=0 and a.type=101, a.uv, 0)) as nrbaCUV
from
(select d
  ,rbaFlag
	, type
	, abversion
	, count(distinct clientcode) as uv
	, count(1) as num
from bnb_rba_product_distribution
where d >= '2018-06-15'
  and abversion is not null
group by d
  , rbaFlag
	, type
	, abversion)a
group by a.d
  ,a.abversion) aa


use bnb_hive_db;
select aa.d as `日期`
  , aa.abversion as `实验号`
  , aa.uv as `列表页分流UV`
  , aa.ois as `分流订单数`
  , aa.oiAmount as `分流订单金额`
  , concat(cast(100*((aa.ois)/aa.uv) as decimal(5,2)),'%') as `列表页U2O占比`
  , concat(cast(100*((aa.oiAmount)/aa.ois) as decimal(5,2)),'%') as `订单均价`
from
(select a.d
  , case when a.abversion = 'B' then 'RBA加权'
            when a.abversion = 'C' then '非RBA加权C'
            when a.abversion = 'D' then '非RBA加权D'
            end as abversion
  , count(a.clientcode) as uv
  , count(a.orderid) as ois
  , sum(a.orderamount) as oiAmount
from
(select distinct d
  , abversion
  , clientcode
  , orderid
  , orderamount
from bnb_rba_oi_distribution
where d>='2018-06-16')a
group by a.d
  , a.abversion) aa