--------------------------------------------------
-- 订单分布的取数逻辑
-- 基于分流用户，计算不同的点击分布用户
--------------------------------------------------

use bnb_hive_db;
drop table if exists tmp_wq_bnb_abtest_raw;
create table tmp_wq_bnb_abtest_raw as
select expcode
  , layer
  , clientcode
  , abversion
  , min(starttime) as starttime
  , min(unix_timestamp(substring(starttime,1,19))) as unix_time
from dw_abtestdb.factabtestingserver
where expcode like ('%_bnbHybrid_%')
  and d='2018-06-06'
group by expcode
  , layer
  , clientcode
  , abversion;


drop table if exists tmp_wq_bnb_abtest_users;
create table tmp_wq_bnb_abtest_users as
select a.expcode
  , a.layer
  , a.clientcode
  , a.abversion
  , a.starttime
  , a.unix_time
from tmp_wq_bnb_abtest_raw a
left outer join
(select expcode
    , clientcode
    , count(distinct abversion) as abcnt
  from tmp_wq_bnb_abtest_raw
  group by expcode
     , clientcode
  having count(distinct abversion)>1) b on a.clientcode=b.clientcode
left outer join
(select experiment
  , cumstart
from dim_abtestdb.DimAbtestConfig
where d = '2018-06-06') dac on

(select distinct clientcode
  from olap_abtestdb.abAbnormalUser
  where d='2018-06-06'
    and clienttype = 'app'
    and distance>std
    and distance>1
 group by clientcode ) c on a.clientcode=c.clientcode
where b.clientcode is null
  and c.clientcode is null;


select dac.experiment
  , aau.clientcode
from
(select experiment
  , max(cumstart) as cumstart
from dim_abtestdb.DimAbtestConfig
where d = '2018-06-01'
  , experiment like ('%_bnbHybrid_%')
group by experiment) dac
union all
(select distinct d, clientcode
  from olap_abtestdb.abAbnormalUser
  where clienttype = 'app'
    and distance>std
    and distance>1
    and d>='2018-06-01') aau
 where aau.d >= dac.cumstart




drop table if exists tmp_wq_bnb_abtest_raw_ordermatch;
create table tmp_wq_bnb_abtest_raw_ordermatch as
select a.d
    ,a.orderid
    ,a.orderamount
    ,a.unix_order
    ,a.cid
    ,a.orderstatus
    ,b.abversion
    ,b.unix_time
    ,case when a.unix_order>=b.unix_time and a.unix_order<=b.unix_time+86400   then 'y' end as is24horder
    ,case when a.d=b.d                                                         then 'y' end as isdayorder
    ,case when a.unix_order>=b.unix_time and a.unix_order<=b.unix_time+7*86400 then 'y' end as is7dorder
from
(select to_date(ordertime) as d
  , productid
  , orderid
  , orderamount
  , unix_timestamp(substring(ordertime,1,19))  as unix_order
  , cid
  , orderstatus
from bnb_orderinfo
where d = ${hiveconf:calDay}
  and to_date(ordertime) >=${hiveconf:beginDay}
  and to_date(ordertime) <=${hiveconf:endDay}
  and source in('100', '101')
  and visitsource not in ('13', '14')
  and (sellerid is null or sellerid = '0')) a
left outer join
tmp_wq_bnb_abtest_users b on a.cid=b.clientcode








use bnb_hive_db;
select d
  , abversion
  , count(distinct clientcode) as users
from tmp_wq_bnb_abtest_users
group by d, abversion;

use bnb_hive_db;
select d
  , abversion
  , count(distinct orderid) as num
from tmp_wq_bnb_abtest_raw_ordermatch
where isdayorder = 'y'
group by d, abversion;

use bnb_hive_db;
select d
  , abversion
  , sum(orderamount) as amount
from tmp_wq_bnb_abtest_raw_ordermatch
where isdayorder = 'y'
group by d, abversion;



--------------------------------------------------
-- 点击分布的取数逻辑
-- 基于分流用户，计算不同的点击分布用户
--------------------------------------------------
drop table if exists tmp_wq_bnb_abtest_users;
create table tmp_wq_bnb_abtest_users as
select a.d
     , a.clientcode
     , a.abversion
     , a.starttime
     , a.unix_time
     , d.key
from tmp_wq_bnb_abtest_raw a
left outer join
(select d
    , clientcode
    , count(distinct abversion) as abcnt
  from tmp_wq_bnb_abtest_raw
  group by d
         , clientcode
  having count(distinct abversion)>1) b on a.clientcode=b.clientcode and a.d=b.d
left outer join
(select clientcode
  from olap_abtestdb.abAbnormalUser
  where d>=${hiveconf:beginDay}
    and d<=${hiveconf:endDay}
    and clienttype = 'app'
    and distance>std
    and distance>1
 group by clientcode ) c on a.clientcode=c.clientcode
inner join
(select d   ---猜你喜欢曝光的用户
    , key
    , cid
  from bnb_tracelog
  where d>=${hiveconf:beginDay}
    and d<=${hiveconf:endDay}
    and pageid = '600003560'   ----- 查看不同的点击分布
    and key in ('o_bnb_inn_2nd_home_app', 'c_bnb_inn_home_hot_app', 'c_bnb_inn_home_abtest_app')) d on a.d = d.d and a.clientcode=d.cid
where b.clientcode is null
  and c.clientcode is null;


use bnb_hive_db;
select d
  , abversion
  , key
  , count(distinct clientcode) as users
from tmp_wq_bnb_abtest_users
group by d, abversion, key;


use bnb_hive_db;
select d
  , count(1) as pv
  , count(distinct cid) as uv
from bnb_tracelog
where d>='2018-04-03'
  and key = 'c_bnb_inn_banner_app'
  and get_json_object(value, '$.source') = '108'
group by d


---进入列表页
select d
  , count (1) as pv
  , count(distinct clientcode) as uv
from dw_mobdb.factmbpageview
where d >='2018-04-01'
	and pagecode in('10320676558')
group by d

use bnb_hive_db;
select d
    , count(distinct cid) as uv
  from bnb_tracelog
  where d>='2018-04-01'
    and pageid = '600003560'   ----- 查看不同的点击分布
    and key in ('o_bnb_inn_2nd_home_app')
group by d


use bnb_hive_db;
select bc.cityname
  , oi.oinum
  , hra.*
from
(select d
  , get_json_object(value, '$.city') as city
  , count(1) as pv
  , count(distinct cid) as uv
from bnb_tracelog
where d >= '2018-04-01'
  and key ='c_bnb_inn_home_abtest_app'
group by d, get_json_object(value, '$.city')) hra
left outer join
ods_htl_groupwormholedb.bnb_city bc on hra.city = bc.cityid
left outer join
(select to_date(ordertime) as d
  , cityid
  , count(orderid) as oinum
from bnb_orderinfo
where d='2018-04-19'
  and to_date(ordertime) >='2018-04-01'
  and vendorid = '203'
group by to_date(ordertime), cityid )oi on hra.city = oi.cityid



--- 4月18日上线海外，去掉切换到搜索页