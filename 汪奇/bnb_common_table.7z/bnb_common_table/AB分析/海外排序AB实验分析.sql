use bnb_hive_db;
set beginDay='2018-06-01';
set endDay='2018-06-04';
set calDay='2018-06-04';

drop table if exists tmp_wq_bnb_hwpx_ab;
create table tmp_wq_bnb_hwpx_ab as
select d
  , clientcode
  , mod
  , abversion
  , min(starttime) as starttime
  , min(unix_timestamp(substring(starttime,1,19))) as unix_time
from dw_abtestdb.factabtestingserver
where expcode = '180516_bnbHybrid_hwxpx'
  and d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
group by d
  , clientcode
  , mod
  , abversion;


drop table if exists tmp_wq_bnb_hwpx_ab_cid;
create table tmp_wq_bnb_hwpx_ab_cid as
select a.d
     , a.clientcode
     , a.abversion
     , a.starttime
     , a.unix_time
from tmp_wq_bnb_hwpx_ab a
left outer join
(select d
    , clientcode
    , count(distinct abversion) as abcnt
  from tmp_wq_bnb_hwpx_ab
  group by d
         , clientcode
  having count(distinct abversion)>1) b on a.clientcode=b.clientcode and a.d=b.d
left outer join
(select clientcode
  from olap_abtestdb.abAbnormalUser
  where d>=${hiveconf:beginDay}
    and d<=${hiveconf:endDay}
    and clienttype = 'app'
    and distance>std
    and distance>1
 group by clientcode ) c on a.clientcode=c.clientcode
where b.clientcode is null
  and c.clientcode is null;



drop table if exists tmp_wq_bnb_hwpx_ab_ordermatch;
create table tmp_wq_bnb_hwpx_ab_ordermatch as
select a.d
    ,a.orderid
    ,a.orderamount
    ,a.unix_order
    ,a.cid
    ,a.orderstatus
    ,b.abversion
    ,b.unix_time
    ,case when a.unix_order>=b.unix_time and a.unix_order<=b.unix_time+86400   then 'y' end as is24horder
    ,case when a.d=b.d                                                         then 'y' end as isdayorder
    ,case when a.unix_order>=b.unix_time and a.unix_order<=b.unix_time+7*86400 then 'y' end as is7dorder
from
(select to_date(ordertime) as d
  , orderid
  , orderamount
  , unix_timestamp(substring(ordertime,1,19))  as unix_order
  , cid
  , orderstatus
from bnb_orderinfo
where d = ${hiveconf:calDay}
  and to_date(ordertime) >=${hiveconf:beginDay}
  and to_date(ordertime) <=${hiveconf:endDay}
  and vendorid = '201') a
left outer join
tmp_wq_bnb_hwpx_ab_cid b on a.cid=b.clientcode;



use bnb_hive_db;
select d
  , abversion
  , count(distinct clientcode) as users
from tmp_wq_bnb_hwpx_ab_cid
group by d, abversion


select d
  , abversion
  , count(distinct orderid) as num
from tmp_wq_bnb_hwpx_ab_ordermatch
where isdayorder = 'y'
group by d, abversion


select d
  , count(distinct orderid)
from bnb_orderinfo
where d = ${hiveconf:calDay}
  and to_date(ordertime) >=${hiveconf:beginDay}
  and to_date(ordertime) <=${hiveconf:endDay}
  and vendorid = '201'