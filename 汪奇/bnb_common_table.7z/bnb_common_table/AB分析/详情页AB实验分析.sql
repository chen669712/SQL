
use bnb_hive_db;
set beginDay='2018-06-16';
set endDay='2018-07-10';
set calDay='2018-07-10';
set abCode='180530_bnbHybrid_xqy06';

drop table if exists tmp_wq_bnb_detail_ab;
create table tmp_wq_bnb_detail_ab as
select d
  , clientcode
  , abversion
  , min(starttime) as starttime
  , min(unix_timestamp(substring(starttime,1,19))) as unix_time
from dw_abtestdb.factabtestingexpdetail
where expcode = ${hiveconf:abCode}
  and d>=${hiveconf:beginDay}
  and d<=${hiveconf:endDay}
group by d
  , clientcode
  , abversion;


drop table if exists tmp_wq_bnb_detail_ab_cid;
create table tmp_wq_bnb_detail_ab_cid as
select a.d
     , a.clientcode
     , a.abversion
     , a.starttime
     , a.unix_time
from tmp_wq_bnb_detail_ab a
left outer join
(select d
    , clientcode
    , count(distinct abversion) as abcnt
  from tmp_wq_bnb_detail_ab
  group by d
         , clientcode
  having count(distinct abversion)>1) b on a.clientcode=b.clientcode and a.d=b.d
left outer join
(select clientcode
  from olap_abtestdb.abAbnormalUser
  where d>=${hiveconf:beginDay}
    and d<=${hiveconf:endDay}
    and clienttype = 'app'
    and distance>std
    and distance>1
 group by clientcode ) c on a.clientcode=c.clientcode
inner join
(select distinct clientcode
from

)
where b.clientcode is null
  and c.clientcode is null;

use bnb_hive_db;
select d
  , abversion
  , count(distinct clientcode) as uv
from tmp_wq_bnb_detail_ab_cid
group by d
  , abversion