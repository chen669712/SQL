-----------------------------------------------------------------
-- 获取仅通过九宫格进入到民宿的人群
-----------------------------------------------------------------
-- use tmp_dmdb;
use tmp_mobdb;
drop table if exists tmp_wq_bnbpvraw_all;
create table tmp_wq_bnbpvraw_all as 
select d
     , vid
     , sid
     , pvid 
     , lower(pagecode) as pagecode
     , lower(prepagecode) as prepagecode
     , substring(starttime,1,19) as starttime
     , clientcode
     , lower(uid) as uid
     , lower(category) as category
from dw_mobdb.factmbpageview
where d>='2017-12-01'
  and d<='2017-12-12'
  and clientcode is not null
  and clientcode not in ('','00000000000000000000');

drop table tmp_wq_bnbpvraw;
create table tmp_wq_bnbpvraw as 
select A.*
from tmp_wq_bnbpvraw_all  A
inner join (
    select d
         , uid
    from tmp_wq_bnbpvraw_all
    where  pagecode='600003560'
      and prepagecode = 'home'
      group by d
           , uid) B on A.uid = B.uid and A.d=B.d;  


------ 意图部分 --15天内是否有酒店意图
drop table tmp_wq_bnbintention;
create table tmp_wq_bnbintention as 
select d 
     , uid
     , intentioninfo
     , case when get_json_object(get_json_object(intentioninfo,'$.buvisitlist'),'$.DHTL') is not null then 'y'
            when get_json_object(get_json_object(intentioninfo,'$.buvisitlist'),'$.IHTL') is not null then 'y'
          else 'n' end as hashtlintention
     , date_add(d,1) as d_adj
  from olap_mobdb.userintentioninfo
 where d>='2017-11-30'
   and d<='2017-12-11';

----- 订单部分 --过去一年内是否有酒店订单
drop table tmp_wq_bnborder;
create table tmp_wq_bnborder as 
select lower(trim(uid)) as uid
  from olap_mobdb.olapmbordertotal
 where to_date(orderdate)>='2016-12-01'
   and to_date(orderdate)< '2017-12-01'
   and channel is not null
   and producttype='H'
   and subproducttype IN ('I','N')
group by lower(trim(uid));


----- 底层表
drop table tmp_wq_bnbdataagg;
create table tmp_wq_bnbdataagg as 
 select a.*
      , b.intentioninfo
      , coalesce(b.hashtlintention,'n') as hashtlintention
      , case when c.uid is not null then 'y' else 'n' end as hasorderlastyr
   from (
          select *
            from tmp_wq_bnbpvraw
           where uid is not null
             and uid not in ('null','','wwwwww','test111111')) a 
left outer join tmp_wq_bnbintention b on a.d=b.d_adj and a.uid=b.uid
left outer join tmp_wq_bnborder c on a.uid=c.uid;

drop table tmp_wq_bnbdatadetail;
create table tmp_wq_bnbdatadetail as 
select d
     , sid
     , pvid
     , pagecode
     , lead(pagecode,1) over (partition by d,sid,clientcode order by pvid) as next_1_page
     , lead(pagecode,2) over (partition by d,sid,clientcode order by pvid) as next_2_page
     , lead(pagecode,3) over (partition by d,sid,clientcode order by pvid) as next_3_page
     , lead(pagecode,4) over (partition by d,sid,clientcode order by pvid) as next_4_page
     , lead(pagecode,5) over (partition by d,sid,clientcode order by pvid) as next_5_page
     , starttime
     , lead(starttime,1) over(partition by d,sid,clientcode order by pvid) as next_time
     , category
     , lead(category,1) over (partition by d,sid,clientcode order by pvid) as next_category
     , uid
     , clientcode
     , case when hashtlintention='y' and hasorderlastyr='y' then '有意图有订单'
            when hashtlintention='y' and hasorderlastyr='n' then '有意图无订单'
            when hashtlintention='n' and hasorderlastyr='y' then '无意图有订单'
            when hashtlintention='n' and hasorderlastyr='n' then '无意图无订单'
        end as usertype
from tmp_wq_bnbdataagg;


select a.d
  , a.usertype
  , count(distinct a.uid)
from (select d
    ,usertype
    ,uid
from tmp_mobdb.tmp_wq_bnbdatadetail) a
inner join
(select to_date(createdtime) as d
  ,uid 
from ods_htl_bnborderdb.order_header_v2
  where to_date(createdtime)>= '2017-12-01') b on a.uid=b.uid and a.d=b.d
group by a.d
  ,a.usertype;


select d 
       , usertype
       , count(distinct uid) as uv
from tmp_dmdb.tmp_wq_bnbdatadetail
where pagecode='600003560'
    and next_1_page='600003563'
group by d 
        , usertype

select d 
       , usertype
       , count(distinct uid) as uv
from tmp_dmdb.tmp_wq_bnbdatadetail
where pagecode='600003563'
    and (next_1_page='600003564' or next_1_page='hotel_inn_detail')
group by d 
        , usertype


select d 
       , usertype
       , count(distinct uid) as uv
from tmp_dmdb.tmp_wq_bnbdatadetail
where (pagecode='600003564' or pagecode='hotel_inn_detail')
    and next_1_page='600003570'
group by d 
        , usertype

select d 
       , usertype
       , count(distinct uid) as uv
from tmp_dmdb.tmp_wq_bnbdatadetail
where pagecode='600003570'
    and next_1_page='widget_pay_main'
group by d 
        , usertype

select d 
       , usertype
       , count(distinct uid) as uv
from tmp_dmdb.tmp_wq_bnbdatadetail
where pagecode='600003572'
group by d 
        , usertype


-----------------------------------------------------------------
-- 进入订单填写页，没有支付
-----------------------------------------------------------------
use tmp_mobdb;
drop table tmp_wq_bnbhtlorder;
create table tmp_wq_bnbhtlorder as 
select lower(trim(uid)) as uid 
     , to_date(orderdate) as orderdate
     , (amount/realquantity) as price
     , max(unix_timestamp(substring(orderdate,1,19))) as unix_order
from olap_Mobdb.olapmbwirelessorder
where channel is not null 
  and to_date(orderdate)>='2017-11-20'
  and to_date(orderdate)<='2017-12-05'
  and producttype='H'
  and subproducttype IN ('I','N')
group by lower(trim(uid))
       , to_date(orderdate)
       , (amount/realquantity);


--- 进入填写页，没有进支付页的用户
use tmp_mobdb;
drop table tmp_wq_bnborderfill_nopay;
create table tmp_wq_bnborderfill_nopay as 
select a.d
     , a.usertype
     , a.uid
     , a.unix_time
     , max(case when b.uid is not null then 'y' else 'n' end) as has_detailpage
from (
     select d
          , usertype
          , uid
          , unix_timestamp(starttime) as unix_time
       from tmp_wq_bnbdatadetail
       where pagecode='600003570' ) a 
left outer join (
              select d
                    , uid
                 from tmp_wq_bnbdatadetail
                 where pagecode='widget_pay_main'
              group by d
                     , uid ) b on a.d=b.d and a.uid=b.uid
group by a.d
       , a.usertype
       , a.uid
       , a.unix_time;      


drop table tmp_wq_bnborderfill_nopay_result;
create table tmp_wq_bnborderfill_nopay_result as 
select a.d
     , a.usertype
     , a.uid
     , c.price
     , max(a.has_detailpage) as has_detailpage
     , max(case when a.unix_time <= c.unix_order then 'y' else 'n' end) as has_htlorder
  from tmp_wq_bnborderfill_nopay a 
left outer join tmp_wq_bnbhtlorder c on a.d=c.orderdate and a.uid=c.uid
group by a.d
       , a.usertype
       , a.uid
       , c.price; 

use tmp_dmdb;
drop table tmp_wq_bnborderfill_nopay_result_money;
create table tmp_wq_bnborderfill_nopay_result_money as
select d
      , usertype
      , case when (price < '100') then '0'
             when (price >='100' and price < '300') then '1'
             when (price >='300' and price < '500') then '2'
             when (price >='500') then '3'
          end as type
  from tmp_wq_bnborderfill_nopay_result
  where has_detailpage='n' 
  and has_htlorder='y'


