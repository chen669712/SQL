
-- 用户下单的产品
use bnb_hive_db;
drop table if exists tmp_wq_bnb_user_order_info;
create table tmp_wq_bnb_user_order_info as
select oi.uid
  , oi.cityid
  , city.cityname
  , oi.productid
  , oi.ts
from
(select uid
  , cityid
  , productid
  , ts
from bnb_product_trace
where d >= '${zdt.addDay(-30).format("yyyy-MM-dd")}'
  and d< = '${zdt.format("yyyy-MM-dd")}') oi
inner join
bnb_recom_city city on oi.cityid = city.cityid


--- 用户收藏的产品
select *
from dw_mobdb.favorites_all
where biztype = 'GUESTHOUSE'

SELECT productid
  , COUNT (DISTINCT uid) as num
FROM dw_mobdb.favorites_all
where biztype = 'GUESTHOUSE'
AND d>='2017-01-01'
GROUP BY productid