

use bnb_hive_db;
drop table bnb_recom_city_image;
CREATE TABLE bnb_recom_city_image(
  cityid int COMMENT '城市Id'
  , cityname string COMMENT '城市名'
  , image string COMMENT '城市图片'
)COMMENT '基础城市表图片';



-- 海外城市
use bnb_hive_db;
INSERT INTO TABLE bnb_recom_city_image
VALUES
('62','马六甲','https://images4.c-ctrip.com/target/fd/tg/g6/M04/08/AA/CggYtFbig8mAe5Q8ACu5mv9jyBE242.jpg')
,('1228','皮皮岛','https://images4.c-ctrip.com/target/100b0h0000008r2ihF9A4.jpg')
,('1225','兰卡威','https://images4.c-ctrip.com/target/100708000000340a7E9A3.jpg')
,('1391','长滩岛','https://images4.c-ctrip.com/target/fd/tg/g6/M02/1F/82/CggYslbMz0yAf9oPAAJvr1DoSnc358.jpg')
,('1369','暹粒','https://images4.c-ctrip.com/target/1006090000003v5f0914C.jpg')
,('1356','岘港','https://images4.c-ctrip.com/target/tg/001/606/652/77b5344f32b0456a97eeef7f73058ad3.jpg')
,('3764','象岛','https://images4.c-ctrip.com/target/10030800000033vev96C9.jpg')
,('4257','薄荷岛','https://images4.c-ctrip.com/target/fd/tg/g6/M0B/55/64/CggYtFa04cOAVIzbAAN-MSEU1QM630.jpg')
,('5204','大叻','https://images4.c-ctrip.com/target/100v0f0000007hp069C10.jpg')
,('5649','富国岛','https://images4.c-ctrip.com/target/100e0l000000d0a2kDB24.jpg')
,('35981','拜县','https://images4.c-ctrip.com/target/fd/tg/g2/M05/67/C1/Cghzf1WkvlyAf7ZhABxVTqP9BuE077.jpg')
,('641','札幌','https://images4.c-ctrip.com/target/fd/tg/g4/M09/A7/51/CggYHVZAVmyAP6ayABH0htawvD8437.jpg')
,('625','槟城','https://images4.c-ctrip.com/target/10060g00000087cgn81BC.jpg')
,('410','仁川','https://images4.c-ctrip.com/target/10040e0000006zsu3A398.jpg')
,('364','马尼拉','https://images4.c-ctrip.com/target/100b0g000000836gfA98F.jpg')
,('5589','屏东','https://images4.c-ctrip.com/target/100b0n000000e7h8w5269.jpg')
,('7203','金门','https://images4.c-ctrip.com/target/tg/137/394/208/667667cb6928474a868f90a0afcf0c16.jpg')
,('7614','宜兰','https://images4.c-ctrip.com/target/tg/520/469/857/e5745d2fd94d4c9ba0d599714af238d7.jpg')
,('3848','台东','https://images4.c-ctrip.com/target/fd/tg/g3/M06/31/7E/CggYGlYmBOeAUtSVABHNXhLTBgw376.jpg')
,('7570','桃园','https://images4.c-ctrip.com/target/tg/451/524/117/b206bbfe86834ba8889f03af8f2c59a9.jpg')
-- ,('1210','黄金海岸','https://images4.c-ctrip.com/target/10030g0000008nrrd8E73.jpg')

--国内城市
use bnb_hive_db;
INSERT INTO TABLE bnb_recom_city_image
VALUES
('36', '大理市', 'https://images4.c-ctrip.com/target/fd/tg/g1/M0A/79/E5/CghzfFWwqDiAFQtgAAhcsJYs-b0709.jpg')
,('258','福州','https://images4.c-ctrip.com/target/100p0h0000008w4eo9DFB.jpg')
,('403','黟县','https://images4.c-ctrip.com/target/10040g0000007tf752C78.jpg')
,('20','淳安','https://images4.c-ctrip.com/target/tg/651/372/901/7f042efd11684e6e947e30c214fa9eb2.jpg')
,('310','蓬莱','https://images4.c-ctrip.com/target/tg/654/807/714/33552fb211964097a8faaf442d8031e5.jpg')
,('460','桐庐','https://images4.c-ctrip.com/target/fd/tg/g1/M02/F7/D2/CghzflW7DE2Acy1XAAh7Fd1zxDQ593.jpg')
,('21286','雷山','https://images4.c-ctrip.com/target/100g0b0000005qq447A87.jpg')
,('344','庐山','https://images4.c-ctrip.com/target/fd/tg/g1/M02/60/3A/CghzfFWvc1KAKxURABfuKZzILvc343.jpg')
,('569','临沂','https://images4.c-ctrip.com/target/100v0e00000076jj257B5.jpg')
,('1300','营口','https://images4.c-ctrip.com/target/fd/tg/g5/M05/03/03/CggYsFbLCESAXhipAAER9clnbiY197.jpg')
,('510','信阳','https://images4.c-ctrip.com/target/100g0e00000070cx7B926.jpg')
,('542','淄博','https://images4.c-ctrip.com/target/100i0p000000fjgfvED22.jpg')
,('1052','昌黎','https://images4.c-ctrip.com/target/100f0q000000gar968DAA.jpg')
--,('21172','昭平','https://images4.c-ctrip.com/target/100u070000002nlakAA0C.jpg')
--,('21416','南靖','https://images4.c-ctrip.com/target/fd/tg/g4/M02/4A/2D/CggYHFXjxtyANZN9ABZLLkbhrJw602.jpg')
--,('392','平潭','https://images4.c-ctrip.com/target/100w0p000000foqjc9B61.jpg')
--,('222','登封','https://images4.c-ctrip.com/target/100w0700000020y1d7748.jpg')
,('340','廊坊','https://images4.c-ctrip.com/target/tg/299/524/609/252ccecafae5498ba7e4f44677490b18.jpg')
--,('2049','修武','https://images4.c-ctrip.com/target/tg/781/656/383/dadcac28e468425b85db97f66ab71714.jpg')
,('601','株洲','https://images4.c-ctrip.com/target/tg/869/605/388/1dfff4adabda4394bb66de2a55056d5d.jpg')
,('3277','雅安','https://images4.c-ctrip.com/target/fd/tg/g4/M0B/1E/F9/CggYHVXBdn-AV-eMAAtReke1yTo143.jpg')
,('1006','宣城','https://images4.c-ctrip.com/target/fd/tg/g2/M00/2E/23/Cghzf1W2KXqATW4FAANfkFKwDxM896.jpg')
--,('21807','丘北','https://images4.c-ctrip.com/target/10090e0000006zdv026B2.jpg')
--,('2594','东山','https://images4.c-ctrip.com/target/fd/tg/g6/M07/51/7B/CggYslb-RSyAISftAARl9PGR6iA907.jpg')
,('201','常德','https://images4.c-ctrip.com/target/tg/452/520/214/049255d5d2f74bac852451aa9ef9488f.jpg')
--,('2442','建水','https://images4.c-ctrip.com/target/fd/tg/g2/M01/89/A5/Cghzf1Wwxx-ALWHIAB9Imt9tKiI687.jpg')
--,('868','仙居','https://images4.c-ctrip.com/target/100a0n000000e8k4mD702.jpg')
--,('619','温岭','https://images4.c-ctrip.com/target/fd/tg/g3/M0A/EE/FC/CggYG1X-zBKAfPELAAIbLvzQ9ww780.jpg')
--,('119','华阴','https://images4.c-ctrip.com/target/fd/tg/g3/M09/19/94/CggYGVaPKr2AOFjsACvD23BWhiw641.jpg')
--,('85','永嘉','https://images4.c-ctrip.com/target/100n0a0000004nw3mBCCC.jpg')
,('44','文昌','https://images4.c-ctrip.com/target/100r0p000000fv4jc5CAC.jpg')
,('141','包头','https://images4.c-ctrip.com/target/100u0q000000gbffq655F.jpg')


