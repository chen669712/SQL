--------------------------------------------------------------
--- 将每天民宿用户的埋点数据筛选出来
--------------------------------------------------------------
use bnb_hive_db;
CREATE TABLE bnb_tracelog(
`uid` string COMMENT 'uid',
`vid` string COMMENT 'vid',
`cid` string COMMENT 'cid',   --来自newvlaue
`cityname` string COMMENT '城市名', --来自newvlaue
`country` string COMMENT '城市所属国家', --来自newvlaue
`sid` string COMMENT 'sid',
`pvid` string COMMENT 'pvid',
`ts` string  COMMENT '时间',
`key` string  COMMENT '埋点的key',
`value` string COMMENT '埋点的value',
`pageid` string COMMENT 'page code/id',
`os` string COMMENT '操作系统',
`appversion` string COMMENT 'appversion'
-- `ip` string,
-- `ua` string,
-- `zdate` string,
-- `newvalue` struct<key:string,data:map<string,string>> COMMENT 'newvalue',
-- `systemcode` string COMMENT 'systemcode',
-- `sourceid` string COMMENT 'sourceid'
)COMMENT '无线民宿用户Trace日志表'
PARTITIONED BY (`d` string COMMENT 'date')
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'


insert overwrite table bnb_tracelog
partition(d = '${zdt.addDay(-1).format("yyyy-MM-dd")}')
select uid
	,vid
	,newvalue.data['env_clientcode'] as cid
	,newvalue.data['env_city'] as cityname
	,newvalue.data['env_country']as country
	,sid
	,pvid
	,ts
	,key
	,value
	,pageid
	,newvalue.data['env_os']as os
	,appversion
FROM dw_mobdb.factmbtracelog_hybrid
where d = '${zdt.addDay(-1).format("yyyy-MM-dd")}'
	and key in('100641','100642', 'bnb_inn_list_app_basic', 'bnb_inn_list_h5_basic'  -- 点击搜索
      , '100643','100644','bnb_inn_detail_app_basic', 'bnb_inn_detail_h5_basic'  -- 点击某个产品
      , '100645','100646', 'bnb_inn_booking_app_basic', 'bnb_inn_booking_h5_basic'  -- 立刻预定
      , '100647','100648','bnb_inn_order_app_basic', 'bnb_inn_order_h5_basic' -- 订单提交
      , 'c_bnb_inn_banner_app','c_bnb_inn_home_filter_app','o_bnb_inn_2nd_home_app','c_bnb_inn_home_hot_app'
      , 'o_bnb_inn_product_app','c_bnb_inn_product_app','o_bnb_inn_2nd_list_app','o_bnb_inn_product_app'
      , 'c_bnb_inn_product_app','c_bnb_inn_list_map_app','c_bnb_inn_list_filter_app','o_bnb_inn_detail_similar_app'
      , 'c_bnb_inn_detail_similar_app','c_bnb_inn_detail_collect_app','c_bnb_inn_detail_operate_app'
      , 'o_bnb_inn_order_filling_app','c_bnb_inn_order_filling_app','c_bnb_inn_order_filling_operate_app'
      , 'o_bnb_inn_order_detail_app','c_bnb_inn_order_detail_operate_app','o_bnb_inn_order_finish_app'
      , 'c_bnb_inn_home_prd_history_app' , 'o_bnb_inn_home_prd_history_app'
      , 'o_bnb_inn_comment_app', 'o_bnb_inn_comment_filter_app'  --评论页
      , 'c_bnb_inn_market_app_basic', 'c_bnb_inn_market_h5_basic'  --市场营销活动
      , 'c_bnb_inn_detail_map_detail_app'
      )



-- tracelog的回补
set beginDay='2018-01-01';
set endDay='2018-03-07';
use bnb_hive_db;
insert overwrite table bnb_tracelog
partition(d)
select uid
	,vid
	,newvalue.data['env_clientcode'] as cid
	,newvalue.data['env_city'] as cityname
	,newvalue.data['env_country']as country
	,sid
	,pvid
	,ts
	,key
	,value
	,pageid
	,newvalue.data['env_os']as os
	,appversion
	,d
FROM dw_mobdb.factmbtracelog_hybrid
where d>=${hiveconf:beginDay}
  	and d<${hiveconf:endDay}
	and key in('100641','100642', 'bnb_inn_list_app_basic', 'bnb_inn_list_h5_basic'  -- 点击搜索
      , '100643','100644','bnb_inn_detail_app_basic', 'bnb_inn_detail_h5_basic'  -- 点击某个产品
      , '100645','100646', 'bnb_inn_booking_app_basic', 'bnb_inn_booking_h5_basic'  -- 立刻预定
      , '100647','100648','bnb_inn_order_app_basic', 'bnb_inn_order_h5_basic' -- 订单提交
      -------曝光和点击埋点
      , 'c_bnb_inn_banner_app','c_bnb_inn_home_filter_app','o_bnb_inn_2nd_home_app','c_bnb_inn_home_hot_app'
      , 'o_bnb_inn_product_app','c_bnb_inn_product_app','o_bnb_inn_2nd_list_app','o_bnb_inn_product_app'
      , 'c_bnb_inn_product_app','c_bnb_inn_list_map_app','c_bnb_inn_list_filter_app','o_bnb_inn_detail_similar_app'
      , 'c_bnb_inn_detail_similar_app','c_bnb_inn_detail_collect_app','c_bnb_inn_detail_operate_app'
      , 'o_bnb_inn_order_filling_app','c_bnb_inn_order_filling_app','c_bnb_inn_order_filling_operate_app'
      , 'o_bnb_inn_order_detail_app','c_bnb_inn_order_detail_operate_app','o_bnb_inn_order_finish_app'
      , 'c_bnb_inn_home_prd_history_app' , 'o_bnb_inn_home_prd_history_app'
      )