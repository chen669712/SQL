---获取城市的city图片
use bnb_hive_db;
CREATE TABLE bnb_recom_city(
`cityid` int COMMENT '城市Id（基于酒店的）',
`cityname` string COMMENT '城市名称',
`image` string COMMENT '城市图片',
`praise` string COMMENT '攻略的口碑',
`algorithm` string  COMMENT '城市打分的算法',
`score` float  COMMENT '城市打分',
`valid` int  COMMENT '是否有效，0-无效，1-有效',
`provinceid` int COMMENT '省份Id',
`provincename` string COMMENT '省份名称',
`country` int COMMENT '国家id'
)COMMENT '无线民宿猜你喜欢城市基础表'
PARTITIONED BY (`d` string COMMENT 'date')
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'


use bnb_hive_db;
insert overwrite table bnb_recom_city
partition (d)
SELECT bnb_city.cityid
  , bnb_city.cityname
  , concat("https://images4.c-ctrip.com/target",you_image.FPath) as image
  , you_praise.praise
  , "a1" as algorithm
  , city_score.score
  , 1 as valid
  , bnb_city.provinceid
  , bnb_city.provincename
  , bnb_city.country
FROM(
  select trace.cityid
    , trace.score + oi.score as score
  from
  (select cityid
    , log10(max(nums)) as score
  from tmp_wq_bnb_trace_city
  group by cityid) trace
  inner join (
  select cityid
    , log10 (max(nums)) as score
  from tmp_wq_bnb_order_city
  group by cityid) oi ON oi.cityid=trace.cityid) city_score
LEFT JOIN 
(
  SELECT * FROM ods_htl_groupwormholedb.bnb_city 
  WHERE d='${zdt.addDay(-1).format("yyyy-MM-dd")}') bnb_city ON bnb_city.cityid = city_score.cityid
LEFT JOIN
(SELECT DISTINCT geoid as id
    , globalid AS districtid
  FROM dim_mobdb.City_Map
  WHERE geocategoryid = 3
    AND type = 'gs_district'
    AND d = '${zdt.addDay(-1).format("yyyy-MM-dd")}') city_trans ON city_trans.id = city_score.cityid
LEFT JOIN 
  dw_youdb.fact_gsdestdb_districtinfo you_city ON you_city.districtid = city_trans.districtid
LEFT JOIN 
(
  SELECT *
    , CASE WHEN havecopyright=1 AND
               (userid in (8088257,17887304,9376843,30325244,14542150) AND orgsourcetype=1) 
              OR orgsourcetype in (47,50,55,56) THEN 1 
      ELSE 0 end as authorized
  FROM dw_youdb.fact_gspoidb_photouploadinfo
  WHERE d='${zdt.format("yyyy-MM-dd")}') you_image on you_image.photouploadinfoid=you_city.coverimageid
LEFT JOIN bnb_hive_db.bnb_you_praise you_praise on you_praise.cityname = bnb_city.cityname
WHERE you_city.publishstatus = 6
  and you_image.authorized = 1;






-- Step 1. 统计每个城市的订单
use bnb_hive_db;
drop table if exists tmp_wq_bnb_order_city;
create table tmp_wq_bnb_order_city as
select cityid
  , row_number() over(partition by cityid order by ordertime) nums
from bnb_orderinfo
where to_date(ordertime) >= '${zdt.addDay(-15).format("yyyy-MM-dd")}'
  and d = '${zdt.addDay(-1).format("yyyy-MM-dd")}';


-- Step 2. 统计每个城市的PV
use bnb_hive_db;
drop table if exists tmp_wq_bnb_trace_city;
create table tmp_wq_bnb_trace_city as
SELECT get_json_object(value, '$.cityid') AS cityid
  , row_number() over (partition by get_json_object(value, '$.cityid') order by ts) nums
FROM bnb_hive_db.bnb_tracelog
WHERE d = '${zdt.addDay(-10).format("yyyy-MM-dd")}'
  and key in('100641','100642', 'bnb_inn_list_app_basic', 'bnb_inn_list_h5_basic')
  and get_json_object(value, '$.cityid') is not null;

-- Step 3. 统计每个城市的score
use bnb_hive_db;
drop table if exists tmp_wq_bnb_city_score;
create table tmp_wq_bnb_city_score as
select trace.cityid
  , bc.cityname
  , case when oi.score is null then trace.score
      else oi.score + trace.score
    end as score
  , bc.provinceid
  , bc.provincename
  , case when cityname in ('台中','台东','台南','嘉义','屏东','高雄','金门','南投','桃园','宜兰','新北市','澎湖') then 0 ---港澳台的城市country设置为0
      else bc.country
    end as country
from
(select cityid
  , log10(max(nums)) as score
from tmp_wq_bnb_trace_city
group by cityid) trace
left outer join
(select cityid
  , log10 (max(nums)) as score
from tmp_wq_bnb_order_city
group by cityid) oi ON oi.cityid=trace.cityid
inner join
(select *
from ods_htl_groupwormholedb.bnb_city
where d = '${zdt.addDay(-1).format("yyyy-MM-dd")}') bc ON bc.cityid = trace.cityid;


-- Step 4. 获取每个城市的图片
use bnb_hive_db;
drop table if exists tmp_wq_bnb_city_image;
create table tmp_wq_bnb_city_image as
select cm.cityid
  , concat("https://images4.c-ctrip.com/target",fgp.FPath) as image
from
(SELECT DISTINCT geoid as cityid
    , globalid AS districtid
FROM dim_mobdb.City_Map
WHERE d = '${zdt.addDay(-1).format("yyyy-MM-dd")}'
  and geocategoryid = 3
  and type = 'gs_district') cm
inner join
(select *
from dw_youdb.fact_gsdestdb_districtinfo
where publishstatus = 6) fgd ON fgd.districtid = cm.districtid
inner join
(SELECT *
    , CASE WHEN havecopyright=1 AND
               (userid in (8088257,17887304,9376843,30325244,14542150) AND orgsourcetype=1)
              OR orgsourcetype in (47,50,55,56) THEN 1
      ELSE 0 end as authorized
FROM dw_youdb.fact_gspoidb_photouploadinfo
WHERE d='${zdt.format("yyyy-MM-dd")}') fgp on fgp.photouploadinfoid=fgd.coverimageid
where fgp.authorized = 1;

-- Step 5. 计算每个城市的价格
use bnb_hive_db;
drop table if exists tmp_wq_bnb_city_price;
create table tmp_wq_bnb_city_price as
select oi.cityid
  , cast(oi.gmv/oi.num as decimal(5,0)) as price
from
(select cityid
  , sum(orderamount) as gmv
  , sum (days) as num
from bnb_hive_db.bnb_orderinfo
where d='${zdt.addDay(-1).format("yyyy-MM-dd")}'
  and to_date(ordertime) >= '${zdt.addDay(-60).format("yyyy-MM-dd")}'
  and source in('100', '101')
  and orderamount/days <=800
  and orderamount/days >=100
group by cityid)oi;


-- Step 6. 进行城市分类及筛选
use bnb_hive_db;
insert overwrite table bnb_recom_city
partition (d = '${zdt.format("yyyy-MM-dd")}')
select bcs.cityid
  , bcs.cityname
	, case when brci.image is not null then brci.image
	    else bci.image
	  end as image
	, concat('约￥', bcp.price, '每晚') as praise
  , "a1" as algorithm
	, bcs.score
  , case when brci.image is not null then 1  ---人为强插有效
      when (bci.image is null or bcs.score <= 2.0) then 0
      else 1
    end as valid
  , bcs.provinceid
  , bcs.provincename
  , bcs.country
from tmp_wq_bnb_city_score bcs
left outer join tmp_wq_bnb_city_image bci on bcs.cityid = bci.cityid
left outer join bnb_recom_city_image brci on bcs.cityid = brci.cityid
left outer join
(select *
from tmp_wq_bnb_city_price
where price <=800
  and price >=100) bcp on bcp.cityid = bci.cityid
where bcp.price is not null




----途家豪宅产品
select distinct spaceid from
ods_htl_groupwormholedb.bnb_space_tag
where d = '2018-04-28'
	and tagid = 57



---各大城市的热门产品数量
---在线DB查询
SELECT COUNT(bss.spaceId)
  , bc.cityName
FROM bnb_space_sortscore  bss
LEFT JOIN bnb_space  bs ON bs.spaceId = bss.spaceId
LEFT JOIN bnb_space_address  bsa ON bsa.spaceId = bss.spaceId
LEFT JOIN bnb_city  bc ON bc.cityId = bsa.cityId
WHERE bss.hotProductScore > 0 AND bs.statusId = 2
GROUP BY bsa.cityId;

---------------------------------------------------------备份--------------------------------------------------------------
select dd.districtid, dd.name, dd.enname, dd.isgsshow, dd.coverimageid, concat("https://images4.c-ctrip.com/target",raw.FPath) as url,raw.authorized
from( 
  select *
  from dw_youdb.fact_gsdestdb_districtinfo
  where districtid in('189','1','206','28','36','258','32','33','5'
      ,'42','17','34','37','12','375','7','43','2','30','451','14','3','580','477'
      ,'10','25','58','559','4','31')) dd
left join
(
    select *,
            (case when
                 havecopyright=1 and
                 (userid in (8088257,17887304,9376843,30325244,14542150) and orgsourcetype=1) or orgsourcetype in (47,50,55,56)
             then 1 else 0 end) as authorized
    from dw_youdb.fact_gspoidb_photouploadinfo
    where d=current_date
) raw on raw.photouploadinfoid=dd.coverimageid
where dd.publishstatus=6
limit 100


 select 
    globalid as districtid, 
    geoid as htl_id, 
    (case geocategoryid 
     when 1 then 'COUNTRY'
     when 2 then 'PROVINCE'
     when 3 then 'CITY'
     when 4 then 'LOCATION'
     when 5 then 'SIGHTZONE' end) as htl_type 
  from dim_mobdb.City_Map
  where type = 'gs_district' and d=date_sub(current_date,1)
