--------------------------------------------------------------
--- 将每天民宿的订单数据筛选出来
--------------------------------------------------------------
use bnb_hive_db;
CREATE TABLE bnb_order_trace(
	orderid string COMMENT '订单Id'
	, status string COMMENT '订单状态'
	, price string COMMENT '产品的价格'
	, cityid string COMMENT '产品所属城市id'
	, productid string COMMENT '产品Id'
	, spaceid string COMMENT '民宿Id'
	, checkin string COMMENT '入住时间'
	, checkout string COMMENT '离开时间'
	, people string COMMENT '入住人数'
	, source string COMMENT '来源 100：订单填写页，101：订单详情页，102：订单完成页'
	, uid string COMMENT 'user id'
	, key string COMMENT '埋点key'
	, ts string COMMENT '埋点时间'
)COMMENT '无线民宿订单曝光表'
PARTITIONED BY (`d` string COMMENT 'date')

use bnb_hive_db;
insert overwrite table bnb_order_trace
partition(d = '${zdt.addDay(-1).format("yyyy-MM-dd")}')
select get_json_object(value, '$.orderid') as orderid
	, get_json_object(value, '$.status') as status
	, get_json_object(value, '$.price') as price
	, get_json_object(value, '$.cityid') as cityid
	, get_json_object(value, '$.productid') as productid
	, get_json_object(value, '$.spaceid') as spaceid
	, get_json_object(value, '$.checkin') as checkin
	, get_json_object(value, '$.checkout') as checkout
	, get_json_object(value, '$.people') as people
	, case when key='o_bnb_inn_order_filling_app'  then '100'
		when key='o_bnb_inn_order_detail_app'  then '101'
		when key='o_bnb_inn_order_finish_app'  then '102' end as source
	, uid
	, key
	, ts
from bnb_tracelog
where d = '${zdt.addDay(-1).format("yyyy-MM-dd")}'
	and key in('o_bnb_inn_order_filling_app'
	, 'o_bnb_inn_order_detail_app'
	, 'o_bnb_inn_order_finish_app')