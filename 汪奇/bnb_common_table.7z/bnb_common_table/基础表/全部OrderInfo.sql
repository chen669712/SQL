
DW_HtlMainDB.FactHotelOrder
subchannel为(gl_kezhan, h5_kezhan, zby_kezhan)

--------------------------------------------------------------
--- 将每天民宿的订单数据筛选出来
--------------------------------------------------------------
use bnb_hive_db;
CREATE TABLE bnb_orderinfo(
	orderid string COMMENT '订单Id'
	, ordertime string COMMENT '订单提交时间'
	, uid string COMMENT 'user id'
	, productid string COMMENT 'productid'
	, vendorid string COMMENT '民宿的vendorid'
	, checkin string COMMENT 'checkin'
	, checkout string COMMENT 'checkout'
	, days string COMMENT '预定间夜量'
	, orderamount string COMMENT '订单预订金额'
	, orderstatus string COMMENT '订单状态'
	, source string COMMENT '订单来源，100：民宿, 101：客栈宫格，102: 客栈未知， 其它: 客栈其他'
	, cityid string COMMENT '城市id'
	, visitsource string COMMENT '入口来源'
	, sellerid string COMMENT '分销售卖, 0: 民宿宫格，1000:酒店， 1001：酒店-斯维登, null：民宿'
	, agent string COMMENT '代理商， 1：uid = $seller-agent， 0：uid ！= $seller-agent, null：民宿'
	, cid string COMMENT '用户的cid'
	, salesChannel string COMMENT '销售渠道，1：直销，2：分销'
)COMMENT '无线民宿订单表'
PARTITIONED BY (`d` string COMMENT 'date')

use bnb_hive_db;
alter table bnb_orderinfo add columns(salesChannel string COMMENT '销售渠道，1：直销，2：分销');

use bnb_hive_db;
insert overwrite table bnb_orderinfo
partition(d = '${zdt.addDay(-1).format("yyyy-MM-dd")}')
select oo.* from (
  -----客栈订单数据
  select orderid
    , orderdate as ordertime
    , uid
    , hotel as productid
    , null as vendorid
    , to_date(arrival) as checkin
    , to_date(departure) as checkout
    , ordquantity as days
    , ordamount as orderamount
    , orderstatus
    , case when (ordertype_ubt is null and d<'2018-05-25') then '102'  --客栈未知来源
           when (ordertype_ubt is null and d>'2018-05-24') then '101'  --客栈宫格
           when ordertype_ubt = '直接订单' then '101'  --客栈宫格
           else ordertype_ubt end as source
    , cityid
    , null as visitsource
    , null as sellerid
    , null as agent
  	, null as cid
  	, null as salesChannel
  from dw_htlmaindb.FactHotelOrder_All_Inn
  where d= '${zdt.format("yyyy-MM-dd")}'
 --   and to_date(orderdate) < '${zdt.format("yyyy-MM-dd")}'
    and to_date(orderdate) >= '2017-01-01'
    and to_date(orderdate) < '${zdt.format("yyyy-MM-dd")}'
    and (ordertype_ubt not in('hotel_order') or ordertype_ubt is null)

  union all
  -----老的民宿订单数据
  select old.orderid
    , old.ordertime
    , old.uid
    , old.productid
    , old.vendorid
    , old.checkin
    , old.checkout
    , old.days
    , old.orderamount
    , old.orderstatus
    , '100-1' as source
    , bsa.cityid
    , null as visitsource
    , null as sellerid
    , null as agent
  	, null as cid
  	, null as salesChannel
  from
  (select ctriporderid as orderid
      , createtime as ordertime
      , uid
      , productid
      , vendorid
      , checkin
      , checkout
      , datediff(to_date(checkout),to_date(checkin)) as days
      , totalamount as orderamount
      , statusid as orderstatus
  from ods_htl_groupwormholedb.bnb_order
  where d='${zdt.format("yyyy-MM-dd")}'
   	and to_date(createtime) >='2017-01-01'
   	and to_date(createtime) <'${zdt.format("yyyy-MM-dd")}'
    and saleamount>=20) old
  left join
  (select spaceid
    , cityid
  from ods_htl_groupwormholedb.bnb_space_address
  where d='${zdt.format("yyyy-MM-dd")}' ) bsa on old.productid = bsa.spaceid

  union all
  -----新的民宿订单数据
  select ohv.orderId as orderid
    , ohv.createdtime as ordertime
    , ohv.uid
    , oi.productid
    , oi.vendorid
    , ois.checkin
    , ois.checkout
    , datediff(to_date(ois.checkout),to_date(ois.checkin)) as days
    , oi.saleamount as orderamount
    , ohv.orderstatusid as orderstatus
    , '100' as source
    , ois.cityid
    , ohv.visitsource
    , ohv.sellerid
    , case when ohv.uid = '$seller-agent' then '1'
      else '0' end as agent
  	, ohv.clientid as cid
  	, ohv.salesChannel
  from
  (select *
  from ods_htl_bnborderdb.order_header_v2
  where d='${zdt.format("yyyy-MM-dd")}'
    and to_date(createdtime) >='2017-01-01'
   	and to_date(createdtime) <'${zdt.format("yyyy-MM-dd")}'
  ) ohv
  inner join
  ( select old.saleamount
      ,old.vendorid
      ,old.orderid
      ,old.orderitemid
      ,bsp.spaceid as productid
    from
    (select *
    from ods_htl_bnborderdb.order_item
    where d='${zdt.format("yyyy-MM-dd")}'
      and saleamount >=20
      and (statusid like '12%'   -- 支付成功
      or statusid like '20%'   -- 待退款
      or statusid like '22%'   -- 	部分退款
      or statusid like '23%')  -- 已退款
      and vendorid >= 114) old
    inner join
    (select productid
      ,spaceid
    from ods_htl_groupwormholedb.bnb_space_product
    where d='${zdt.format("yyyy-MM-dd")}')bsp on old.productid = bsp.productid

    union all

    select saleamount
      ,vendorid
      ,orderid
      ,orderitemid
      ,productid
    from ods_htl_bnborderdb.order_item
    where d='${zdt.format("yyyy-MM-dd")}'
      and saleamount >=20
      and (statusid like '12%'
        or statusid like '20%'
        or statusid like '22%'
        or statusid like '23%')
      and vendorid < 114) oi on oi.orderid=ohv.orderid
  inner join
  (select *
    from ods_htl_bnborderdb.order_item_space
    where d='${zdt.format("yyyy-MM-dd")}') ois on ois.orderitemid=oi.orderitemid
)oo


set beginDay= '2018-01-01';
set endDay= '2018-05-01';
set calcDay= '2018-05-01';
select c.day
  ,sum(c.directorder) as totalorder
  from
  (select to_date(a.orderdate) as day
    ,count(distinct a.uid) as directorder
  from dw_htlmaindb.FactHotelOrder_All_Inn a
  where to_date(a.orderdate)>=${hiveconf:beginDay}
    and to_date(a.orderdate)<=${hiveconf:endDay}
    and a.d=${hiveconf:calcDay}
    and (a.ordertype_ubt not in ('hotel_order') or a.ordertype_ubt is null)
  group by to_date(a.orderdate)


  union all

  select b2.day
    ,count(distinct b2.uid) as directorder
  from
  (select to_date(b1.createdtime) as day
    ,b1.uid
    ,datediff(to_date(c1.checkout),to_date(c1.checkin))*(a1.quantity) as output
  from ods_htl_bnborderdb.order_item a1
  left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d=${hiveconf:calcDay}
  left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d=${hiveconf:calcDay}
  where to_date(b1.createdtime)<=${hiveconf:endDay}
    and to_date(b1.createdtime)>=${hiveconf:beginDay}
    and a1.saleamount>=20
    and a1.d=${hiveconf:calcDay}
    and b1.sellerid = 0) b2
  group by b2.day)c
group by c.day