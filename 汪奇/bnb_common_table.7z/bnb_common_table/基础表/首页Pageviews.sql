--------------------------------------------------------------
--- 将每天从首页进入民宿的用户筛选出来
--------------------------------------------------------------
-- 创建民宿的pageview表
create table bnb_pageview
(starttime string COMMENT '时间'
	, clientversion string COMMENT '版本号'
	, clientcode string COMMENT '用户唯一标识'
	, pagecode string COMMENT '页面code'
	, sessionid string COMMENT 'sessionid'
	, uid string COMMENT '用户登录帐号'
	, sourceid string COMMENT '渠道号'
	, logtype string COMMENT '日志来源类型：native或hybrid'
	, prepagecode string COMMENT '当条记录pagecode的前一个pagecode'
	, prechannel string COMMENT '当条记录的来源频道'
	, category string COMMENT '频道类型'
	, pagename string COMMENT '页面'
	, cityid string COMMENT '城市id'
	, cityname string COMMENT '城市'
	, countryname string COMMENT '国家'
	, sid string COMMENT 'sid'
	, pvid string COMMENT 'pvid'
	, standard_version string COMMENT 'standard_version'
--	, systemcode string COMMENT '无线平台'
--	, vid string COMMENT 'vid'
--	, insertdt string COMMENT '插入时间'
--	, logdate string COMMENT 'logdate'
--	, idfa string COMMENT 'idfa'
--	, imei string COMMENT 'imei'
--	, mac string COMMENT 'mac'
--	, ouid string COMMENT 'ouid'
--	, extendsourceid string COMMENT 'extendsourceid'
--	, allianceid string COMMENT 'allianceid'
--	, siteid string COMMENT 'siteid'
--	, orderid string COMMENT '订单号'
--	, clientip string COMMENT '用户ip'
--	, ssid string COMMENT 'sessionid:concat(d,clientcode,ssid)'
--	, preprechannel string COMMENT '当条记录的往前两个频道来源'
--	, categorynew string COMMENT '频道'
--	, process string COMMENT '主要步骤说明'
--	, provincename string COMMENT '省份'
--	, serviceprovider string COMMENT 'serviceprovider'
--	, host string COMMENT 'host'
--	, path string COMMENT 'path'
--	, query string COMMENT 'query'
--	, channelid string COMMENT 'channelid'
--	, userlanguage string COMMENT 'userlanguage'
--	, operationsystem string COMMENT 'operationsystem'
--	, referer string COMMENT 'referer'
--	, mbpvid string COMMENT 'tag'
--	, language string COMMENT 'language'
--	, appname string COMMENT 'appname'
--	, cracked string COMMENT 'cracked'
--	, frompage string COMMENT 'frompage'
--	, subchannel string COMMENT 'subchannel'
	)COMMENT '无线民宿用户页面级日志表'
PARTITIONED BY (`d` string COMMENT 'test')
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde'WITH SERDEPROPERTIES ( 'serialization.format' = '1')
STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat' OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat';


-- 存储每天的民宿用户，作为一个定时任务启动
use bnb_hive_db;
insert overwrite into table bnb_pageview
partition (d = '${zdt.addDay(-1).format("yyyy-MM-dd")}')
select pv.* from
(select distinct clientcode
  from dw_mobdb.factmbpageview
  where d= '${zdt.addDay(-1).format("yyyy-MM-dd")}'
  and pagecode in ('600003560', '10320675332')  --- '10320675332'是海外民宿的首页pageid
  and prepagecode in ('home', '215019', '0')
  and clientcode is not null
  and clientcode not in ('','00000000000000000000')) bnb
left outer join
(select starttime
	, clientversion
	, clientcode
	, pagecode
	, sessionid
	, uid
	, sourceid
	, logtype
	, prepagecode
	, prechannel
	, category
	, pagename
	, cityid
	, cityname
	, countryname
	, sid
	, pvid
	, standard_version
from dw_mobdb.factmbpageview
where d= '${zdt.addDay(-1).format("yyyy-MM-dd")}'
  and clientcode is not null
  and clientcode not in ('','00000000000000000000')) pv on bnb.clientcode = pv.clientcode
where pv.clientcode is not null;



--------------------------------------------------------------
--- 数据回补
--------------------------------------------------------------
-- pageview的回补
set beginDay='2017-12-01';
set endDay='2018-01-01';
use bnb_hive_db;
insert overwrite table bnb_pageview
partition (d)
select pv.starttime
	, pv.clientversion
	, pv.clientcode
	, pv.pagecode
	, pv.sessionid
	, pv.uid
	, pv.sourceid
	, pv.logtype
	, pv.prepagecode
	, pv.prechannel
	, pv.category
	, pv.pagename
	, pv.cityid
	, pv.cityname
	, pv.countryname
	, pv.sid
	, pv.pvid
	, pv.standard_version
	, pv.d
from
(select distinct d, clientcode
  from dw_mobdb.factmbpageview
  where d>=${hiveconf:beginDay}
  and d<${hiveconf:endDay}
  and pagecode in ('600003560', '10320675332')  --- '10320675332'是海外民宿的首页pageid
  and prepagecode in ('home', '215019', '0')
  and clientcode is not null
  and clientcode not in ('','00000000000000000000')) bnb
inner join
(select starttime
	, clientversion
	, clientcode
	, pagecode
	, sessionid
	, uid
	, sourceid
	, logtype
	, prepagecode
	, prechannel
	, category
	, pagename
	, cityid
	, cityname
	, countryname
	, sid
	, pvid
	, standard_version
	, d
from dw_mobdb.factmbpageview
where d>=${hiveconf:beginDay}
  and d<${hiveconf:endDay}
  and clientcode is not null
  and clientcode not in ('','00000000000000000000')) pv on bnb.clientcode = pv.clientcode and bnb.d=pv.d
where pv.clientcode is not null;