CREATE TABLE `bnb_product_trace`(
  `productid` string COMMENT '产品Id',
  `spaceid` string COMMENT '民宿Id',
  `parentpid` string COMMENT 'source=200 专用, 源民宿productid',
  `parentsid` string COMMENT 'source=200 专用, 源民宿spaceid',
  `cityid` string COMMENT '产品所属城市id',
  `uid` string COMMENT 'user id',
  `price` string COMMENT '产品折扣价格，券减后的价格',
  `orgprice` string COMMENT '产品原始价格',
  `ticketprice` string COMMENT '优惠券价格',
  `checkin` string COMMENT '入住时间',
  `checkout` string COMMENT '离开时间',
  `score` string COMMENT '用户评分',
  `comments` string COMMENT '评论数',
  `duration` string COMMENT '房东确认时长',
  `rating` string COMMENT '房东成功率',
  `labels` string COMMENT '房屋特色',
  `poi` string COMMENT '所处位置',
  `distance` string COMMENT 'source=200 专用,距离',
  `pos` string COMMENT '页面展示的位置',
  `source` string COMMENT '来源 100-首页特卖，101-首页推荐，102-列表页, 103- 列表页无结果推荐， 105- 猜你喜欢的产品列表页， 200:详情页的相似， 300：首页浏览历史',
  `type` string COMMENT '类型，100：曝光，101：点击',
  `key` string COMMENT '埋点key',
  `ts` string COMMENT '埋点时间',
  `cid` string COMMENT '用户的cid')
COMMENT '无线民宿产品点击曝光表'
PARTITIONED BY (`d` string COMMENT 'date')
ROW FORMAT SERDE  'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
STORED AS INPUTFORMAT  'org.apache.hadoop.hive.ql.io.orc.OrcInputFormat'
OUTPUTFORMAT  'org.apache.hadoop.hive.ql.io.orc.OrcOutputFormat'


use bnb_hive_db;
insert overwrite table bnb_product_trace
partition(d = '${zdt.addDay(-1).format("yyyy-MM-dd")}')
select get_json_object(value, '$.productid') as productid
	, get_json_object(value, '$.spaceid') as spaceid
	, get_json_object(value, '$.orgproductid') as parentpid
	, get_json_object(value, '$.orgspaceid') as parentsid
	, get_json_object(value, '$.cityid') as cityid
	, uid
	, get_json_object(value, '$.price') as price
	, get_json_object(value, '$.orgprice') as orgprice
	, get_json_object(value, '$.ticketprice') as ticketprice
	, get_json_object(value, '$.checkin') as checkin
	, get_json_object(value, '$.checkout') as checkout
	, get_json_object(value, '$.score') as score
	, get_json_object(value, '$.comments') as comments
	, get_json_object(value, '$.duration') as duration
	, get_json_object(value, '$.rating') as rating
	, get_json_object(value, '$.labels') as labels
	, get_json_object(value, '$.poi') as poi
	, get_json_object(value, '$.distance') as distance
	, get_json_object(value, '$.pos') as pos
	, case when (key='c_bnb_inn_detail_similar_app' or key='o_bnb_inn_detail_similar_app') then '200'
	    when (key='c_bnb_inn_home_prd_history_app' or key='o_bnb_inn_home_prd_history_app') then '300'
		else get_json_object(value, '$.source') end as source
	, case when (key='c_bnb_inn_product_app'
			or key='c_bnb_inn_detail_similar_app'
			or key='c_bnb_inn_home_prd_history_app') then '101'
		else '100' end as type
	, key
	, ts
    , cid
from bnb_tracelog
where d = '${zdt.addDay(-1).format("yyyy-MM-dd")}'
	and key in('c_bnb_inn_product_app'
	, 'o_bnb_inn_product_app'
	, 'o_bnb_inn_detail_similar_app'
	, 'c_bnb_inn_detail_similar_app'
	, 'c_bnb_inn_home_prd_history_app'
	, 'o_bnb_inn_home_prd_history_app'
	)
