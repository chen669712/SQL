use bnb_hive_db;
select detail.d
  , count (distinct detail.cid) as uv
  , count (distinct click.cid) as click
  , count (distinct oi.orderid) as num
from
(select distinct d
  , cid
from bnb_tracelog
where d>='2018-07-01'
  and key='o_bnb_inn_detail_app'
  and get_json_object(value, '$.channelId') = '0') detail
left outer join
(select distinct d
  , cid
from bnb_tracelog
where d>='2018-07-01'
  and key='c_bnb_inn_detail_operate_app'
  and get_json_object(value, '$.source') = '105') click on detail.d=click.d and detail.cid=click.cid
left outer join
(select to_date(ordertime) as d
  , cid
  , orderid
from bnb_orderinfo
where d='2018-07-09')oi on oi.d=detail.d and oi.cid=click.cid
group by detail.d





use bnb_hive_db;
select home.d
  , count (distinct home.cid) as uv
  , count (distinct click.cid) as click
  , count (distinct oi.orderid) as num
from
(select distinct d
  , clientcode as cid
from bnb_hive_db.bnb_pageview
where d>='2018-07-01') home
left outer join
(select distinct d
  , cid
from bnb_tracelog
where d>='2018-07-01'
  and key='c_bnb_inn_banner_app'
  and get_json_object(value, '$.source') = '111') click on home.d=click.d and home.cid=click.cid
left outer join
(select to_date(ordertime) as d
  , cid
  , orderid
from bnb_orderinfo
where d='2018-07-09')oi on oi.d=home.d and oi.cid=click.cid
group by home.d