

------------------搜索相关操作---------------------------
use bnb_hive_db;
select d
	, get_json_object(value, "$.source") as source
	, count(cid) as uv
from bnb_tracelog
where key = 'c_bnb_inn_home_filter_app'
	and d>='2018-06-01'
group by d, get_json_object(value, "$.source")

------------------点击搜索操作---------------------------
use bnb_hive_db;
select d
	, key
	, count(distinct cid) as uv
from bnb_tracelog
where d>='2018-06-01'
	and key in('bnb_inn_list_app_basic', '100641')
group by d, key


------------------页面功能操作---------------------------
use bnb_hive_db;
select d
	, get_json_object(value, "$.source") as source
	, count(distinct cid) as uv
from bnb_tracelog
where key = 'c_bnb_inn_banner_app'
	and d>='2018-06-01'
group by d, get_json_object(value, "$.source")


------------------获取进入首页UV---------------------------
use bnb_hive_db;
select d
	, count(distinct clientcode) as uv
from bnb_pageview
where d>='2018-06-01'
	and pagecode='600003560'
group by d


use bnb_hive_db;
select recom.d
  , count (distinct recom.cid) as uv
  , sum(if(trace.cid is null, 1, 0)) as 'recom'
  , sum(if(trace.cid is not null, 1, 0)) as 'all'
from
(select distinct d
  , cid
from bnb_tracelog
where key='c_bnb_inn_home_recom_app'
  and d>='2018-06-01')recom
left outer join
(select distinct d
	, cid
from bnb_tracelog
where d>='2018-06-01'
	and key in('bnb_inn_list_app_basic', '100641')) trace on recom.d = trace.d and recom.cid = trace.cid
group by recom.d;



