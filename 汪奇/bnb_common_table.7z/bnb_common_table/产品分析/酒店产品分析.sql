select dhmh.masterhotelid as `母酒店Id`
	, dhmh.hotelname  as `酒店名称`
	, brm.partnerhotelid  as `子酒店Id`
	, room.room as `酒店子房型Id`
	, room.roomname as `酒店子房型名称`
  , bses.spaceid as `民宿房型Id`
	, bses.feedesc as `收费描述`
from
(select spaceid
from ods_htl_groupwormholedb.bnb_space
where d='2018-07-08'
	and statusid=2
group by spaceid) bs
inner join
(select spaceid
	, collect_set(concat(name, description)) as feedesc
from ods_htl_groupwormholedb.bnb_space_extra_service
where d='2018-07-08'
	and feetype='T'
group by spaceid) bses on bses.spaceid=bs.spaceid
inner join
(select distinct roomid
  , partnerroomid
  , partnerhotelid
from ods_htl_groupwormholedb.bnb_room_mapping
where d='2018-07-08') brm on brm.roomid=bses.spaceid
inner join
(select distinct room
  , hotel
  , roomname
from dim_htldb.dimroom ) room on room.hotel = brm.partnerhotelid and room.room = brm.partnerroomid
inner join
(select distinct hotel
  ,masterhotelid
  ,hotelname
from dim_htldb.dimhtlhotel) dhmh on dhmh.hotel = room.hotel
--where brm.roomid is not null
limit 10000


-------------------------------------------------------
-- 获取分销的产品
-------------------------------------------------------
select dhmh.masterhotelid as `母酒店Id`
	, dhmh.hotelname  as `酒店名称`
	, brm.partnerhotelid  as `子酒店Id`
	, room.room as `酒店子房型Id`
	, room.roomname as `酒店子房型名称`
  , bs.spaceid as `民宿房型Id`
from
(select spaceid
from ods_htl_groupwormholedb.bnb_space
where d='2018-07-08'
	and statusid=2
group by spaceid) bs
inner join
(select distinct roomid
  , partnerroomid
  , partnerhotelid
from ods_htl_groupwormholedb.bnb_room_mapping
where d='2018-07-08') brm on brm.roomid=bs.spaceid
inner join
(select distinct room
  , hotel
  , roomname
from dim_htldb.dimroom ) room on room.hotel = brm.partnerhotelid and room.room = brm.partnerroomid
inner join
(select distinct hotel
  ,masterhotelid
  ,hotelname
from dim_htldb.dimhtlhotel) dhmh on dhmh.hotel = room.hotel
where dhmh.masterhotelid='9536670'