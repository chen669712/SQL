
select bpt.d as `日期`
  , bpt.cityid as `城市`
  , bpt.productid as `产品Id`
  , bs.name as `产品名称`
  , bpt.type as `类型`
  , bpt.num as `次数`
  , case when oi.num is null then '0'
    else oi.num end as `订单数`
from
(select d
  , cityid
  , productid
  , type
  , count(1) as num
from bnb_hive_db.bnb_product_trace
where d>='2018-05-01'
  and source = '102'
  and cityid in(359, 617)
group by d, cityid, productid,type) bpt
left outer join
(select spaceid
    , name
  from ods_htl_groupwormholedb.bnb_space
  where d= '2018-05-17') bs on bpt.productid = bs.spaceid
left outer join
(select to_date(ordertime) as d
  , cityid
  , productid
  , count(distinct orderid) as num
from bnb_hive_db.bnb_orderinfo
where d = '2018-05-17'
  and to_date(ordertime) >'2018-05-01'
  and cityid in(359, 617)
group by to_date(ordertime)
  , cityid
  , productid) oi on bpt.d = oi.d and bpt.productid=oi.productid
