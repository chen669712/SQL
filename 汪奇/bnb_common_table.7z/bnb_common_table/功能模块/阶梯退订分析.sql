-----------------------------------------------------
-- 天津  3
-- 大连  6
-- 哈尔滨 5
-- 北海 189
-- 婺源 489
-- 大同 136
-- 保定 185
-- 支持阶梯退订
'3', '6', '5', '189', '489', '136', '185'
-----------------------------------------------------

--------------------
--点击预定按键UV / 产品详情页曝光UV
use bnb_hive_db;
set beginDay= '2018-05-09';
set endDay= '2018-05-14';
set calcDay= '2018-05-13';
select detail.d
  , count (distinct detail.cid) as `详情页UV`
  , count (distinct fill.cid) as `预订页UV`
  , count (distinct pay.cid) as `预订页UV`
  , count (distinct oi.cid) as `成功订单UV`
  , count (distinct oi.orderid) as `成功订单数`
from
(select distinct d
  , cid
from bnb_product_trace
where d >=${hiveconf:beginDay}
  and cityid in ('3', '6', '5', '189', '489', '136', '185')
  and d<${hiveconf:endDay}) detail
left join
(select distinct d
  , cid
from bnb_tracelog
where d >=${hiveconf:beginDay}
  and d<${hiveconf:endDay}
  and get_json_object(value, '$.cityid') in ('3', '6', '5', '189', '489', '136', '185')
  and key = 'o_bnb_inn_order_filling_app') fill on detail.d = fill.d and detail.cid = fill.cid
left join
(select distinct d
  , cid
from bnb_tracelog
where d >=${hiveconf:beginDay}
  and d<${hiveconf:endDay}
  and get_json_object(value, '$.cityid') in ('3', '6', '5', '189', '489', '136', '185')
  and key in ('bnb_inn_order_app_basic','100647')) pay on detail.d = pay.d and detail.cid = pay.cid
left join
(select distinct to_date(ordertime) as d
  , orderid
  , cid
from bnb_orderinfo
where d = ${hiveconf:calcDay}
  and to_date(ordertime) >= ${hiveconf:beginDay}
  and to_date(ordertime) < ${hiveconf:endDay}
  and cityid in ('3', '6', '5', '189', '489', '136', '185')
  and source = '100') oi on detail.d = oi.d and detail.cid = oi.cid
group by detail.d


----------------------------------------------------------
---查看每个城市的UV及订单
----------------------------------------------------------
use bnb_hive_db;
set beginDay= '2018-05-09';
set endDay= '2018-05-14';
set calcDay= '2018-05-13';
select home.d
  , home.cityid
  , home.uv as `首页UV`
  , detail.uv as `详情页UV`
  , fill.uv as `预订页UV`
  , pay.uv as `支付页UV`
  , oi.uv as `成功订单UV`
  , oi.oi as `成功订单数`
from
(select d
  , get_json_object(value, '$.cityid') as cityid
  , count (distinct cid) as uv
from bnb_tracelog
where d >=${hiveconf:beginDay}
  and d<${hiveconf:endDay}
  and key in('bnb_inn_list_app_basic', '100641')
group by d, get_json_object(value, '$.cityid')) home
left join
(select d
  , get_json_object(value, '$.cityid') as cityid
  , count (distinct cid) as uv
from bnb_tracelog
where d >=${hiveconf:beginDay}
  and d<${hiveconf:endDay}
  and key in('bnb_inn_detail_app_basic', '100643')
group by d, get_json_object(value, '$.cityid')) detail on home.d=detail.d and home.cityid=detail.cityid
left join
(select d
  , get_json_object(value, '$.cityid') as cityid
  , count (distinct cid) as uv
from bnb_tracelog
where d >=${hiveconf:beginDay}
  and d<${hiveconf:endDay}
  and key = 'o_bnb_inn_order_filling_app'
group by d, get_json_object(value, '$.cityid')) fill on home.d = fill.d and home.cityid = fill.cityid
left join
(select d
  , get_json_object(value, '$.cityid') as cityid
  , count (distinct cid) as uv
from bnb_tracelog
where d >=${hiveconf:beginDay}
  and d<${hiveconf:endDay}
  and key in ('bnb_inn_order_app_basic','100647')
group by d, get_json_object(value, '$.cityid')) pay on home.d = pay.d and home.cityid = pay.cityid
left join
(select to_date(ordertime) as d
  , cityid
  , count (distinct cid) as uv
  , count (distinct orderid) as oi
from bnb_orderinfo
where d = ${hiveconf:calcDay}
  and to_date(ordertime) >= ${hiveconf:beginDay}
  and to_date(ordertime) < ${hiveconf:endDay}
  and source = '100'
group by to_date(ordertime), cityid) oi on home.d = oi.d and home.cityid = oi.cityid
where detail.cityid in ('3', '6', '5', '189', '489', '136', '185')


use bnb_hive_db;
set beginDay= '2018-01-01';
set endDay= '2018-05-14';
set calcDay= '2018-05-14';
select home.d
  , home.cityid
  , home.uv as `首页UV`
  , oi.uv as `成功订单UV`
  , oi.oi as `成功订单数`
from
(select d
  , get_json_object(value, '$.cityid') as cityid
  , count (distinct cid) as uv
from bnb_tracelog
where d >=${hiveconf:beginDay}
  and d<${hiveconf:endDay}
  and key in('bnb_inn_list_app_basic', '100641')
group by d, get_json_object(value, '$.cityid')) home
left join
(select to_date(ordertime) as d
  , cityid
  , count (distinct cid) as uv
  , count (distinct orderid) as oi
from bnb_orderinfo
where d = ${hiveconf:calcDay}
  and to_date(ordertime) >= ${hiveconf:beginDay}
  and to_date(ordertime) < ${hiveconf:endDay}
  and source = '100'
group by to_date(ordertime), cityid) oi on home.d = oi.d and home.cityid = oi.cityid
where detail.cityid in ('3', '6', '5', '189', '489', '136', '185')




----------------------------------------------------------
--- 点击产品的UV
--- 点击立刻预订的UV
----------------------------------------------------------
use bnb_hive_db;
select detail.d
  , detail.uv
  , booking.uv
  , cast(booking.uv/detail.uv as decimal(5,2)) as D2B
from
(select d
  , count (distinct cid) as uv
from bnb_product_trace
where d>='2018-05-09'
  and type = '101'
--  and cityid in ('3', '6', '5', '189', '489', '136', '185')
group by d)detail
join
(select d
  , count (distinct cid) as uv
from bnb_tracelog
where d>='2018-05-09'
 -- and get_json_object(value, '$.cityid') in ('3', '6', '5', '189', '489', '136', '185')
  and key in('o_bnb_inn_order_filling_app')
group by d) booking on detail.d = booking.d

-------------------------------------------------------
-- 预订单
-------------------------------------------------------
select oo.d
  , count (distinct oo.orderid)
from
(select to_date(b1.createdtime) as d
  ,a1.orderid
  ,c1.cityid
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d='2018-05-14'
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d='2018-05-14'
where to_date(b1.createdtime)>='2018-05-09'
  and a1.saleamount>=20 and a1.d='2018-05-14' and b1.sellerid=0) oo
where oo.cityid in ('3', '6', '5', '189', '489', '136', '185')
group by oo.d

-------------------------------------------------------
-- 支付单
-------------------------------------------------------
select oo.d
  , count (distinct oo.orderid)
from
(select to_date(b1.createdtime) as d
  ,a1.orderid
  ,c1.cityid
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d='2018-05-14'
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d='2018-05-14'
where to_date(b1.createdtime)>='2018-05-09'
  and a1.saleamount>=20 and a1.d='2018-05-14'
  and b1.sellerid=0
  and (a1.statusid like '12%' or a1.statusid like '20%' or a1.statusid like '22%' or a1.statusid like '23%')) oo
where oo.cityid in ('3', '6', '5', '189', '489', '136', '185')
group by oo.d

-------------------------------------------------------
-- 取消单
-------------------------------------------------------
select oo.d
  , count (distinct oo.orderid)
from
(select to_date(b1.createdtime) as d
  ,a1.orderid
  ,c1.cityid
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d='2018-05-14'
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d='2018-05-14'
where to_date(b1.createdtime)>='2018-05-09'
  and a1.saleamount>=20 and a1.d='2018-05-14'
  and b1.sellerid=0
  and a1.statusid in (1212,2212,2232,2233)) oo
where oo.cityid in ('3', '6', '5', '189', '489', '136', '185')
group by oo.d




select to_date(ordertime) as d
  , count(distinct orderid) as num
from bnb_orderinfo
where d = '2018-05-14'
  and to_date(ordertime) > '2018-05-08'
  and source = '100'
  and cityid in ('3', '6', '5', '189', '489', '136', '185')