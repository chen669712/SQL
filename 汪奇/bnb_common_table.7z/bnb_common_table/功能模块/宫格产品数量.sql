--获取客栈的产品数---
use ods_htl_groupwormholedb;
select case when country=1 then '国内'
          when country!=1 then '海外' end 'ca'
      ,count(distinct s.spaceid) from bnb_space s
inner join bnb_space_source ss on s.spaceid=ss.spaceid
inner join bnb_space_address sad on sad.spaceid=s.spaceid
inner join bnb_city c on c.cityid=sad.cityid
where s.statusid=2 and ss.vendorid=106
group by ca

