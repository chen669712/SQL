select substring(b1.createdtime, 0, 10) as d
  , b1.terminalType
  , case when b1.visitsource in (0, 20, 70, 120, 130, 201, 203, 205) then 'y'
      else 'n' end as source
  , count (a1.orderid) as ois
  , sum(a1.saleamount) as amount
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d="$effectdate('yyyy-MM-dd',0)"
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d="$effectdate('yyyy-MM-dd',0)"
where substring(b1.createdtime,0,10)>="$effectdate('yyyy-MM-dd',-15)"
  and substring(b1.createdtime,0,10)<"$effectdate('yyyy-MM-dd',0)"
  and (a1.statusid like '12%' OR a1.statusid like '20%' OR a1.statusid like '22%' OR a1.statusid like '23%')
  and a1.saleamount>=20 and a1.d="$effectdate('yyyy-MM-dd',0)" and b1.sellerid=0
group by substring(b1.createdtime, 0, 10)
  , b1.terminalType
  , source



select substring(b1.createdtime, 0, 10) as d
  , b1.terminalType
  , case when b1.visitsource in (0, 20, 70, 120, 130, 201, 203, 205) then 'y'
      else 'n' end as source
  , count (a1.orderid) as ois
  , sum(a1.saleamount) as amount
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d='2018-06-18'
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d='2018-06-18'
where substring(b1.createdtime,0,10)>='2018-06-10'
  and substring(b1.createdtime,0,10)<'2018-06-18'
  and (a1.statusid like '12%' OR a1.statusid like '20%' OR a1.statusid like '22%' OR a1.statusid like '23%')
  and a1.saleamount>=20 and a1.d='2018-06-18' and b1.sellerid=0
group by substring(b1.createdtime, 0, 10)
  , b1.terminalType
  , source