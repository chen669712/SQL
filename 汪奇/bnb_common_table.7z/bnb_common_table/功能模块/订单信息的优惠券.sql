
---------------------------------------------------------------
-- 算优惠券的占比
---------------------------------------------------------------
select aa.d
  , aa.type
  , aa.oinum as `总订单数`
  , aa.ticketnum as `使用券订单数`
  , aa.oiamount as `订单总金额`
  , aa.ticketamount as `优惠券总金额`
  , concat(cast(100*((aa.ticketamount)/aa.oiamount) as decimal(5,2)),'%') as `赔付率`
  , concat(cast(100*((aa.ticketnum)/aa.oinum) as decimal(5,2)),'%') as `使用率`
from
(select oi.d
  , 0 as type
  , sum(if(ticket.paychannel=10, 1, 0)) as oinum
  , sum(if(ticket.paychannel=11, 1, 0)) as ticketnum
  , sum(if(ticket.paychannel=10, ticket.payamount, 0)) as oiamount
  , sum(if(ticket.paychannel=11, ticket.payamount, 0)) as ticketamount
from
(select distinct substring(b1.createdtime, 0, 10) as d
    , a1.orderid
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d="$effectdate('yyyy-MM-dd',0)"
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d="$effectdate('yyyy-MM-dd',0)"
where substring(b1.createdtime,0,10)>="$effectdate('yyyy-MM-dd',-15)"
  and substring(b1.createdtime,0,10)<"$effectdate('yyyy-MM-dd',0)"
  and (a1.statusid like '12%' OR a1.statusid like '20%' OR a1.statusid like '22%' OR a1.statusid like '23%')
  and a1.saleamount>=20 and a1.d="$effectdate('yyyy-MM-dd',0)" and b1.sellerid=0) oi
inner join
(select distinct substring(createdtime,0,10) as d
  , orderid
  , paychannel
  , payamount
from ods_htl_bnborderdb.order_pay
where d = "$effectdate('yyyy-MM-dd',0)"
  and substring(createdtime,0,10)>="$effectdate('yyyy-MM-dd',-15)"
  and substring(createdtime,0,10)<"$effectdate('yyyy-MM-dd',0)"
  and paychannel in(10, 11)
  and reverseflag=1) ticket on ticket.d = oi.d and ticket.orderid=oi.orderid
group by oi.d

union all

select substring(orderdate, 0, 10) as d
  , 1 as type
  , count (distinct orderid) as oinum
  , 0 as ticketnum
  , sum(ciireceivable) as oiamount
  , 0 as ticketamount
from dw_htlmaindb.FactHotelOrder_All_Inn
where substring(orderdate,0,10)>="$effectdate('yyyy-MM-dd',-15)"
  and substring(orderdate,0,10)<"$effectdate('yyyy-MM-dd',0)"
  and d ="$effectdate('yyyy-MM-dd', 0)"
group by substring(orderdate, 0, 10)
) aa



select aa.d
  , aa.type
  , aa.oinum as `总订单数`
  , aa.ticketnum as `使用券订单数`
  , aa.oiamount as `订单总金额`
  , aa.ticketamount as `优惠券总金额`
  , concat(cast(100*((aa.ticketamount)/aa.oiamount) as decimal(5,2)),'%') as `赔付率`
  , concat(cast(100*((aa.ticketnum)/aa.oinum) as decimal(5,2)),'%') as `使用率`
from
(select oi.d
  , 0 as type
  , sum(if(ticket.paychannel=10, 1, 0)) as oinum
  , sum(if(ticket.paychannel=11, 1, 0)) as ticketnum
  , sum(if(ticket.paychannel=10, ticket.payamount, 0)) as oiamount
  , sum(if(ticket.paychannel=11, ticket.payamount, 0)) as ticketamount
from
(select distinct substring(b1.createdtime, 0, 10) as d
    , a1.orderid
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d='2018-06-18'
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d='2018-06-18'
where substring(b1.createdtime,0,10)>='2018-06-10'
  and substring(b1.createdtime,0,10)<'2018-06-18'
  and (a1.statusid like '12%' OR a1.statusid like '20%' OR a1.statusid like '22%' OR a1.statusid like '23%')
  and a1.saleamount>=20 and a1.d='2018-06-18' and b1.sellerid=0) oi
inner join
(select distinct substring(createdtime,0,10) as d
  , orderid
  , paychannel
  , payamount
from ods_htl_bnborderdb.order_pay
where d = '2018-06-18'
  and substring(createdtime,0,10)>='2018-06-10'
  and substring(createdtime,0,10)<'2018-06-18'
  and paychannel in(10, 11)
  and reverseflag=1) ticket on ticket.d = oi.d and ticket.orderid=oi.orderid
group by oi.d

union all

select substring(orderdate, 0, 10) as d
  , 1 as type
  , count (distinct orderid) as oinum
  , 0 as ticketnum
  , sum(ciireceivable) as oiamount
  , 0 as ticketamount
from dw_htlmaindb.FactHotelOrder_All_Inn
where substring(orderdate,0,10)>='2018-06-10'
  and substring(orderdate,0,10)<'2018-06-18'
  and d ='2018-06-18'
group by substring(orderdate, 0, 10)
) aa
