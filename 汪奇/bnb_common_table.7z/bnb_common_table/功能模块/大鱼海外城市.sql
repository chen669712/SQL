--获取大鱼海外的城市集
set calDay='2018-05-02';
use bnb_hive_db;

drop table if EXISTS tmp_wq_oversea_city_prd;
CREATE TABLE tmp_wq_oversea_city_prd AS
select bss.spaceid
  , city.cityid
	, city.cityname
from
(select distinct spaceid
from ods_htl_groupwormholedb.bnb_space_source
where d = ${hiveconf:calDay}
	and vendorid = 201) bss
inner join(
select spaceid
	, cityid
from ods_htl_groupwormholedb.bnb_space_address
where d = ${hiveconf:calDay}) bsa on bss.spaceid = bsa.spaceid
inner join(
select spaceid
from ods_htl_groupwormholedb.bnb_space
where d = ${hiveconf:calDay}
  and statusid=2) bsp on bsp.spaceid = bsa.spaceid
inner join(
select cityid
	,cityname 
from ods_htl_groupwormholedb.bnb_city
where d = ${hiveconf:calDay}) city on city.cityid = bsa.cityid



use bnb_hive_db;
select count(distinct cityid) as num
from tmp_wq_oversea_city_prd


use bnb_hive_db;
select cityname, count(distinct spaceid) as num
from tmp_wq_oversea_city_prd
group by cityname


--------------------------------------
--- 订单城市
use bnb_hive_db;
select distinct oi.d
  , oi.nums
  , oi.cityid
	, city.cityname
from
(select to_date(ordertime) as d
	, cityid
	, count(DISTINCT orderid) as nums
from bnb_orderinfo
where d='2018-04-08'
	and to_date(ordertime) >='2018-02-01'
	and to_date(ordertime) <'2018-04-09'
	and vendorid = '201'
group by to_date(ordertime), cityid) oi
inner join
tmp_wq_oversea_city_prd city on oi.cityid = city.cityid

use bnb_hive_db;
select bc.cityname
  , count (oi.orderid) as num
from
(select to_date(ordertime) as d
  , orderid
  , cityid
from bnb_orderinfo
where d = '2018-04-24'
  and to_date(ordertime) >='2018-02-01'
  and to_date(ordertime) <='2018-04-01'
  and source = '101') oi
inner join
(select *
from ods_htl_groupwormholedb.bnb_city
where d = '2018-04-24'
  and country <> 1) bc on oi.cityid = bc.cityid
group by bc.cityname



---------------------------------------------------------------------------------
--- 日报表
set calDay='2018-05-01';
use bnb_hive_db;
select bss.d  as `日期`
  , city.cityname as `城市名`
	, count (distinct bss.spaceid) as `有效产品数`
	, count (distinct bpt1.productid) as `列表页曝光产品数`
	, count (distinct bpt2.productid) as `列表页点击产品数`
	, count (distinct oi.orderid) as `日订单数`
	, count (distinct oi.productid) as `产生订单产品数`
from
(select distinct d, spaceid
from ods_htl_groupwormholedb.bnb_space_source
where d = "$effectdate('yyyy-MM-dd',-1)"
	and vendorid = 201) bss
inner join(
select spaceid
	, cityid
from ods_htl_groupwormholedb.bnb_space_address
where d = "$effectdate('yyyy-MM-dd',-1)") bsa on bss.spaceid = bsa.spaceid
inner join(
select spaceid
from ods_htl_groupwormholedb.bnb_space
where d = "$effectdate('yyyy-MM-dd',-1)"
  and statusid=2) bsp on bsp.spaceid = bsa.spaceid
inner join(
select cityid
	,cityname
from ods_htl_groupwormholedb.bnb_city
where d = "$effectdate('yyyy-MM-dd',-1)") city on city.cityid = bsa.cityid
left outer join
(select cityid
	, orderid
	, productid
from bnb_hive_db.bnb_orderinfo
where d = "$effectdate('yyyy-MM-dd',-1)"
	and to_date(ordertime) = "$effectdate('yyyy-MM-dd',-1)"
	and vendorid = '201') oi on oi.cityid = bsa.cityid
left outer join
(select distinct cityid
  , productid
  , type
from bnb_hive_db.bnb_product_trace
where d = "$effectdate('yyyy-MM-dd',-1)"
  and source = '102'
  and type='100') bpt1 on bpt1.productid = bsa.spaceid
left outer join
(select distinct cityid
  , productid
  , type
from bnb_hive_db.bnb_product_trace
where d = "$effectdate('yyyy-MM-dd',-1)"
  and source = '102'
  and type='101') bpt2 on bpt2.productid = bsa.spaceid
group by bss.d
  , city.cityname



