


select d
	, count(distinct vid) as uv
from dw_ubtdb.pageview
where originalpageid in('600003543')
	and d >= '2018-06-01'
group by d