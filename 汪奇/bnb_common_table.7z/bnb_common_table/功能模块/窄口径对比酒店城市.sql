
----------------------------酒店的搜索城市分布--------------------------------------
use bnb_hive_db;
drop table if exists tmp_wq_bnb_vs_htl_search;
create table tmp_wq_bnb_vs_htl_search as
select d
  , get_json_object(exdata,'$.cityid') as cityid
  , count(distinct clientcode) as uv
from dw_mobdb.factmbtracelog_sdk
where d>='2018-06-13'
  and actioncode in('o_hotel_oversea_list_basic', 'o_hotel_inland_list_basic')
group by d
  , actioncode
  , get_json_object(exdata,'$.cityid')


----------------------------酒店的订单城市分布--------------------------------------
use bnb_hive_db;
drop table if exists tmp_wq_bnb_vs_htl_oi;
create table tmp_wq_bnb_vs_htl_oi as
select oi.d
  , oi.cityid
  , city.cityname
  , city.country
  , count (distinct oi.orderid) as ois
from
(select substring(orderdate,0,10) as d
  , cityid
  , orderid
from dw_htlmaindb.facthotelorder
where d>='2018-06-01') oi
inner join
(select d
  , orderid
 from ods_htl_orderdb.ord_ltp_paymentinfo
where d='2018-06-20'
  and paymentstatus = 2) olp on oi.orderid = olp.orderid
left outer join
(select cityid
  , cityname
  , country
from ods_htl_groupwormholedb.bnb_city
where d='2018-06-20') city on oi.cityid = city.cityid
group by oi.d
  , cityid
  , city.cityname
  , city.country

----------------------------民宿的搜索城市分布--------------------------------------
use bnb_hive_db;
drop table if exists tmp_wq_bnb_vs_bnb_search;
create table tmp_wq_bnb_vs_bnb_search as
SELECT d
  , get_json_object(value, '$.cityid') AS cityid
  , get_json_object(value, '$.cityname') AS cityname
  , count(distinct cid) AS uv
FROM bnb_hive_db.bnb_tracelog
WHERE d >= '2018-06-01'
AND KEY in ('100641','bnb_inn_list_app_basic')
GROUP BY d
  , get_json_object( VALUE, '$.cityid')
  , get_json_object(value, '$.cityname') AS cityname


----------------------------------
--- 查看搜索占比
----------------------------------
use bnb_hive_db;
select htl.d
  , htl.cityid
  , city.cityname
  , case when city.country = 1 then 'y'
    else 'n' end as chFlag
  , htl.uv
  , bnb.uv
  , concat(cast(100*((bnb.uv)/htl.uv) as decimal(5,2)),'%') as `搜索用户占比`
from
(select d
  , cityid
  , sum(uv) as uv
from tmp_wq_bnb_vs_htl_search10
group by d, cityid) htl
left outer join
tmp_wq_bnb_vs_bnb_search bnb on htl.d = bnb.d and htl.cityid=bnb.cityid
left outer join
(select cityid
  , cityname
  , country
from ods_htl_groupwormholedb.bnb_city
where d='2018-06-20') city on htl.cityid = city.cityid


----------------------------民宿的搜索城市分布--------------------------------------
use bnb_hive_db;
drop table if exists tmp_wq_bnb_vs_bnb_oi;
create table tmp_wq_bnb_vs_bnb_oi as
select a.d
  , a.cityid
  , sum (a.ois) as ois
from
(select a.d
  , a.cityid
  ,if(a.d>='2018-05-26', sum(if(a.terminalType=10, 1, 0))
      , sum(if(a.applicationType=10 or a.applicationType is null, 1, 0))) as ois
from
(select distinct substring(b1.createdtime, 0, 10) as d
    , b1.applicationType
    , b1.terminalType
    , a1.orderid
    , c1.cityid
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d='2018-06-20'
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d='2018-06-20'
where substring(b1.createdtime,0,10)>='2018-06-01'
  and b1.visitsource in (0, 20, 70, 120, 130, 201, 203, 205)
  and (a1.statusid like '12%' OR a1.statusid like '20%' OR a1.statusid like '22%' OR a1.statusid like '23%')
  and a1.saleamount>=20 and a1.d='2018-06-20' and b1.sellerid=0) a
group by a.d
  , a.cityid
union all
select b.d
  , b.cityid
  , round(count(distinct b.orderid)*0.85,0) as ois
from
(select substring(orderdate, 0, 10) as d
  , cityid
  , orderid
from dw_htlmaindb.FactHotelOrder_All_Inn
where substring(orderdate,0,10)>='2018-06-01'
  and d ='2018-06-20' ) b
  group by b.d, b.cityid)a
group by a.d
  , a.cityid


----------------------------------
--- 查看订单占比
----------------------------------
use bnb_hive_db;
select htl.d
  , htl.cityid
  , htl.cityname
  , case when htl.country = 1 then 'y'
    else 'n' end as chFlag
  , htl.ois
  , bnb.ois
  , concat(cast(100*((bnb.ois)/htl.ois) as decimal(5,2)),'%') as `订单占比`
from tmp_wq_bnb_vs_htl_oi htl
left outer join
tmp_wq_bnb_vs_bnb_oi bnb on htl.d = bnb.d and htl.cityid=bnb.cityid




use bnb_hive_db;
select d
  , cityid
  , sum(uv) as uv
from tmp_wq_bnb_vs_htl_search10
group by d
  ,cityid