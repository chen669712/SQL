use bnb_hive_db;
set beginDay='2018-04-01';
set endDay='2018-04-30';
set calDay='2018-05-02';


select count (a.orderid) as `离店总订单数`
  , sum (a.saleamount) as `离店总GMV`
  , sum (IF(a.payamount is null, 0, 1)) as `离店有券订单数`
  , sum (IF(a.payamount is null, 0, a.saleamount)) as `离店有券GMV`
  , sum (IF(a.payamount is null, 0, a.payamount)) as `券金额`
from
(select distinct oi.d
  , oi.orderid
  , oi.saleamount
  , op.payamount
from
(select			------------离店
  to_date(c1.checkout) as d
  ,a1.orderid
  ,datediff(to_date(c1.checkout),to_date(c1.checkin))*(a1.quantity) as output
  ,a1.saleamount
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d=${hiveconf:calDay}
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d=${hiveconf:calDay}
where to_date(c1.checkout)<=${hiveconf:endDay}
  and to_date(c1.checkout)>=${hiveconf:beginDay}
  and a1.statusid  in (1212,2212,2232,2233)
  and a1.saleamount>=20
  and a1.d=${hiveconf:calDay}
  and b1.sellerid=0) oi
left outer join
(select orderid
  , payamount
from ods_htl_bnborderdb.order_pay
where d = ${hiveconf:calDay}
  and paychannel=11 --优惠券支付
) op on oi.orderid = op.orderid) a