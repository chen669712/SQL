
use bnb_hive_db;
select *
from bnb_tracelog
where d='2018-06-27'
	and key in ('c_bnb_inn_search_list_app')
	and get_json_object(value, '$.sequenceId') is not null
	and get_json_object(value, '$.type') is null
	and (get_json_object(value, '$.item') is null or get_json_object(get_json_object(value, '$.item'), '$.typeid') <> 0)
	and get_json_object(value, '$.operation') not in ('100', '200')