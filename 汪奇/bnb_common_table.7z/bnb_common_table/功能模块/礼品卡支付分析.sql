select op.orderid as '订单号',
 case op.reverseFlag when 1 then '支付' else '取消' end as '类型',
 case  when oi.productid is null then '无发票' else '开发票' end as '发票',
 optd.realamount '金额',op.createdtime '时间'
from order_pay op
inner join order_pay_trans opt on op.payid=opt.payid
inner join order_pay_trans_detail optd on optd.transid=opt.transid
left join order_item oi on op.orderid=oi.orderid and oi.producttype=2
where paytypecode = 'TMPAY' and op.createdtime>'2018-05-25'
order by op.orderid


(select to_date(b1.createdtime) as d
    , a1.orderid
    , b1.applicationType
    , b1.terminalType
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d='${zdt.format("yyyy-MM-dd")}'
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d='${zdt.format("yyyy-MM-dd")}'
where to_date(b1.createdtime)='${zdt.addDay(-1).format("yyyy-MM-dd")}'
  and b1.visitsource in (0, 20, 70, 120, 130, 201, 203, 205)
  and (a1.statusid like '12%' OR a1.statusid like '20%' OR a1.statusid like '22%' OR a1.statusid like '23%')
  and a1.saleamount>=20 and a1.d='${zdt.format("yyyy-MM-dd")}'
  and b1.sellerid=0) oi
left outer join