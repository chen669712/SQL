select d
  , count (distinct clientcode ) as uv
from dw_mobdb.factmbpageview
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and pagecode = '600003560'
group by d;


select a.d
  , count (distinct a.cid) as `使用搜索UV`
from
(
select distinct d
  ,newvalue.data['env_clientcode'] as cid
from dw_mobdb.factmbtracelog_hybrid
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and key = 'bnb_inn_list_app_basic'

union all
select distinct d
  ,newvalue.data['env_clientcode'] as cid
from dw_mobdb.factmbtracelog_hybrid
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and key = 'c_bnb_inn_home_filter_app') a
group by a.d;


-----对比两边的用户集-----
---首页
use bnb_hive_db;
select home.d
  , count (distinct home.cid) as uv
from
(select distinct d, cid
from bnb_user_distribution
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and homeFlag='1')home
left outer join tmp_wq_newkpi_search search on search.d=home.d and search.cid=home.cid
where search.cid is null
group by home.d
---列表页
use bnb_hive_db;
select home.d
  , count (distinct home.cid) as uv
from
(select distinct d, cid
from bnb_user_distribution
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and listFlag='1')home
left outer join tmp_wq_newkpi_list list on list.d=home.d and list.cid=home.cid
where list.cid is null
group by home.d
---详情页
use bnb_hive_db;
select home.d
  , count (distinct home.cid) as uv
from
(select distinct d, cid
from bnb_user_distribution
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and detailFlag='1')home
left outer join tmp_wq_newkpi_detail detail on detail.d=home.d and detail.cid=home.cid
where detail.cid is null
group by home.d

---填写页
use bnb_hive_db;
select home.d
  , count (distinct home.cid) as uv
from
(select distinct d, cid
from bnb_user_distribution
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and fillFlag='1')home
left outer join tmp_wq_newkpi_booking booking on booking.d=home.d and booking.cid=home.cid
where booking.cid is null
group by home.d


select oi.d
  , count (oi.orderid) as num
from
(select substring(b1.createdtime, 0, 10) as d
        , a1.orderid
        , b1.clientid as cid
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d='2018-07-17'
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d='2018-07-17'
where substring(b1.createdtime,0,10)>='2018-07-10'
  and b1.visitsource in (0, 20, 70, 120, 130, 201, 203, 205)
  and b1.sellerid=0
  and a1.saleamount>=20
  and b1.terminalType=10
  and a1.d='2018-07-17') oi
left outer join
tmp_wq_newkpi_submit sumbit on oi.d = submit.d and oi.cid = submit.cid
where sumbit.cid is null
group by oi.d



select *
from dw_mobdb.factmbtracelog_hybrid
where d = '2018-07-16'
  and key = 'bnb_inn_list_app_basic'
  and newvalue.data['env_clientcode']='12001011410029109554'

----------------------------------------------------------------------------------------------------
-----
----------------------------------------------------------------------------------------------------
drop table if exists tmp_wq_newkpi_search;
create table tmp_wq_newkpi_search as
select distinct d
    ,newvalue.data['env_clientcode'] as cid
from dw_mobdb.factmbtracelog_hybrid
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and key = 'bnb_inn_list_app_basic'


use bnb_hive_db;
drop table if exists tmp_wq_newkpi_list;
create table tmp_wq_newkpi_list as
select search.d
  ,search.cid
from tmp_wq_newkpi_search search
left outer join
(select distinct d
  ,clientcode as cid
from dw_mobdb.factmbpageview
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and pagecode = '600003563') list on list.d=search.d and list.cid=search.cid
where list.cid is not null;


use bnb_hive_db;
drop table if exists tmp_wq_newkpi_detail;
create table tmp_wq_newkpi_detail as
select search.d
  ,search.cid
from tmp_wq_newkpi_search search
left outer join
(select distinct d
  ,clientcode as cid
from dw_mobdb.factmbpageview
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and pagecode in ('600003564','10320677404')) detail on detail.d=search.d and detail.cid=search.cid
where detail.cid is not null;

use bnb_hive_db;
drop table if exists tmp_wq_newkpi_booking;
create table tmp_wq_newkpi_booking as
select search.d
  ,search.cid
from tmp_wq_newkpi_search search
left outer join
(select distinct d
  ,clientcode as cid
from dw_mobdb.factmbpageview
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and pagecode in ('600003570','10320677405')) booking on booking.d=search.d and booking.cid=search.cid
where booking.cid is not null;

use bnb_hive_db;
drop table if exists tmp_wq_newkpi_submit;
create table tmp_wq_newkpi_submit as
select search.d
  ,search.cid
from tmp_wq_newkpi_search search
left outer join
(select substring(b1.createdtime, 0, 10) as d
        , a1.orderid
        , b1.clientid as cid
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d='2018-07-17'
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d='2018-07-17'
where substring(b1.createdtime,0,10)>='2018-07-10'
  and substring(b1.createdtime,0,10)<='2018-07-16'
  and a1.d='2018-07-17'
union all
select to_date(orderdate) as d
  , orderid
  , clientid as cid
from dwhtl.edw_htl_order_all_orderdate
where to_date(orderdate)>='2018-07-10'
  and to_date(orderdate)<='2018-07-16'
  and subchannel='h5_kezhan'
  and d>='2018-07-10'
  and d<='2018-07-16') submit on submit.d=search.d and submit.cid=search.cid
where submit.cid is not null;

select search.d
  , count (distinct search.cid ) as `完成搜索`
  , count (distinct list.cid) as `列表页`
  , count (distinct detail.cid) as `详情页`
  , count (distinct booking.cid) as `填写页`
  , count (distinct submit.cid) as `提交UV`
  , count (distinct submit.orderid) as `提交单`
  , count (distinct pay.cid) as `支付UV`
  , count (distinct pay.orderid) as `支付单`
from
(select distinct d
    ,newvalue.data['env_clientcode'] as cid
from dw_mobdb.factmbtracelog_hybrid
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and key = 'bnb_inn_list_app_basic')search
left outer join
(select distinct d
  ,clientcode as cid
from dw_mobdb.factmbpageview
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and pagecode = '600003563') list on list.d=search.d and list.cid=search.cid
left outer join
(select distinct d
  ,clientcode as cid
from dw_mobdb.factmbpageview
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and pagecode in ('600003564','10320677404')) detail on detail.d=search.d and detail.cid=search.cid
left outer join
(select distinct d
  ,clientcode as cid
from dw_mobdb.factmbpageview
where d >= '2018-07-10'
  and d <= '2018-07-16'
  and pagecode in ('600003570','10320677405')) booking on booking.d=search.d and booking.cid=search.cid
left outer join
(select substring(b1.createdtime, 0, 10) as d
        , a1.orderid
        , b1.clientid as cid
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d='2018-07-17'
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d='2018-07-17'
where substring(b1.createdtime,0,10)>='2018-07-10'
  and substring(b1.createdtime,0,10)<='2018-07-16'
  and a1.d='2018-07-17'
union all
select to_date(orderdate) as d
  , orderid
  , clientid as cid
from dwhtl.edw_htl_order_all_orderdate
where to_date(orderdate)>='2018-07-10'
  and to_date(orderdate)<='2018-07-16'
  and subchannel='h5_kezhan'
  and d>='2018-07-10'
  and d<='2018-07-16') submit on submit.d=search.d and submit.cid=search.cid
left outer join
(select substring(b1.createdtime, 0, 10) as d
        , a1.orderid
        , b1.clientid as cid
from ods_htl_bnborderdb.order_item a1
left join ods_htl_bnborderdb.order_header_v2 b1 on a1.orderid=b1.orderid and b1.d='2018-07-17'
left join ods_htl_bnborderdb.order_item_space c1 on c1.orderitemid=a1.orderitemid and c1.d='2018-07-17'
where substring(b1.createdtime,0,10)>='2018-07-10'
  and substring(b1.createdtime,0,10)<='2018-07-16'
  and a1.d='2018-07-17'
  and (a1.statusid like '12%' or a1.statusid like '20%' or a1.statusid like '22%' or a1.statusid like '23%')
union all
select to_date(orderdate) as d
  , orderid
  , clientid as cid
from dwhtl.edw_htl_order_all_orderdate
where to_date(orderdate)>='2018-07-10'
  and to_date(orderdate)<='2018-07-16'
  and subchannel='h5_kezhan'
  and d>='2018-07-10'
  and d<='2018-07-16'
  and orderstatus not in ('W')) pay on pay.d = search.d and pay.cid=search.cid
group by search.d;
