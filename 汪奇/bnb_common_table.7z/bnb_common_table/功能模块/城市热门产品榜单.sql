use bnb_hive_db;
CREATE TABLE bnb_product_list(
`cityid` int COMMENT '城市Id（基于酒店的）',
`zoneid` int COMMENT '商圈Id',
`zonename` string COMMENT '商圈名',
`locationid` int COMMENT '行政区Id',
`locationname` string  COMMENT '行政区名',
`productid` int  COMMENT '是否有效，0-无效，1-有效',
`score` float  COMMENT '产品打分'
)COMMENT '产品地区榜单表'
PARTITIONED BY (`d` string COMMENT 'date')


use bnb_hive_db;
insert overwrite table bnb_product_list
partition (d = '${zdt.format("yyyy-MM-dd")}')
select oi.cityid
  , bsz.zoneid
  , bsz.zonename
  , bsl.locationid
  , bsl.locationname
  , oi.productid
  , log10(oi.num) * 1.5 + if(bpt.num is null, 0, log10(bpt.num)) as score
from
(select cityid
  , productid
  , count(distinct orderid) as num
from bnb_orderinfo
where d='${zdt.addDay(-1).format("yyyy-MM-dd")}'
  and to_date(ordertime) >='${zdt.addDay(-121).format("yyyy-MM-dd")}'
  and source = '100'
group by cityid
  , productid) oi
left join
(select distinct spaceid
  ,locationid
  ,locationname
from ods_htl_groupwormholedb.bnb_space_location
where d='${zdt.format("yyyy-MM-dd")}') bsl on oi.productid = bsl.spaceid
left join
(select distinct spaceid
  ,zoneid
  ,zonename
from ods_htl_groupwormholedb.bnb_space_zone
where d='${zdt.format("yyyy-MM-dd")}') bsz on oi.productid = bsz.spaceid
left outer join
(select productid
  , count (1) as num
from bnb_product_trace
where d>='${zdt.addDay(-31).format("yyyy-MM-dd")}'
  and type='101'
group by productid) bpt on oi.productid = bpt.productid
where bsl.locationid is not null
  or bsz.zoneid is not null

use bnb_hive_db;
select * from bnb_product_list
where d = '2018-05-23'
  and cityid = 2
  and zonename like '%长宁%'
order by score desc
limit 100

