use bnb_hive_db;
set beginDay='2018-01-01';
set endDay='2018-02-01';
set calDay='2018-05-02';
select
`createdate` as `日期`,
`bookingCnt` as `预定订单`,
`uv` as `日均UV`,
round(`checkoutCnt` / `bookingCnt`, 2) as `离店/预定`,
round(`bookingCnt` / `uv`, 4) as `转化率`,
round(`bookingNightsCnt` / `bookingCnt`, 2) as `总单均间夜`,
round(`tujiaBookingNightsCnt` / `tujiaBookingCnt`, 2) as `途家单均间夜`,
round((`bookingNightsCnt` - `tujiaBookingNightsCnt`) / (`bookingCnt` - `tujiaBookingCnt`), 2) as `非途家单均间夜`,
round(`sumBookingAmount` / `bookingNightsCnt`, 2) as `总间夜均价`,
round(`tujiaBookingAmount` / `tujiaBookingNightsCnt`, 2) as `途家间夜均价`,
round((`sumBookingAmount` - `tujiaBookingAmount`) / (`bookingNightsCnt` - `tujiaBookingNightsCnt`), 2) as `非途家间夜均价`,
`GMV` as `总GMV`,
`tujiaGMV` as `途家GMV`,
`GMV` - `tujiaGMV` as `非途家GMV`,
round(`tujiaGMV` / `GMV`, 4) as `途家GMV占比`,
`checkoutCnt` as `总离店订单`,
`checkoutCnt` - `tujiaCheckoutCnt` as `非途家离店订单`,
`tujiaCheckoutCnt` as `途家离店订单`,
round(`tujiaCheckoutCnt` / `checkoutCnt`, 4) as `途家离店订单途家占比`,
`checkoutNightsCnt` as `总离店间夜`,
`checkoutNightsCnt` - `tujiaCheckoutNightsCnt` as `非途家离店间夜`,
`tujiaCheckoutNightsCnt` as `途家离店间夜`,
round(`tujiaCheckoutNightsCnt` / `checkoutNightsCnt`, 4) as `途家离店间夜途家占比`
from (
    (SELECT  ----预定时间
       to_date(oh.createdtime) AS `createdate`,
       count(*) AS `bookingCnt`,
       sum(if(oi.vendorId IN ( 105, 115 ), 1, 0)) AS `tujiaBookingCnt`,

       sum(DATEDIFF(ois.checkout, ois.checkin)) AS `bookingNightsCnt`,
       sum(if(oi.vendorId IN ( 105, 115 ), DATEDIFF(ois.checkout, ois.checkin), 0)) AS `tujiaBookingNightsCnt`,

       sum(saleAmount) as `sumBookingAmount`,
       sum(if(oi.vendorId IN ( 105, 115 ), oi.saleAmount, 0)) as `tujiaBookingAmount`
    FROM ods_htl_bnborderdb.order_header_v2  oh,ods_htl_bnborderdb.order_item  oi,ods_htl_bnborderdb.order_item_space  ois
    WHERE
       oh.d = ${hiveconf:calDay} AND
       oi.d = ${hiveconf:calDay} AND
       ois.d = ${hiveconf:calDay} AND
       oh.orderid = oi.orderid AND
       oi.orderitemid = ois.orderitemid AND
       oh.salesChannel = 1 AND
       oi.statusId DIV 100 IN (12,20,22,23) AND
       oi.productType = 1 AND
       oh.createdtime >= ${hiveconf:beginDay} AND oh.createdtime < ${hiveconf:endDay}
       group by to_date(oh.createdtime) ) as created_date_dimension
    JOIN
    (SELECT  ----离店时间
         to_date(ois.checkout) AS `checkoutdate`,
         sum(DATEDIFF(ois.checkout, ois.checkin)) AS `checkoutNightsCnt`,
         sum(if(oi.vendorId IN ( 105, 115 ), DATEDIFF(ois.checkout, ois.checkin), 0)) AS `tujiaCheckoutNightsCnt`,

         sum(oi.saleAmount) as `GMV`,
         sum(if(oi.vendorId IN ( 105, 115 ), oi.saleAmount, 0)) as `tujiaGMV`,
         count(*) AS `checkoutCnt`,
         sum(if(oi.vendorId IN ( 105, 115 ), 1, 0)) AS `tujiaCheckoutCnt`
    FROM ods_htl_bnborderdb.order_header_v2  oh,ods_htl_bnborderdb.order_item  oi,ods_htl_bnborderdb.order_item_space  ois
    WHERE
       oh.d = ${hiveconf:calDay} AND
       oi.d = ${hiveconf:calDay} AND
       ois.d = ${hiveconf:calDay} AND
       oh.orderid = oi.orderid AND
       oi.orderitemid = ois.orderitemid AND
       oh.salesChannel = 1 AND
       oi.statusId DIV 100 IN (12,20,22,23) AND
       oi.productType = 1 AND
       ois.checkout >= ${hiveconf:beginDay} AND ois.checkout < ${hiveconf:endDay}
       group by to_date(ois.checkout)) as checkout_date_dimension
    ON created_date_dimension.createdate = checkout_date_dimension.checkoutdate

    JOIN
    (SELECT d as `uvdate`, round(count(DISTINCT clientcode)) as `uv`
      FROM DW_MobDB.factmbpageview
      WHERE d >= ${hiveconf:beginDay} AND d < ${hiveconf:endDay}AND
             pagecode IN ('600003560', '10320675332') AND
             (prepagecode = '215019' OR prepagecode = 'home' OR prepagecode = '0')
      group by d )  AS uv_date_dimension
    ON created_date_dimension.createdate = uv_date_dimension.uvdate
) as t order by `createdate` asc












