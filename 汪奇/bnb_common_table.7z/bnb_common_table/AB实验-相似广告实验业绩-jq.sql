-----# 相似广告实验业绩

drop table tmp_wq_similaradcid;
create table tmp_wq_similaradcid as 
select clientcode
     , mod
     , case when lower(abversion) in ('c','d') then 'C+D' else 'B' end as abversion
     , min(starttime) as starttime
     , min(unix_timestamp(substring(starttime,1,19))) as unix_time
     , lower(trim(expcode)) as expcode
     , d
  from dw_abtestdb.factabtestingserver
where lower(trim(expcode)) in ('170816_oth_adxs'
                              ,'170816_oth_adxsb'
                              ,'170828_oth_xsad')
  and d>='2017-09-11'
  and d<='2017-09-24'
 group by clientcode
     , mod
     , case when lower(abversion) in ('c','d') then 'C+D' else 'B' end
     , lower(trim(expcode))
     , d;


drop table tmp_wq_similarad_abcid;
create table tmp_wq_similarad_abcid as 
select a.d 
     , a.clientcode
     , a.abversion
     , a.expcode
     , a.starttime
     , a.unix_time
  from tmp_wq_similaradcid a 
left outer join (
                 select d
                      , clientcode
                      , expcode
                      , count(distinct abversion) as abcnt 
                  from tmp_wq_similaradcid 
                group by d
                       , clientcode
                       , expcode
                having count(distinct abversion)>1) b on a.clientcode=b.clientcode and a.d=b.d and a.expcode=b.expcode
left outer join (
                 select clientcode
                   from olap_abtestdb.abAbnormalUser
                  where d>='2017-09-11'
                    and d<='2017-09-24'
                    and clienttype = 'app'
                    and distance>std
                    and distance>1
               group by clientcode ) c on a.clientcode=c.clientcode
where b.clientcode is null
  and c.clientcode is null; 



--- 帮忙计算一下相似广告的AB实验结果，实验周期为9月11日~9月17日
--- 计算实验组和对照组的订单金额提升，订单只取酒店订单，
--- 取订单口径分成(预订单，成交单) x 时间(当天，24小时，7天三个口径)

use tmp_mobdb;

drop table tmp_wq_similaradshowclick;
create table tmp_wq_similaradshowclick as
select vid,sid,d,key
      ,floor(cast(ts as bigint)/1000) as unix_time
      ,str_to_map(value,'&','=')['UserId'] as UserId --(userid=clientcode + uid)
      ,str_to_map(value,'&','=')['PageId'] as PageId
      ,str_to_map(value,'&','=')['AdId'] as AdId
      ,value
from dw_mobdb.factmbtracelog_hybrid 
where d>='2017-09-11'
  and d<='2017-09-24'  
  and lower(trim(key)) IN ('adclick'
                          ,'adpv')
  and str_to_map(value,'&','=')['AdId'] <> 'undefined';


create table tmp_wq_similaradvidcid_raw as 
select sid
     , vid
     , clientcode
     , d
 from dw_mobdb.factmbpageview
where d>='2017-09-11'
  and d<='2017-09-24'
  and clientcode is not null 
  and clientcode not in ('','00000000000000000000')
group by sid
       , vid
       , clientcode
       , d;


---- 打上cid
create table tmp_wq_similaradvidcid as 
select a.sid
     , a.vid
     , a.clientcode
     , a.d
from tmp_wq_similaradvidcid_raw a 
left outer join (
                  select sid 
                       , vid 
                       , d 
                       , count(distinct clientcode) as cnt
                  from tmp_wq_similaradvidcid_raw
                  group by sid 
                         , vid 
                         , d 
                  having count(distinct clientcode)>1 ) b on a.sid=b.sid and a.vid=b.vid and a.d=b.d 
where b.vid is null ;


create table tmp_wq_similaradshowclick_hybrid as 
select a.vid
      ,a.sid
      ,b.clientcode
      ,a.d
      ,a.key
      ,a.unix_time
      ,a.UserId
      ,a.PageId
      ,a.AdId
      ,a.value
  from tmp_wq_similaradshowclick a 
left outer join tmp_wq_similaradvidcid b 
  on a.d=b.d and lower(trim(a.vid))=lower(trim(b.vid)) and a.sid=b.sid ;



drop table tmp_wq_similarad_order ;
create table tmp_wq_similarad_order as
select to_date(orderdate) as d 
      ,orderid
      ,orderdate
      ,amount
      ,unix_timestamp(substring(orderdate,1,19))  as unix_order
      ,clientcode 
      ,orderstatus
from olap_mobdb.olapmbwirelessorder
where to_date(orderdate)>='2017-09-11'
  and to_date(orderdate)<='2017-10-02'
  and sourcetype = 1
  and clientcode is not null 
  and trim(clientcode) not in ('','00000000000000000000')
  and producttype in ('H');


drop table tmp_wq_similarad_ordermatch ;
create table tmp_wq_similarad_ordermatch as
select a.d as order_date
      ,a.orderid
      ,a.orderdate
      ,a.amount
      ,a.unix_order
      ,a.clientcode 
      ,a.orderstatus
      ,b.expcode
      ,b.abversion
      ,b.unix_time
      ,b.d as click_date
      ,case when a.unix_order>=b.unix_time and a.unix_order<=b.unix_time+86400   then 'y' end as is24horder
      ,case when a.d=b.d                                                         then 'y' end as isdayorder
      ,case when a.unix_order>=b.unix_time and a.unix_order<=b.unix_time+7*86400 then 'y' end as is7dorder
  from tmp_wq_similarad_order a 
left outer join tmp_wq_similarad_abcid b on a.clientcode=b.clientcode;


drop table tmp_wq_similarad_ordermatch_flag;
create table tmp_wq_similarad_ordermatch_flag as 
select order_date
      ,orderid
      ,orderdate
      ,amount
      ,unix_order
      ,clientcode 
      ,orderstatus
      ,expcode
      ,abversion
      ,unix_time
      ,click_date
      ,'24h' as flag
  from tmp_wq_similarad_ordermatch
 where is24horder='y'
union all
select order_date
      ,orderid
      ,orderdate
      ,amount
      ,unix_order
      ,clientcode 
      ,orderstatus
      ,expcode
      ,abversion
      ,unix_time
      ,click_date
      ,'day' as flag
  from tmp_wq_similarad_ordermatch
 where isdayorder='y'
 union all
select order_date
      ,orderid
      ,orderdate
      ,amount
      ,unix_order
      ,clientcode 
      ,orderstatus
      ,expcode
      ,abversion
      ,unix_time
      ,click_date
      ,'7d' as flag
  from tmp_wq_similarad_ordermatch
 where is7dorder='y'  ;


drop table tmp_wq_similarad_aborder;
create table tmp_wq_similarad_aborder as 
 select orderid
       ,orderstatus
       ,clientcode
       ,amount
       ,expcode
       ,abversion
       ,flag 
       ,min(click_date) as click_date
   from tmp_wq_similarad_ordermatch_flag
group by orderid
       ,orderstatus
       ,clientcode
       ,amount
       ,expcode
       ,abversion
       ,flag ;


select click_date
      ,expcode
      ,abversion
      ,flag 
      ,count(orderid)    as order_cnt
      ,  sum(amount)     as order_amount
      ,count(case when upper(orderstatus) IN ('S','T') then orderid    end) as order_cnt_st
      ,  sum(case when upper(orderstatus) IN ('S','T') then amount     end) as order_amount_st
from tmp_wq_similarad_aborder
group by click_date
        ,expcode
        ,abversion
        ,flag;


-------------------- 基于曝光  ------------

---- 533177 adid
---- B版中把该adid曝光过的cid拿出来和C+D比较
---- 还是基于分流时间作为起始时间

create table tmp_wq_similaradshowclick_sdk as 
select vid 
    ,  sid 
    ,  clientcode
    ,  lower(trim(actioncode)) as key
    ,  get_json_object(exdata,'$.AdId') as adid
    ,  exdata
    ,  starttime
    ,  unix_timestamp(substring(starttime,1,19)) as unix_time
 from dw_mobdb.factmbtracelog_sdk
where d>='2017-09-11'
  and d<='2017-09-24'
  and clientcode is not null 
  and clientcode not in ('','00000000000000000000')
  and lower(trim(actioncode)) in ('adpv'
                                 ,'adclick');


--- adid曝光过的cid
create table tmp_wq_similaradshowclick_all as 
select clientcode
     , key 
     , min(unix_time) as unix_time 
     , d
from (
      select clientcode
           , key
           , unix_time
           , d 
        from tmp_wq_similaradshowclick_hybrid
       where adid='533177'
      union all 
      select clientcode
           , key
           , unix_time
           , to_date(starttime) as d 
        from tmp_wq_similaradshowclick_sdk
       where adid='533177' 
         and to_date(starttime)>='2017-09-11'
         and to_date(starttime)<='2017-09-24') a 
group by clientcode
       , key 
       , d;


create table tmp_wq_similarad_abcid2 as 
select a.*
from (
      select d 
           , clientcode
           , abversion
           , expcode
           , starttime
           , unix_time
      from tmp_wq_similarad_abcid
      where abversion='B' ) a 
inner join tmp_wq_similaradshowclick_all b on a.d=b.d and a.clientcode=b.clientcode
union all 
select d 
     , clientcode
     , abversion
     , expcode
     , starttime
     , unix_time
from tmp_wq_similarad_abcid
where abversion='C+D';


drop table tmp_wq_similarad_ordermatchexpose ;
create table tmp_wq_similarad_ordermatchexpose as
select a.d as order_date
      ,a.orderid
      ,a.orderdate
      ,a.amount
      ,a.unix_order
      ,a.clientcode 
      ,a.orderstatus
      ,b.expcode
      ,b.abversion
      ,b.unix_time
      ,b.d as click_date
      ,case when a.unix_order>=b.unix_time and a.unix_order<=b.unix_time+86400   then 'y' end as is24horder
      ,case when a.d=b.d                                                         then 'y' end as isdayorder
      ,case when a.unix_order>=b.unix_time and a.unix_order<=b.unix_time+7*86400 then 'y' end as is7dorder
  from tmp_wq_similarad_order a 
left outer join tmp_wq_similarad_abcid2 b on a.clientcode=b.clientcode;


drop table tmp_wq_similarad_ordermatchexpose_flag;
create table tmp_wq_similarad_ordermatchexpose_flag as 
select order_date
      ,orderid
      ,orderdate
      ,amount
      ,unix_order
      ,clientcode 
      ,orderstatus
      ,expcode
      ,abversion
      ,unix_time
      ,click_date
      ,'24h' as flag
  from tmp_wq_similarad_ordermatchexpose
 where is24horder='y'
union all
select order_date
      ,orderid
      ,orderdate
      ,amount
      ,unix_order
      ,clientcode 
      ,orderstatus
      ,expcode
      ,abversion
      ,unix_time
      ,click_date
      ,'day' as flag
  from tmp_wq_similarad_ordermatchexpose
 where isdayorder='y'
 union all
select order_date
      ,orderid
      ,orderdate
      ,amount
      ,unix_order
      ,clientcode 
      ,orderstatus
      ,expcode
      ,abversion
      ,unix_time
      ,click_date
      ,'7d' as flag
  from tmp_wq_similarad_ordermatchexpose
 where is7dorder='y'  ;


drop table tmp_wq_similarad_aborderexpose;
create table tmp_wq_similarad_aborderexpose as 
 select orderid
       ,orderstatus
       ,clientcode
       ,amount
       ,expcode
       ,abversion
       ,flag 
       ,min(click_date) as click_date
   from tmp_wq_similarad_ordermatchexpose_flag
group by orderid
       ,orderstatus
       ,clientcode
       ,amount
       ,expcode
       ,abversion
       ,flag ;


select click_date
      ,expcode
      ,abversion
      ,flag 
      ,count(orderid)    as order_cnt
      ,  sum(amount)     as order_amount
      ,count(case when upper(orderstatus) IN ('S','T') then orderid    end) as order_cnt_st
      ,  sum(case when upper(orderstatus) IN ('S','T') then amount     end) as order_amount_st
from tmp_wq_similarad_aborderexpose
group by click_date
        ,expcode
        ,abversion
        ,flag;


------ 点击量  -----
create table tmp_tmp_wq_similarad_expcompare as 
select a.clientcode
     , b.expcode
     , lower(a.key) as key 
     , a.d 
from tmp_wq_similaradshowclick_all a 
inner join tmp_wq_similarad_abcid2 b on a.d=b.d and a.clientcode=b.clientcode
group by a.clientcode
       , b.expcode
       , lower(a.key)
       , a.d;